Sega Saturn Common Files
by Anders Montonen
<URL:http://www.helsinki.fi/~ammonton/sega/>

These files are placed in the public domain with no restrictions.

Introduction:
-------------

These are a set of files that I eventually hope will evolve into a
set of C libraries for programming the Sega Saturn without Sega's
libraries. Currently there are only some headers and a few macros
included.

Beware! There will be no guarantees that future updates maintain
compatibility.


History:
--------

18SEP2003:
    -initial release
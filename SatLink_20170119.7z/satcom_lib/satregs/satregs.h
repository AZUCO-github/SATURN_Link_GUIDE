#ifndef SATREGS_H_
#define SATREGS_H_

#include "scu.h"
#include "smpc.h"
#include "vdp1.h"
#include "vdp2.h"

#include "ubc.h"

#endif /* SATREGS_H_ */

iapetus "lite" version for Pseudo Saturn Kai.

This folder contains stripped version of iapetus library used by Pseudo Saturn Kai.

Following modules are removed :
 - ar
 - debug
 - ui
 - video

And, peripheral module is slightly modified in order to support theses two ways of reading pad status :
 - direct I/O
 - INTBACK polling (interrupt free)


Latest and full version of iapetus library can be found here :
https://github.com/cyberwarriorx/iapetus





//---------------------------------------------------------------------------

#ifndef ProcessThreadH
#define ProcessThreadH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <stdio.h>
#include <stdarg.h>

#include "common/log.h"
#include "common/satcom.h"
#include "satcom_devices.h"

#include "UserData.h"
#include "inifile.h"

/* Register Write stuff (global data). */
typedef struct _regs_list_t
{
    char siz;          /* Register size (in bytes). */
    unsigned long adr; /* Register address.         */
    char nam[32];      /* Register name.            */
} regs_list_t;
extern const regs_list_t regs_list[];

/* Register Write stuff (process thread internal use). */
typedef struct _reg_convert_t
{
    /* Input: register address/name. */
    char* i_reg_address;
    /* Input: register size. */
    char* i_reg_size;
    /* Input: register value. */
    char* i_reg_value;

    /* Output: register address. */
    unsigned long o_reg_address;
    /* Output: register list index (-1: not found in list). */
    int o_reg_index;
    /* Output: register size. */
    int o_reg_size;
    /* Input: register value. */
    unsigned char o_reg_value[4];
    unsigned long o_reg_intvalue;
} reg_convert_t;

#define REGISTER_READ  0
#define REGISTER_WRITE 1

//---------------------------------------------------------------------------
class ProcessThread : public TThread
{
private:
protected:
        void __fastcall Execute();
public:
    /*--- Log-related. ---*/
    char cLogBuff[8192];
    unsigned char log_msg_id;
    void /*__fastcall*/ LogOut(const char *string, ...);
    void __fastcall LogOut_Internal(void);

    /*--- Thread related. ---*/
    int iTerminateRequest;

    /*--- GUI related. ---*/
    int iThreadEndRequest;
    char app_path[MAX_PATH];
    UserData udGUI;
    /* Get GUI state from Unit1. */
    void __fastcall GetUserData(void);
    void __fastcall GetUserData_Internal(void);

    /* Clear button state (do after performing action associated to this button). */
    unsigned char _btn_clear_index;
    void __fastcall ClearButtonState(unsigned char btn);
    void __fastcall ClearButtonState_Internal(void);

    /* Send local UserData to Unit1's user data. */
    void __fastcall SetUserData(void);
    void __fastcall SetUserData_Internal(void);

    /* Buffer used to display local memory contents with disassembled opcodes. */
    unsigned char ucDisasmMem[2048];
    /* Send local MemView buffer to Unit1's user data. */
    void __fastcall RefreshMemViewData(void);
    void __fastcall RefreshMemViewData_Internal(void);
    /* Send Unit1's user data to local MemView buffer. */
    void __fastcall GetMemViewData(void);
    void __fastcall GetMemViewData_Internal(void);

    /* Set debug folder. */
    void __fastcall SetDebugFolder(void);


    /* Update silent log status. */
    void __fastcall UpdateSilentLogStatus(unsigned char s);
    void __fastcall UpdateSilentLogStatus_Internal(void);

    /* Update and display transfer status in status bar. */
    void __fastcall UpdateTransferStatus(bool bTransferOn);
    void __fastcall UpdateDebuggerStatus(bool bDebuggerOn);
    void __fastcall UpdatePromptStatus(bool bPromptOn);
    ULONG ulSendData;
    ULONG ulReceivedData;
    void __fastcall UpdateLinkStatus(void);
    void __fastcall UpdateTransferStatus_Internal(void);
    void __fastcall UpdateDeviceVersion(void);
    void __fastcall UpdateDeviceVersion_Internal(void);
    void __fastcall UpdateTransferSpeed(void);
    void __fastcall UpdateTransferSpeed_Internal(void);

    /* Extra stuff. */
    Graphics::TBitmap* pBmpVDP1;
    Graphics::TBitmap* pBmpRGB;
    void vdp1_view_init(void);
    void vdp1_view_end(void);

    void vdp1_view(void);
    void __fastcall DisplayVDP1_Internal(void);

    void rgb_view(unsigned long adr, unsigned long w, unsigned long h, unsigned char rcv);
    void __fastcall DisplayRGB_Internal(void);

    void target_info(void);

    /* Register Write stuff. */
    void register_convert(reg_convert_t* r);
    void register_process(int process_type, reg_convert_t* r);
    void register_macro_process(void);


    /*--- SatCom-related. ---*/
    SatCom* pSc;
    /* For internal usage (-> Debugger). */
    void __fastcall SC_OpenDevice(char* dev_name);
    void __fastcall SC_Set(char* name, char* value);
    void __fastcall SC_Receive(unsigned long address, unsigned long size, char* buffer);
    void __fastcall SC_Send(char* buffer, unsigned long size, unsigned long address, bool exec_flag);
    void __fastcall SC_Memset(unsigned long address, unsigned char val, unsigned long size);
    void __fastcall SC_GUI_Options(bool bProgressUse, bool bDebuggerUse);
    void __fastcall UpdateLogStatus_Internal(void);

    /* For User Interface usage. */
    void __fastcall print_help(char* filename);
    void __fastcall ParseCommandLine(void);
    void __fastcall SendData(char* file, unsigned long address, int exec_flag);
    void __fastcall SendDataExt(char* file, unsigned long address, int exec_flag, unsigned long softreset_flags);
    void __fastcall ReceiveData(char* file, unsigned long address, unsigned long length);

    /* Debugger-related */
    bool bDllOpen;

    scd_info_t* ptrDebuggerActivity;
    void __fastcall UpdateDebuggerActivity(scd_info_t* ptr);
    void __fastcall UpdateDebuggerActivity_Internal(void);

    void /*__fastcall*/ DbgOut(const char *string, ...);
    void __fastcall DbgOut_Internal(void);
    void /*__fastcall*/ DbgGridOut(unsigned char msg_id, const char *string, ...);
    void __fastcall DbgGridOut_Internal(void);

    void __fastcall ResetDebugger(void);
    void __fastcall ResetDebugger_Internal(void);
    void __fastcall DebuggerFileIO(
        unsigned char type, 
        unsigned long foffset, 
        unsigned long frw_address, 
        unsigned long frw_len, 
        char*         fname);
    void __fastcall LogDebuggerError(
        unsigned short rptr, unsigned short wptr, 
        unsigned char* data, unsigned long len, unsigned long data_offs, 
        char* str, int i);
public:
        __fastcall ProcessThread(bool CreateSuspended);
};
//---------------------------------------------------------------------------
#endif

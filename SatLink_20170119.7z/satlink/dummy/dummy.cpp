/* 
 * This software is licensed under terms of the GNU GENERAL PUBLIC LICENSE
 *
 * This software is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This software  is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this software.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Source code is available at http://ppcenter.free.fr
 */

#include "../common/satcom.h"
#include "sc_dummy.h"






////////////////////////////////////////////////////////////////////////
// Derived class functions
////////////////////////////////////////////////////////////////////////

#define DUMMY_FILE_STRLEN 1024
char _dummy_file[DUMMY_FILE_STRLEN];
unsigned long _dummy_file_offset = 0;
unsigned long _dummy_address = 0;



/**
 *  DLL startup : Display help screen.
**/
char SC_dummy::sc_start(void)
{
    scl_log(SCLT_DLLPG, 0, "[DUMMY]Start");

    memset((void*)_dummy_file, '\0', DUMMY_FILE_STRLEN);
    _dummy_file_offset = 0;
    _dummy_address = 0;

    return SC_NOERROR;
}

/**
 *  Set internal parameter.
**/
char SC_dummy::sc_set(char* parameter, char* value)
{
    scl_log(SCLT_DLLPG, 0, "[DUMMY]Set(%s, %s)", parameter, value);

    if(!stricmp(parameter, "file"))
    {
        strcpy(_dummy_file, value);
        scl_log(SCLT_DLLPG, 4, "Set file to %s", _dummy_file);
    }
    else if(!stricmp(parameter, "offset"))
    {
        _dummy_file_offset = strtoul(value, NULL, 0);
        scl_log(SCLT_DLLPG, 4, "Set file offset to %d (0x%08X)", _dummy_file_offset, _dummy_file_offset);
    }
    else if(!stricmp(parameter, "address"))
    {
        _dummy_address = strtoul(value, NULL, 0);
        scl_log(SCLT_DLLPG, 4, "Set address to 0x%08X (%d)", _dummy_address, _dummy_address);
    }


    return SC_NOERROR;
}

/**
 *  Close USB Data Link.
**/
char SC_dummy::sc_end(void)
{
    scl_log(SCLT_DLLPG, 0, "[DUMMY]End");
    return SC_NOERROR;
}





/**
 *  Receive data from Saturn.
**/
char SC_dummy::sc_receive(unsigned long address, unsigned char* buffer, unsigned long length)
{
    scl_log(SCLT_DLLPG, 0, "[DUMMY]Receive(adr=0x%08X, len=%d)", address, length);

    if(_dummy_file[0] == '\0')
    { /* Don't use file. */
        /* Simulates the download of data. */
        unsigned long psz = (8000*length)/442364;//8000;
        if(psz < 30) psz = 30;
        unsigned long p=0;
        STATUS_CALLBACK(CLBK_START, 0, buffer, 0, length);
        for(p=0; p<length; p++)
        {
            if(rand()%100 > 60)
            {
                buffer[p] = 'a' + rand()%('z' - 'a');
            }
            else if(rand()%100 > 60)
            {
                buffer[p] = 'A' + rand()%('Z' - 'A');
            }
            else
            {
                buffer[p] = '\0';
            }
        }
        for(p=0; p<length; p+=psz)
        {
            scl_log(SCLT_DLLPG, 9, " [RCV]p=%d", p);
            Sleep(80+(rand()%40));
            STATUS_CALLBACK(CLBK_RECEIVE, address, buffer, p, length);
        }
        STATUS_CALLBACK(CLBK_END, 0, buffer, length, length);
    }
    else
    { /* Read from dummy file. */
        FILE* fp;

        STATUS_CALLBACK(CLBK_START, 0, buffer, 0, length);
        memset((void*)buffer, 42, length);
        STATUS_CALLBACK(CLBK_RECEIVE, address, buffer, length/2, length);

        fp = fopen(_dummy_file, "rb");
        if(fp)
        {
            int o = (address & 0x0FFFFFFF) - ((_dummy_address & 0x0FFFFFFF) - _dummy_file_offset);
            fseek(fp, o, SEEK_SET);
            fread((void*)buffer, 1, length, fp);
            fclose(fp);
        }
        else
        {
            scl_log(SCLT_DLLPG, 0/*level*/, "[DUMMY]Can't open file \"%s\" for reading !", _dummy_file);
        }

        STATUS_CALLBACK(CLBK_END, 0, buffer, length, length);
    }

    return SC_NOERROR;
}




/**
 *  Send data to Saturn.
**/
char SC_dummy::sc_send(unsigned long address, unsigned char* buffer, unsigned long length, char exec_flag, unsigned long softreset_flags)
{
    scl_log(SCLT_DLLPG, 0, "[DUMMY]Send(adr=0x%08X, len=%d, exec=%d)", address, length, exec_flag);

    if(_dummy_file[0] == '\0')
    { /* Don't use file. */
        /* Simulates the upload of data. */
        unsigned long psz = 8000;
        unsigned long p=0;
        STATUS_CALLBACK(CLBK_START, 0, buffer, 0, length);
        for(p=0; p<length; p+=psz)
        {
            Sleep(80+(rand()%40));
            STATUS_CALLBACK(CLBK_SEND, address, buffer, p, length);
        }
        STATUS_CALLBACK(CLBK_END, 0, buffer, length, length);
    }
    else
    { /* Write to dummy file. */
        FILE* fp;

        STATUS_CALLBACK(CLBK_START, 0, buffer, 0, length);

        fp = fopen(_dummy_file, "r+");
        if(fp)
        {
            int o = (address & 0x0FFFFFFF) - ((_dummy_address & 0x0FFFFFFF) - _dummy_file_offset);
            STATUS_CALLBACK(CLBK_RECEIVE, address, buffer, length/2, length);
            fseek(fp, o, SEEK_SET);
            fwrite((void*)buffer, 1, length, fp);
            fclose(fp);
        }
        else
        {
            scl_log(SCLT_DLLPG, 0/*level*/, "[DUMMY]Can't open file \"%s\" for writing !", _dummy_file);
        }

        STATUS_CALLBACK(CLBK_END, 0, buffer, length, length);
    }

    return SC_NOERROR;
}



/**
 *  Return DLL version informations.
**/
char* SC_dummy::sc_version(void)
{
    sprintf(_version, (char*)("SatLink dummy/file device Ver. 0.2"));
    return _version;
}


/* 
 * This software is licensed under terms of the GNU GENERAL PUBLIC LICENSE
 *
 * This software is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This software  is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this software.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Source code is available at http://ppcenter.free.fr
 */

#include "../common/satcom.h"
#include "sc_usbdc.h"

/* Includes CRC used by USB dev cart and USBDC_FUNC_* definitions. */
#include "../../satcom_lib/sc_common.h"

/* Class to our FTDI chip. */
#include "ftdi_dll.h"
FtdiDll _ftdi;


////////////////////////////////////////////////////////////////////////
// Init/end/send\receive related functions.
// Note: grabbed source code from http://www.iki.fi/Anders.Montonen/sega/usbcart/
////////////////////////////////////////////////////////////////////////


/* Optimal payload/usb transfer size, see FTDI appnote */
#define USB_READPACKET_SIZE (64*1024)
#define USB_WRITEPACKET_SIZE (4*1024)
#define USB_PAYLOAD(x) ((x)-(((x)/64)*2))
#define READ_PAYLOAD_SIZE (USB_PAYLOAD(USB_READPACKET_SIZE))
#define WRITE_PAYLOAD_SIZE (USB_PAYLOAD(USB_WRITEPACKET_SIZE))

static unsigned char SendBuf[2*WRITE_PAYLOAD_SIZE];
static unsigned char RecvBuf[2*READ_PAYLOAD_SIZE];
static struct ftdi_context Device = {0};



static int DoDownload(unsigned int address, unsigned char* pFileBuffer, unsigned int size)
{
    unsigned int  received = 0;
    int           status = -1;
    unsigned char readChecksum, calcChecksum;

    STATUS_CALLBACK(CLBK_START, 0, pFileBuffer, 0, size);

    SendBuf[0] = USBDC_FUNC_DOWNLOAD; /* Client function */
    SendBuf[1] = (unsigned char)(address >> 24);
    SendBuf[2] = (unsigned char)(address >> 16);
    SendBuf[3] = (unsigned char)(address >> 8);
    SendBuf[4] = (unsigned char)(address);
    SendBuf[5] = (unsigned char)(size >> 24);
    SendBuf[6] = (unsigned char)(size >> 16);
    SendBuf[7] = (unsigned char)(size >> 8);
    SendBuf[8] = (unsigned char)(size);

    status = _ftdi.write_data(&Device, SendBuf, 9);
    if (status < 0)
    {
        scl_log(SCLT_DLLPG, 0, "Send download command error: %s", _ftdi.get_error_string(&Device));
        goto DownloadError;
    }

    while (size - received > 0)
    {
        STATUS_CALLBACK(CLBK_RECEIVE, address, pFileBuffer, received, size);

        status = _ftdi.read_data(&Device, &pFileBuffer[received], size);
        if (status < 0)
        {
            scl_log(SCLT_DLLPG, 0, "Read data error: %s", _ftdi.get_error_string(&Device));
            goto DownloadError;
        }

        received += status;
    }

    // The transfer may timeout, so loop until a byte
    // is received or an error occurs.
    do
    {
        status = _ftdi.read_data(&Device, (unsigned char*)&readChecksum, 1);
        if (status < 0)
        {
            scl_log(SCLT_DLLPG, 0, "Read data error: %s", _ftdi.get_error_string(&Device));
            goto DownloadError;
        }
    } while (status == 0);


    calcChecksum = crc_usbdc_init();
    calcChecksum = crc_usbdc_update(calcChecksum, pFileBuffer, size);
    calcChecksum = crc_usbdc_finalize(calcChecksum);

    if (readChecksum != calcChecksum)
    {
        scl_log(SCLT_DLLPG, 0, "Checksum error (0x%02x, should be 0x%02x) (address = 0x%08X)", calcChecksum, readChecksum, address);

        unsigned int dump_size, index, col;
        dump_size = (size > 256 ? 256 : size);
        for(index = 0; index < dump_size; index+=16)
        {
            char strDump[1024];
            strDump[0] = '\0';
            for(col = 0; col < 16; col++)
            {
                unsigned char val;
                char strTmp[16];
                if((index + col) < dump_size)
                {
                    sprintf(strTmp, "%02X ", pFileBuffer[index+col]);
                    strcat(strDump, strTmp);
                }
            }
            scl_log(SCLT_DLLPG, 0, " Dump[0x%02X]:%s", index, strDump);
        }

        status = -1;
        goto DownloadError;
    }


DownloadError:

    STATUS_CALLBACK(CLBK_END, 0, pFileBuffer, size, size);
    return status < 0 ? 0 : 1;
}

/* Sending the write command and data separately is inefficient,
   but simplifies the code. The alternative is to copy also the data
   into the sendbuffer. */
static int DoUpload(unsigned int Address, unsigned char* pFileBuffer, unsigned int size)
{
    unsigned int  sent = 0;
    int           status = 0;
    unsigned char checksum = crc_usbdc_init();

    STATUS_CALLBACK(CLBK_START, 0, pFileBuffer, 0, size);

    checksum = crc_usbdc_update(checksum, pFileBuffer, size);
    checksum = crc_usbdc_finalize(checksum);

    SendBuf[0] = USBDC_FUNC_UPLOAD; /* Client function */
    SendBuf[1] = (unsigned char)(Address >> 24);
    SendBuf[2] = (unsigned char)(Address >> 16);
    SendBuf[3] = (unsigned char)(Address >> 8);
    SendBuf[4] = (unsigned char)Address;
    SendBuf[5] = (unsigned char)(size >> 24);
    SendBuf[6] = (unsigned char)(size >> 16);
    SendBuf[7] = (unsigned char)(size >> 8);
    SendBuf[8] = (unsigned char)size;
    status = _ftdi.write_data(&Device, SendBuf, 9);

    if (status < 0)
    {
        scl_log(SCLT_DLLPG, 0, "Send upload command error: %s", _ftdi.get_error_string(&Device));
        goto UploadError;
    }

    while (size - sent > 0)
    {
        STATUS_CALLBACK(CLBK_SEND, Address, pFileBuffer, sent, size);

        status = _ftdi.write_data(&Device, &pFileBuffer[sent], size-sent);
        if (status < 0)
        {
            scl_log(SCLT_DLLPG, 0, "Send data error: %s", _ftdi.get_error_string(&Device));
            goto UploadError;
        }

        sent += status;
    }

    SendBuf[0] = (unsigned char)checksum;
    status = _ftdi.write_data(&Device, SendBuf, 1);

    if (status < 0)
    {
        scl_log(SCLT_DLLPG, 0, "Send checksum error: %s", _ftdi.get_error_string(&Device));
        goto UploadError;
    }

    do
    {
        status = _ftdi.read_data(&Device, RecvBuf, 1);
        if (status < 0)
        {
            scl_log(SCLT_DLLPG, 0, "Read upload result failed: %s", _ftdi.get_error_string(&Device));
            goto UploadError;
        }
    } while (status == 0);

    if (RecvBuf[0] != 0)
    {
        status = -1;
    }


UploadError:

    STATUS_CALLBACK(CLBK_END, 0, pFileBuffer, size, size);
    return status < 0 ? 0 : 1;
}

static int DoExecute(unsigned int Address)
{
    int status = 0;

    SendBuf[0] = USBDC_FUNC_EXEC; /* Client function */
    SendBuf[1] = (unsigned char)(Address >> 24);
    SendBuf[2] = (unsigned char)(Address >> 16);
    SendBuf[3] = (unsigned char)(Address >> 8);
    SendBuf[4] = (unsigned char)Address;
    status = _ftdi.write_data(&Device, SendBuf, 5);
    if (status < 0)
    {
        scl_log(SCLT_DLLPG, 0, "Send execute error: %s", _ftdi.get_error_string(&Device));
    }

    return status < 0 ? 0 : 1;
}

static int DoGetBufferAddress(unsigned long* upload_address)
{
    unsigned char data[4];
    unsigned char* pFileBuffer = data;
    unsigned long size = 4;
    unsigned int  received = 0;
    int           status = -1;
    unsigned char readChecksum, calcChecksum;

    *upload_address = 0;
    SendBuf[0] = USBDC_FUNC_GET_BUFF_ADDR; /* Client function */

    status = _ftdi.write_data(&Device, SendBuf, 1);
    if (status < 0)
    {
        scl_log(SCLT_DLLPG, 0, "Send download command error: %s", _ftdi.get_error_string(&Device));
        goto GetBufferAddressError;
    }

    while (size - received > 0)
    {
        status = _ftdi.read_data(&Device, &pFileBuffer[received], size);
        if (status < 0)
        {
            scl_log(SCLT_DLLPG, 0, "Read data error: %s", _ftdi.get_error_string(&Device));
            goto GetBufferAddressError;
        }

        received += status;
    }

    *upload_address  = data[0] << 24;
    *upload_address |= data[1] << 16;
    *upload_address |= data[2] <<  8;
    *upload_address |= data[3] <<  0;
    scl_log(SCLT_DLLPG, 1, "upload_address = 0x%08X", *upload_address);

GetBufferAddressError:

    return status < 0 ? 0 : 1;
}


static int DoCopyExecute(unsigned long upload_address, unsigned long length, unsigned long address)
{
    int status = 0;

    SendBuf[ 0] = USBDC_FUNC_COPYEXEC; /* Client function */

    SendBuf[ 1] = (unsigned char)(upload_address >> 24);
    SendBuf[ 2] = (unsigned char)(upload_address >> 16);
    SendBuf[ 3] = (unsigned char)(upload_address >> 8);
    SendBuf[ 4] = (unsigned char)upload_address;

    SendBuf[ 5] = (unsigned char)(length >> 24);
    SendBuf[ 6] = (unsigned char)(length >> 16);
    SendBuf[ 7] = (unsigned char)(length >> 8);
    SendBuf[ 8] = (unsigned char)length;

    SendBuf[ 9] = (unsigned char)(address >> 24);
    SendBuf[10] = (unsigned char)(address >> 16);
    SendBuf[11] = (unsigned char)(address >> 8);
    SendBuf[12] = (unsigned char)address;

    status = _ftdi.write_data(&Device, SendBuf, 13);
    if (status < 0)
    {
        scl_log(SCLT_DLLPG, 0, "Send copy&execute error: %s", _ftdi.get_error_string(&Device));
    }

    return status < 0 ? 0 : 1;
}



/* Sending the write command and data separately is inefficient,
   but simplifies the code. The alternative is to copy also the data
   into the sendbuffer. */
static int DoExecExt(unsigned int Address, unsigned char* pFileBuffer, unsigned int size, unsigned long softreset_flags)
{
    unsigned int  sent = 0;
    int           status = 0;
    unsigned char checksum = crc_usbdc_init();

    STATUS_CALLBACK(CLBK_START, 0, pFileBuffer, 0, size);

    checksum = crc_usbdc_update(checksum, pFileBuffer, size);
    checksum = crc_usbdc_finalize(checksum);

    SendBuf[ 0] = USBDC_FUNC_EXEC_EXT; /* Client function */
    SendBuf[ 1] = (unsigned char)(Address >> 24);
    SendBuf[ 2] = (unsigned char)(Address >> 16);
    SendBuf[ 3] = (unsigned char)(Address >> 8);
    SendBuf[ 4] = (unsigned char)Address;
    SendBuf[ 5] = (unsigned char)(size >> 24);
    SendBuf[ 6] = (unsigned char)(size >> 16);
    SendBuf[ 7] = (unsigned char)(size >> 8);
    SendBuf[ 8] = (unsigned char)size;
    SendBuf[ 9] = (unsigned char)(softreset_flags >> 24);
    SendBuf[10] = (unsigned char)(softreset_flags >> 16);
    SendBuf[11] = (unsigned char)(softreset_flags >> 8);
    SendBuf[12] = (unsigned char)softreset_flags;
    status = _ftdi.write_data(&Device, SendBuf, 13);

    if (status < 0)
    {
        scl_log(SCLT_DLLPG, 0, "Send ExecExt command error: %s", _ftdi.get_error_string(&Device));
        goto ExecExtError;
    }

    while (size - sent > 0)
    {
        STATUS_CALLBACK(CLBK_SEND, Address, pFileBuffer, sent, size);

        status = _ftdi.write_data(&Device, &pFileBuffer[sent], size-sent);
        if (status < 0)
        {
            scl_log(SCLT_DLLPG, 0, "Send data error: %s", _ftdi.get_error_string(&Device));
            goto ExecExtError;
        }

        sent += status;
    }

    SendBuf[0] = (unsigned char)checksum;
    status = _ftdi.write_data(&Device, SendBuf, 1);

    if (status < 0)
    {
        scl_log(SCLT_DLLPG, 0, "Send checksum error: %s", _ftdi.get_error_string(&Device));
        goto ExecExtError;
    }

    do
    {
        status = _ftdi.read_data(&Device, RecvBuf, 1);
        if (status < 0)
        {
            scl_log(SCLT_DLLPG, 0, "Read ExecExt result failed: %s", _ftdi.get_error_string(&Device));
            goto ExecExtError;
        }
    } while (status == 0);

    if (RecvBuf[0] != 0)
    {
        status = -1;
    }


ExecExtError:

    STATUS_CALLBACK(CLBK_END, 0, pFileBuffer, size, size);
    return status < 0 ? 0 : 1;
}




static int InitComms(int VID, int PID)
{
    int status = _ftdi.init(&Device);
    int error = 0;

    if (status < 0)
    {
        scl_log(SCLT_DLLPG, 0, "Init error: %s", _ftdi.get_error_string(&Device));
        error = 1;
    }
    else
    {
        status = _ftdi.usb_open(&Device, VID, PID);
        if (status < 0 && status != -5)
        {
            scl_log(SCLT_DLLPG, 0, "Device open error: %s", _ftdi.get_error_string(&Device));
            error = 1;
        }
        else
        {
            status = _ftdi.usb_purge_buffers(&Device);
            if (status < 0)
            {
                scl_log(SCLT_DLLPG, 0, "Purge buffers error: %s", _ftdi.get_error_string(&Device));
                error = 1;
            }

            status = _ftdi.read_data_set_chunksize(&Device, USB_READPACKET_SIZE);
            if (status < 0)
            {
                scl_log(SCLT_DLLPG, 0, "Set read chunksize error: %s", _ftdi.get_error_string(&Device));
                error = 1;
            }

            status = _ftdi.write_data_set_chunksize(&Device, USB_WRITEPACKET_SIZE);
            if (status < 0)
            {
                scl_log(SCLT_DLLPG, 0, "Set write chunksize error: %s", _ftdi.get_error_string(&Device));
                error = 1;
            }

            status = _ftdi.set_bitmode(&Device, 0x0, BITMODE_RESET);
            if (status < 0)
            {
                scl_log(SCLT_DLLPG, 0, "Bitmode configuration error: %s", _ftdi.get_error_string(&Device));
                error = 1;
            }

            if (error)
            {
                _ftdi.usb_close(&Device);
            }
        }
    }

    return !error;
}

static void CloseComms(void)
{
    int status = _ftdi.usb_purge_buffers(&Device);
    if (status < 0)
    {
        scl_log(SCLT_DLLPG, 0, "Purge buffers error: %s", _ftdi.get_error_string(&Device));
    }

    _ftdi.usb_close(&Device);
}






////////////////////////////////////////////////////////////////////////
// Derived class functions
////////////////////////////////////////////////////////////////////////

int _vid = 0x0403;
int _pid = 0x6001;



/**
 *  DLL startup : Display help screen.
**/
char SC_usbdc::sc_start(void)
{
    /* Set default settings. */
    _vid = 0x0403;
    _pid = 0x6001;


    /* Display help screen. */
    scl_log(SCLT_DLLPG, 4, "USB dev cart interface.");
    scl_log(SCLT_DLLPG, 4, " From http://www.iki.fi/Anders.Montonen/sega/usbcart/");
    scl_log(SCLT_DLLPG, 4, "Available parameters :");
    scl_log(SCLT_DLLPG, 4, " v          <VID> : Set device VID (Default 0x%04X).", _vid);
    scl_log(SCLT_DLLPG, 4, " p          <PID> : Set device PID (Default 0x%04X).", _pid);
    scl_log(SCLT_DLLPG, 4, " smart_exec <0/1> : Turn off/on smart exec.");
    scl_log(SCLT_DLLPG, 4, " display    <1>   : Display configuration settings.");
    scl_log(SCLT_DLLPG, 4, " init       <1>   : Init USB device.");
    

    if(_ftdi.is_dll_opened() != 1)
    {
        scl_log(SCLT_DLLPG, 0, "Error: couldn't open libftdi.dll");
        return SC_ERROR_PORT;
    }

    return SC_NOERROR;
}

/**
 *  Set internal parameter.
**/
char SC_usbdc::sc_set(char* parameter, char* value)
{
    int err = SC_NOERROR;
    int ret = 0;

    if(_ftdi.is_dll_opened() != 1)
    {
        scl_log(SCLT_DLLPG, 0, "Error: couldn't open libftdi.dll");
        return SC_ERROR_PORT;
    }

    /* Parse parameters. */
    //scl_log(SCLT_DLLPG, 9, "param = %s", parameter);
    if(!stricmp(parameter, "v"))
    {
        _vid = strtoul(value, NULL, 0);
        scl_log(SCLT_DLLPG, 4, "Set VID 0x%04X", _vid);
    }
    else if(!stricmp(parameter, "p"))
    {
        _pid = strtoul(value, NULL, 0);
        scl_log(SCLT_DLLPG, 4, "Set PID 0x%04X", _pid);
    }
    else if(!stricmp(parameter, "smart_exec"))
    {
        scl_log(SCLT_DLLPG, 4, "smart_exec value (%s) ignored.", strtoul(value, NULL, 0));
    }
    else if(!stricmp(parameter, "display"))
    {
        /* Display parameters contents to log. */
        scl_log(SCLT_DLLPG, 1, "USB dev cart internal settings");
        scl_log(SCLT_DLLPG, 1, "|VID        : 0x%04X", _vid);
        scl_log(SCLT_DLLPG, 1, "|PID        : 0x%04X", _pid);
    }
    else if(!stricmp(parameter, "init"))
    {
        /* Initialize device. */
        scl_log(SCLT_DLLPG, 1, "USB dev cart init ...");
        ret = InitComms(_vid, _pid);
        scl_log(SCLT_DLLPG, 1, "USB dev cart init = %d", ret);
    }
    else
    {
        scl_log(SCLT_DLLPG, 0, "ERROR: Unknown parameter : \"%s\"", parameter);
        return SC_ERROR_PARAMETER;
    }

    return SC_NOERROR;
}

/**
 *  Close USB dev cart.
**/
char SC_usbdc::sc_end(void)
{
    if(_ftdi.is_dll_opened() != 1)
    {
        scl_log(SCLT_DLLPG, 0, "Error: couldn't open libftdi.dll");
        return SC_ERROR_PORT;
    }

    scl_log(SCLT_DLLPG, 4, "Close USB dev cart connection ...");
    CloseComms();

    return SC_NOERROR;
}





/**
 *  Receive data from Saturn.
**/
char SC_usbdc::sc_receive(unsigned long address, unsigned char* buffer, unsigned long length)
{
    int ret = 0;

    if(_ftdi.is_dll_opened() != 1)
    {
        scl_log(SCLT_DLLPG, 0, "Error: couldn't open libftdi.dll");
        return SC_ERROR_PORT;
    }

    ret = DoDownload(address, buffer, length);
    scl_log(SCLT_DLLPG, 1, "DoDownload = %d", ret);

    return SC_NOERROR;
}




/**
 *  Send data to Saturn.
**/
char SC_usbdc::sc_send(unsigned long address, unsigned char* buffer, unsigned long length, char exec_flag, unsigned long softreset_flags)
{
    int ret = 0;

    if(_ftdi.is_dll_opened() != 1)
    {
        scl_log(SCLT_DLLPG, 0, "Error: couldn't open libftdi.dll");
        return SC_ERROR_PORT;
    }

    if(exec_flag)
    {
        /* Retrieve firmware version in order to check
         * if can use ExecExt function or not.
         */
        unsigned char firm_info[USBDC_VERSION_LEN];
        int ext_exec;

        memset((void*)firm_info, 0, USBDC_VERSION_LEN);
        ret = DoDownload(USBDC_VERSION_ADR, firm_info, USBDC_VERSION_LEN);
        scl_log(SCLT_DLLPG, 0, "Firmware Version = 0x%02X (%d)", firm_info[0], ret);
        if(firm_info[0] == 0x31)
        {
            ext_exec = 1;
            scl_log(SCLT_DLLPG, 0, " -> will use ExecExt function");
        }
        else
        {
            ext_exec = 0;
            scl_log(SCLT_DLLPG, 0, " -> will use Upload then Execute functions");
        }

        if(ext_exec)
        {
            ret = DoExecExt(address, buffer, length, softreset_flags);
            scl_log(SCLT_DLLPG, 1, "DoExecExt(address=0x%08X, buffer, length=%d, reset=0x%08X) = %d", address, length, softreset_flags, ret);
        }
        else
        {
            ret = DoUpload(address, buffer, length);
            scl_log(SCLT_DLLPG, 1, "DoUpload(address=0x%08X, buffer, length=%d) = %d", address, length, ret);

            DoExecute(address);
            scl_log(SCLT_DLLPG, 1, "DoExecute(address=0x%08X)", address);
        }
    }
    else
    {
        /* Data upload */
        ret = DoUpload(address, buffer, length);
        scl_log(SCLT_DLLPG, 1, "DoUpload(address=0x%08X, buffer, length=%d) = %d", address, length, ret);
    }

    return SC_NOERROR;
}



/**
 *  Return DLL version informations.
**/
char* SC_usbdc::sc_version(void)
{
    if(_ftdi.is_dll_opened() != 1)
    {
        sprintf(_version, (char*)("Saturn USB dev cart (FTDI) interface. <NO DLL>"));
    }
    else
    {
        char* error_string = _ftdi.get_error_string(&Device);
        sprintf(_version, (char*)("Saturn USB dev cart (FTDI) interface Ver. 0.3"));
        if(error_string != NULL)
        {
            strcat(_version, " [");
            strcat(_version, error_string);
            strcat(_version, "]");
        }
    }

    return _version;
}


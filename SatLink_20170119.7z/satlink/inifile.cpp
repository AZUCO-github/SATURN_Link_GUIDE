#include "inifile.h"
#include <stdio.h>
#include <string.h>


void parse_satlink_inifile(char* inifilebuffer, char* filename, int* argc, char** argv)
{
    int i, j;

    FILE *fp;
    fp = fopen(filename,"rb");
    if(fp)
    { /* The first parameter is a path to an ini file. */
        int len;
        memset((void*)inifilebuffer, '\0', INIFILE_MAXSIZE);
        len = fread(inifilebuffer, 1, INIFILE_MAXSIZE, fp);
        fclose(fp); //fp = NULL;
        inifilebuffer[INIFILE_MAXSIZE-1] = '\0';

        /* If needed, append first line to argv. */
        if((inifilebuffer[0] > ' ') && (inifilebuffer[0] != '#'))
        {
            argv[(*argc)] = inifilebuffer; (*argc)++;
        }
        for(i=0; i<(len-2); i++)
        {
            /* If found, append command. */
            if((inifilebuffer[i  ] < ' ')
            && (inifilebuffer[i+1] > ' '))
            {
                /* Ignore comments */
                if(inifilebuffer[i+1] != '#')
                {
                    argv[(*argc)] = inifilebuffer + i+1; (*argc)++;
                }
            }
            /* Remove non displayable characters. */
            if(inifilebuffer[i] < ' ') inifilebuffer[i] = '\0';
        }
        /* Remove non displayable characters. */
        j=i;
        for(i=j; i<len; i++)
        {
            if(inifilebuffer[i] < ' ') inifilebuffer[i] = '\0';
        }
    }
}



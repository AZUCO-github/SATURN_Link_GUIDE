/* 
 * This software is licensed under terms of the GNU GENERAL PUBLIC LICENSE
 *
 * This software is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This software  is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this software.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Source code is available at http://ppcenter.free.fr
 */

#include "sc_ylink.h"

/* Vpar wrapper functions and global data definitions.
 * Remark : VPar includes both :
 *  - Yabause Link, used here only
 * and
 *  - Yabause Shared Memory, used in several places in SatLink
 * Hence, initialization/release of VPar DLL wrapper is done on SatLink side.
 */
VPAR_WRAPPER_GLOBAL_LOG_DECLARATIONS();
VPAR_WRAPPER_GLOBAL_MAIN_DECLARATIONS();

/* Local copy of I/O data from shared memory. */
vpar_io_t _ylink_io[2];


/* Maximum loop count when waiting for data from Yabause. */
unsigned long _ylink_loop_max = 10000;

/* Indicate if Vpar DLL could be init or not. */
int _vpar_init = 0;

/* Indicate if Yabause Link is in use or not. */
int _ylink_in_use = 0;


/**
 *  DLL startup : display help screen and initialize Vpar DLL.
**/
char SC_ylink::sc_start(void)
{
    /* Display help screen. */
    scl_log(SCLT_DLLPG, 2, "Yabause link interface.");
    scl_log(SCLT_DLLPG, 2, "Available parameters :");
    scl_log(SCLT_DLLPG, 2, " loop_max <value> : Max loop count when polling data.");
    scl_log(SCLT_DLLPG, 2, " display  <1    > : Display the parameters current values.");

    /* Indicate Yabause Link is use, if DLL could be opened. */
    _ylink_in_use = _vpar_init;

    return(_ylink_in_use ? SC_NOERROR : SC_ERROR_PNOTOPEN);
}

char SC_ylink::sc_set(char* parameter, char* value)
{
    /* Parse parameters. */
    //scl_log(SCLT_DLLPG, 9, "param = %s", parameter);
    if(!stricmp(parameter, "loop_max"))
    {
        _ylink_loop_max = strtoul(value, NULL, 0);
    }
    else if(!stricmp(parameter, "display"))
    {
        scl_log(SCLT_DLLPG, 1, "loop_max = %u", _ylink_loop_max);
    }
    else
    {
        scl_log(SCLT_DLLPG, 0, "ERROR: Unknown parameter : \"%s\"", parameter);
        return SC_ERROR_PARAMETER;
    }

    return SC_NOERROR;
}


/**
 *  Release Vpar DLL.
**/
char SC_ylink::sc_end(void)
{
    _ylink_in_use = 0;

    return SC_NOERROR;
}



/**
 * Return DLL version informations.
**/
char* SC_ylink::sc_version(void)
{
    sprintf(_version, (char*)("Yabause Link Ver. 0.1"));
    return _version;
}



/**
 * Receive data from Saturn.
 * Returns :
 *    SC_NOERROR        = No error.
 *    SC_ERROR_PNOTOPEN = Yabause Link DLL (VPar) open failure.
 *    SC_ERROR_TIMEOUT  = Timeout while polling data from Yabause.
**/
char SC_ylink::sc_receive(unsigned long address, unsigned char* buffer, unsigned long length)
{
    if(!_vpar_init) return SC_ERROR_PNOTOPEN;

    int i, error = SC_NOERROR;

    /* Transfer-related internal variables. */
    unsigned long p   = 0;
    unsigned long psz = VPAR_IO_LENGTH;

    /* Indicates that the process started. */
    STATUS_CALLBACK(CLBK_START, 0, buffer, 0, length);

    /* Receive data little by little (VPAR_IO_LENGTH bytes). */
    for(p=0; p<length; p+=psz)
    {
        unsigned long l = ((length-p) < psz ? length-p : psz);
        STATUS_CALLBACK(CLBK_RECEIVE, address, buffer, p, length);

        scl_log(SCLT_DLLPG, 5, "[sc_receive]receive loop: length=%d, psz=%d, p=%d, l=%d", length, psz, p, l);

        vpar_io_t* io_satlink = &(_ylink_io[IO_SATLINK_ID]);
        vpar_io_t* io_yabause = &(_ylink_io[IO_YABAUSE_ID]);

        /* Setup data read parameters in shared memory. */
        VparGetIo(IO_SATLINK_ID, io_satlink);

        io_satlink->address    = address+p;
        io_satlink->length     = l;
        io_satlink->write_flag = 0;
        io_satlink->exec_flag  = 0;
        io_satlink->update_counter++;

        /* Get initial Yabause I/O update counter. */
        VparGetIo(IO_YABAUSE_ID, io_yabause);
        unsigned char yabause_update_counter = io_yabause->update_counter;

        /* Send request to Yabause. */
        VparSetIo(IO_SATLINK_ID, io_satlink);

        /* Wait until Yabause bumps update counter. */
        for(i=0; i<_ylink_loop_max; i++)
        {
            VparGetIo(IO_YABAUSE_ID, io_yabause);
            if(yabause_update_counter != io_yabause->update_counter)
            {
                break;
            }

            if(i == (_ylink_loop_max-1))
            {
                error = SC_ERROR_TIMEOUT;
                scl_log(SCLT_DLLPG, 0, "[sc_receive]Yabause Link timeout error ! (yabause not running ?)");
            }

            /* Periodically check if user wants to abort transfer. */
            if((i % 101) == 0)
            {
                if(AbortRequested())
                {
                    return SC_ERROR_ABORTED;
                }
            }
        }
        if(error != SC_NOERROR) break;

        /* Copy received data to output buffer. */
        memcpy(buffer+p, io_yabause->data, l);
    }

receive_end:
    /* Indicates that the process ended */
    STATUS_CALLBACK(CLBK_END, 0, buffer, length, length);

    return error;
}







/**
 * Send data to Saturn.
 * Returns :
 *    SC_NOERROR        = No error.
 *    SC_ERROR_PNOTOPEN = Yabause Link DLL (VPar) open failure.
 *    SC_ERROR_TIMEOUT  = Timeout while polling data from Yabause.
**/
char SC_ylink::sc_send(unsigned long address, unsigned char* buffer, unsigned long length, char exec_flag, unsigned long softreset_flags)
{
    if(!_vpar_init) return SC_ERROR_PNOTOPEN;

    int i, error = SC_NOERROR;

    /* Transfer-related internal variables. */
    unsigned long p   = 0;
    unsigned long psz = VPAR_IO_LENGTH;
    vpar_io_t* io_satlink = &(_ylink_io[IO_SATLINK_ID]);
    vpar_io_t* io_yabause = &(_ylink_io[IO_YABAUSE_ID]);
    unsigned char yabause_update_counter;

    /* Indicates that the process started. */
    STATUS_CALLBACK(CLBK_START, 0, buffer, 0, length);

    /* Send data little by little (VPAR_IO_LENGTH bytes). */
    for(p=0; p<length; p+=psz)
    {
        unsigned long l = ((length-p) < psz ? length-p : psz);

        STATUS_CALLBACK(CLBK_SEND, address, buffer, p, length);

        scl_log(SCLT_DLLPG, 5, "[sc_send]send loop: length=%d, psz=%d, p=%d, l=%d", length, psz, p, l);

        /* Setup data write parameters in shared memory. */
        VparGetIo(IO_SATLINK_ID, io_satlink);

        io_satlink->address    = address+p;
        io_satlink->length     = l;
        io_satlink->write_flag = 1;
        io_satlink->exec_flag  = 0;
        memcpy(io_satlink->data, buffer+p, io_satlink->length);
        io_satlink->update_counter++;

        /* Get initial Yabause I/O update counter. */
        VparGetIo(IO_YABAUSE_ID, io_yabause);
        yabause_update_counter = io_yabause->update_counter;

        /* Send request to Yabause. */
        VparSetIo(IO_SATLINK_ID, io_satlink);

        /* Wait until Yabause bumps update counter. */
        for(i=0; i<_ylink_loop_max; i++)
        {
            VparGetIo(IO_YABAUSE_ID, io_yabause);
            if(yabause_update_counter != io_yabause->update_counter)
            {
                break;
            }

            if(i == (_ylink_loop_max-1))
            {
                error = SC_ERROR_TIMEOUT;
                scl_log(SCLT_DLLPG, 0, "[sc_send]Yabause Link timeout error ! (yabause not running ?)");
            }

            /* Periodically check if user wants to abort transfer. */
            if((i % 101) == 0)
            {
                if(AbortRequested())
                {
                    return SC_ERROR_ABORTED;
                }
            }
        }
        if(error != SC_NOERROR) break;
    }

    /** If load-execute flag is set, re-send first packet with execute flag set. **/
    if(exec_flag)
    {
        scl_log(SCLT_DLLPG, 5, "[sc_send]Send first packet with exec flag set (softreset_flags=0x%08X)", softreset_flags);
        io_satlink->address    = address;
        io_satlink->length     = (length < psz ? length : psz);
        io_satlink->write_flag = 1;
        io_satlink->exec_flag  = 1;
        io_satlink->softreset_flags = softreset_flags;
        memcpy(io_satlink->data, buffer, io_satlink->length);
        io_satlink->update_counter++;

        /* Get initial Yabause I/O update counter. */
        VparGetIo(IO_YABAUSE_ID, io_yabause);
        yabause_update_counter = io_yabause->update_counter;

        /* Send request to Yabause. */
        VparSetIo(IO_SATLINK_ID, io_satlink);

        /* Wait until Yabause bumps update counter. */
        for(i=0; i<_ylink_loop_max; i++)
        {
            VparGetIo(IO_YABAUSE_ID, io_yabause);
            if(yabause_update_counter != io_yabause->update_counter)
            {
                break;
            }

            if(i == (_ylink_loop_max-1))
            {
                error = SC_ERROR_TIMEOUT;
                scl_log(SCLT_DLLPG, 0, "[sc_send]Yabause Link timeout error ! (yabause not running ?)");
            }
        }
    }

send_end:
    /* Indicates that the process ended */
    STATUS_CALLBACK(CLBK_END, 0, buffer, length, length);

    return error;
}



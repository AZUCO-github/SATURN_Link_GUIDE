#ifndef __IASM_H__
#define __IASM_H__

#ifdef  __cplusplus
extern "C" {
#endif

int iasm(char *str);

#ifdef  __cplusplus
}
#endif

#endif


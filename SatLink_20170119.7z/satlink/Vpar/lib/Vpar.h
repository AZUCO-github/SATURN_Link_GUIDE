// definition of exported functions

#ifndef _INCLUDE_VPAR_H_
#define _INCLUDE_VPAR_H_

#ifdef  __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <string.h>
#include <stdarg.h>

/**
 * Virtual LPT port DLL for yabause.
 * Simulates PC'sparallel port <-> ARP's Comms port access between Yabause and SatLink.
 *
 * References used:
 *   http://msdn.microsoft.com/en-us/library/windows/desktop/ms686958%28v=vs.85%29.aspx
 *   http://stackoverflow.com/questions/4579640/dll-mutex-an-example
 *   http://msdn.microsoft.com/en-us/library/windows/desktop/ms682411%28v=vs.85%29.aspx
 *   http://msdn.microsoft.com/en-us/library/windows/desktop/aa382954%28v=vs.85%29.aspx
 *   http://tweakbits.com/articles/dll/index.html
**/


/**
 * Vpar #define switches.
 *
 * In order to make this header working for both DLL/Yabause/SatLink, 
 * it is necessary to #define one of the switch below :
 *
 *  - VPAR_DLL_BUILD     : when included in Vpar DLL itself.
 *  - VPAR_SATLINK_BUILD : when included in SatLink.
 *  - VPAR_YABAUSE_BUILD : when included in Yabause.
**/
#ifdef VPAR_DLL_BUILD
#   define VPAR_DLLEXPORT __declspec(dllexport)
#endif

#ifdef VPAR_SATLINK_BUILD
#   define VPAR_DLLEXPORT 
#endif

#ifdef VPAR_YABAUSE_BUILD
#   define VPAR_DLLEXPORT 
#endif



/**
 * Definition of DLL file name.
 * SatLink can only use 32 bits DLL, and Yabause may require 64 bits DLL, 
 * hence both 32/64 bits builds of the DLL are provided, and "_x64" suffix
 * is appended to file name of DLL for 64 bits platform.
**/
#ifdef _WIN64
#   define VPAR_FILE_NAME "Vpar_x64.dll"
#else
#   define VPAR_FILE_NAME "Vpar.dll"
#endif



/**
 * Whole shared memory data contents.
 *
 * vpar_shared_memory_t structure contains whole shared memory structure, 
 * which is created and managed by Vpar DLL, and shared between SatLink and Yabause.
 *
 * Brief description of shared memory structure contents :
 * +==========+==================+===========================================================+
 * | Set By   | Name             | Description                                               |
 * +==========+==================+===========================================================+
 * | DLL      |                  | DLL status, access statistics, etc                        |
 * +- - - - - +- - - - - - - - - +- - - - - - - - - - - - - - - - - - - - - - - - - - - - - -+
 * | Yabause  |                  | Yabause -> SatLink I/O                                    |
 * +- - - - - +- - - - - - - - - +- - - - - - - - - - - - - - - - - - - - - - - - - - - - - -+
 * | SatLink  |                  | SatLink -> Yabause I/O                                    |
 * +- - - - - +- - - - - - - - - +- - - - - - - - - - - - - - - - - - - - - - - - - - - - - -+
 * | Yabause  |                  | Yabause emulation/etc status                              |
 * |          |                  |  + log                                                    |
 * |          |                  |  + SH2  (should separate for each core ?)                 |
 * |          |                  |  + VDP1                                                   |
 * |          |                  |  + VDP2                                                   |
 * +- - - - - +- - - - - - - - - +- - - - - - - - - - - - - - - - - - - - - - - - - - - - - -+
 * | SatLink  |                  | Emulation/Debug/etc settings                              |
 * |          |                  |  + log settings                                           |
 * +- - - - - +- - - - - - - - - +- - - - - - - - - - - - - - - - - - - - - - - - - - - - - -+
 * | SatLink  |                  | Break point settings                                      |
 * +==========+==================+===========================================================+
**/


/**
 * Mutex list definitions.
 *
 * In order to get safe, fast and concurrent access of shared
 * memory, 32 mutexes are provided on Vpar DLL side.
 *
 * Shared memory access is controlled as follow :
 *  - One mutex for link related access.
 *  - One mutex for other structures access.
 *  - All mutexes for dump access.
**/
#define SHRDMEM_MUTEX_COUNT (sizeof(unsigned long) * 8)
#define VPAR_MTX_COMMON (1 << 0)
#define VPAR_MTX_LINK   (1 << 1)
#define VPAR_MTX_ALL    (0xFFFFFFFF)


// GCC have alternative #pragma pack(N) syntax and old gcc version not
// support pack(push,N), also any gcc version not support it at some platform
#if defined( __GNUC__ )
#pragma pack(1)
#else
#pragma pack(push,1)
#endif


/* Vpar statistics structure definition. */
typedef struct _vpar_stats_t
{
    /* Mutex error count. */
    unsigned long error_cnt;

    /* Read/write access count. */
    unsigned long read_cnt, write_cnt;

    /* Data count dead/writen so far. */
    unsigned long read_size, write_size;

    /* Pack structure size to fixed size (32 bytes). */
    unsigned char padding[32 - sizeof(unsigned long)*5];
} vpar_stats_t;




/* Character count (including terminating null one) in strings. */
#define VPAR_STRLEN 128

/*
 * Yabause <-> SatLink I/O structure.
 *
 * Two I/O structures are defined in shared
 * memory : one set by SatLink, and another one set by Yabause.
 *
 * How it works :
 *  1. Yabause regularly polls SatLink's I/O structure.
 *  2. If update counter in SatLink's I/O structure have changed, I/O request is processed by yabause.
 *   - I/O request can be memory read or memory write and is specified in SatLink's I/O structure.
 *  4. SatLink polls for Yabause's I/O structure until update counter changes.
 *  3. Result of I/O request (read data contents, update counter, etc) is set on shared memory by yabause.
 *  - Transfers larger than VPAR_IO_LENGTH are split in several times.
 *    In that case, first packet is sent last when data execution is requested.
 *
 */
#define VPAR_IO_LENGTH (4*1024)
typedef struct _vpar_io_t
{
    /* Incremented when owner updated data in this structure. */
    unsigned char update_counter;
    /* Padding byte. */
    unsigned char padding1[1];

    /* 0:data read, 1:data write. */
    unsigned char write_flag;

    /* Code execution flag. */
    unsigned char exec_flag;

    /* Indicates how far soft reset needs to be
     * processed before executing data.
     * This information is ignored when exec_flag is not set.
     */
    unsigned long softreset_flags;

    /* Address/Length informations. */
    unsigned long address;
    unsigned long length;

    /* IO_SATLINK_ID : buffer containing written by SatLink.
     * IO_YABAUSE_ID : buffer containing data read from Yabause.
     */
    unsigned char data[VPAR_IO_LENGTH];
} vpar_io_t;


/**
 * Asynchronous breakpoint structure related definitions.
 *
 * Similar to yabause's SH2 emulator code/data breakpoint feature, but with the
 * differences/improvements below :
 *  - Asynchronous : when triggered, only output log message, and continue emulation
 *  - Allow advanced breakpoint settings : data contents, address/data mask.
 *
 * Note : this feature seems best implemented in Yabause's SH2HandleBreakpoints function.
 *
 * List of breakpoint types available :
 *  - VPAR_BP_CODE :
 *    Break when code is executed at a specific address.
 *
 *  - VPAR_BP_ADDRESS :
 *    Break when data is accessed (read or written) at a specific address.
 *
 *  - VPAR_BP_VALUE :
 *    Break when a specific value is accessed (read or written) from memory.
 *    Additionally, it is possible to specify address where to enable the breakpoint.
 *
 * In all cases, address and value can be masked, allowing some
 * (relative) flexibility in breakpoint setting.
 * Examples :
 *  - "06004000" address: 0x06004000 address only.
 *  - "060040XX" address: all 256 bytes from 0x06004000 address.
**/

/* Maximum breakpoint count. */
#define VPAR_BP_COUNT 32

/* Breakpoint types. */
#define VPAR_BPT_DISABLED 0
#define VPAR_BPT_CODE     1
#define VPAR_BPT_ADDRESS  2
#define VPAR_BPT_VALUE    3
#define VPAR_BPT_COUNT (VPAR_BPT_VALUE + 1)

typedef struct _vpar_bp_entry
{
    /* Breakpoint type (VPAR_BP_*). */
    unsigned char type;

    /* 0: don't check address, 1: check address.
     * Used only in "value" breakpoint.
     */
    unsigned char address_check;

    /* Padding bytes. */
    unsigned char padding1[2];

    /*
     * Breakpoint name, useful when using many breakpoints
     * at once in order to verify which one triggered.
     */
    char name[VPAR_STRLEN];


    /* Read access :
     *  [0] : 8 bits
     *  [1] : 16 bits
     *  [2] : 32 bits
     *  [3] : unused
     */
    unsigned char read_access[4];

    /* Write access :
     *  [0] : 8 bits
     *  [1] : 16 bits
     *  [2] : 32 bits
     *  [3] : unused
     */
    unsigned char write_access[4];

    /* Break address :
     * - String, for use on SatLink side.
     * - value and mask, for use on Yabause side.
     */
    char address_str[12];
    unsigned long address_val;
    unsigned long address_mask;

    /* Break value :
     * - String, for use on SatLink side.
     * - value and mask, for use on Yabause side.
     */
    char value_str[12];
    unsigned long value_val;
    unsigned long value_mask;
} vpar_bp_entry;

typedef struct _vpar_bp_settings
{
    /* Breakpoints count. */
    unsigned short bp_count;

    /* Padding bytes. */
    unsigned char padding1[2];

    /*
     * Values below are set by SatLink, and used by Yabause :
     *  - Data read  start ID / count
     *  - Data write start ID / count
     */



    /* Definition of each breakpoints. */
    vpar_bp_entry bp[VPAR_BP_COUNT];
} vpar_bp_settings;






typedef struct _vpar_yabause_set_t
{
    /* Incremented when Yabause updated some data. */
    unsigned char update_counter;

    /* Last debug data file wrote by Yabause. */
    char last_file[VPAR_STRLEN];

    /* "Ready" flag : 0: shared memory cleared, 1: yabause is/was running. */
    unsigned long ready;

    /* PC & other register value. */
    unsigned long pc[2]; // For each CPU
    unsigned long mem_read;
    unsigned long mem_write;
    unsigned char mem_read_cntr;
    unsigned char mem_write_cntr;
    unsigned char unused_regs[64 - 4*2 - 4 - 4 - 1 - 1];

    /* Pushed key count. */
    unsigned long keycount;
    /* Trace when pushed key count reached the following count. */
    unsigned long trace_keycount;

    /* Custom cartridge LED output. */
    unsigned char cart_testled;

    /* Current function level. */
    unsigned short sh2fct_log_level;
} vpar_yabause_set_t;

typedef struct _vpar_satlink_set_t
{
    /* Incremented when SatLink updated some data. */
    unsigned char update_counter;

    /* Link-related DebugView log output (Yabause side / SatLink side). */
    unsigned char dbgview[2];

    /* Vpar internal log output, for Yabause/SatLink debug purpose. */
    unsigned char vpar_logout;

    /* When 1, log VDP2 state. */
    unsigned char vdp2log;
    /* When 1, display the state of all registers. */
    unsigned char alldisp;
    /* When 1, display the state of the registers that changed in a "ready to compile" way. */
    unsigned char diffdisp;
    /* When 1, dump the VDP2 memory contents to disk. */
    unsigned char dump;
    /* When 1, save the current state as reference. */
    unsigned char saveref;

    /* Yabause VDP2 poll interval (frames). */
    unsigned short vdp2_poll_interval;


    /* Path where to log debugger data. */
    char logpath[VPAR_STRLEN];

    /* Path where to find SD card data. */
    char sdpath[VPAR_STRLEN];

    /* When 1, log SH2 function calls. */
    unsigned char sh2fct_log;

    /* When 1, trace PC values in text file. */
    unsigned char pc_trace;
    unsigned long pc_trace_trigger;


    /* Output logs to debugview or file. */
    unsigned char logs_to_file;


    /* When 1, log VDP1 state. */
    unsigned char vdp1log;
    /* When 1, log VDP1 registers access. */
    unsigned char vdp1_reglog;
    /* When 1, log VDP1 command table access. */
    unsigned char vdp1_cmdlog;
    /* When 1, periodically dump all VDP1 registers. */
    unsigned char vdp1_regsdump;

    /* When 1, emulate link from yabause. */
    unsigned char ylink_emulate;
    /* When 1, output log related to yabause link emulator. */
    unsigned char log_ylink_emulate;

    /* When 1, emulate custom cartridge from yabause. */
    unsigned char satcart_emulate;

    /* Custom cartridge switch status and ID. */
    unsigned char cart_sw;
    unsigned char cart_id;

    /* Monitor data (SH2 registers) refresh interval. */
    unsigned char monitor_interval;

    /* Trace SH2 register contents. */
    unsigned char sh2_trace;

    /* Trace when a key is pushed ? */
    unsigned long trace_keycount_use;

    /* Common log settings. */
    unsigned char log_fileline;
    unsigned char log_pcreg;
    /* Satcom logs output selectors. */
    unsigned char logs_etc;
    unsigned char logs_dbgr;
    unsigned char logs_inter;
    unsigned char logs_ubc;
    unsigned char logs_vdp1;
    unsigned char logs_vdp2;
    unsigned char logs_sdc;
    /* Yabause logs output selectors. */
    unsigned char logy_etc;
    unsigned char logy_cd;
    unsigned char logy_scsp;
    unsigned char logy_vdp1;
    unsigned char logy_vdp2;
    unsigned char logy_smpc;
    unsigned char logy_sh2;
    unsigned char logy_net;

} vpar_satlink_set_t;


/* Define area reserved for main structures, so that compatibility
 * is not broken when some data is added in theses structures.
 */
#define YABAUSE_SET_AREA_SIZE (1*1024)
#define SATLINK_SET_AREA_SIZE (1*1024)
#define BREAKPOINTS_AREA_SIZE (16*1024)


typedef struct _vpar_shared_memory_t
{
    /** ---------------------------------- **/
    /** -- Shared memory statistics.    -- **/
    /** -- (Data set by DLL itself)     -- **/
    vpar_stats_t vpar_stats[SHRDMEM_MUTEX_COUNT];

    /** ---------------------------------- **/
    /** -- SatLink/Yabause I/O related. -- **/
    vpar_io_t io[2];
#define IO_YABAUSE_ID 0
#define IO_SATLINK_ID 1

    /** --------------------------------- **/
    /** -- Common data set by Yabause. -- **/
    vpar_yabause_set_t yabause_set;
    /* Pad above area to fixed size. */
    unsigned char yabause_set_pad[YABAUSE_SET_AREA_SIZE - sizeof(vpar_yabause_set_t)];

    /** --------------------------------- **/
    /** -- Common data set by SatLink. -- **/
    vpar_satlink_set_t satlink_set;
    /* Pad above area to fixed size. */
    unsigned char satlink_set_pad[SATLINK_SET_AREA_SIZE - sizeof(vpar_satlink_set_t)];

    /** --------------------------------- **/
    /** -- Breakpoints stuff.          -- **/
    vpar_bp_settings bps;
    /* Pad above area to fixed size. */
    unsigned char bp_pad[BREAKPOINTS_AREA_SIZE - sizeof(vpar_bp_settings)];
} vpar_shared_memory_t;


/** Offsets to several structures in shared memory. **/
#define IO_OFFSET(_IO_ID_) ((sizeof(vpar_stats_t)*SHRDMEM_MUTEX_COUNT) + (_IO_ID_)*sizeof(vpar_io_t))
#define YABAUSE_SET_OFFSET (IO_OFFSET(2))
#define SATLINK_SET_OFFSET (YABAUSE_SET_OFFSET + YABAUSE_SET_AREA_SIZE)
#define BREAKPOINTS_OFFSET (SATLINK_SET_OFFSET + SATLINK_SET_AREA_SIZE)


// GCC have alternative #pragma pack() syntax and old gcc version not
// support pack(pop), also any gcc version not support it at some platform
#if defined( __GNUC__ )
#pragma pack()
#else
#pragma pack(pop)
#endif









/**
 * VparInit
 *
 * Initialize shared memory stuff.
 * This function needs to be called on program startup.
 *
 * Note : this function is defined on wrapper side.
 *
 * Return 1 if initialization successed, zero else.
**/
int VparInit(void);


/**
 * VparClose
 *
 * Initialize shared memory stuff.
 * This function needs to be called on program close.
 *
 * Note : this function is defined on wrapper side.
**/
void VparClose(void);


/**
 * VparWaitForSingleObject
 *
 * Lock specified mutex(es).
 * This function is useful if you want to do complex manipulation directly within shared memory.
 * However, in order to avoid contention it is prefered to use VparGet/VParSet
 * functions when possible.
 *
 * Parameters :
 *  ulMtxList : bitfield of mutex(es) to release.
 *  pptrSharedMem : pointer to shared memory (output parameter).
 *
 * Note : this function is defined on DLL side.
**/
typedef unsigned long (*Fct_VparWaitForSingleObject)(unsigned long, vpar_shared_memory_t**);
VPAR_DLLEXPORT unsigned long VparWaitForSingleObject(unsigned long ulMtxList, vpar_shared_memory_t** pptrSharedMem);


/**
 * VparReleaseMutex
 *
 * Release specified mutex(es).
 * Please call this function in pair with VparWaitForSingleObject.
 *
 * Parameters :
 *  ulMtxList : bitfield of mutex(es) to release.
 *
 * Note : this function is defined on DLL side.
**/
typedef void (*Fct_VparReleaseMutex)(unsigned long);
VPAR_DLLEXPORT void VparReleaseMutex(unsigned long ulMtxList);


/**
 * VparWrite
 *
 * Write shared memory to given offset and size.
 *
 * Parameters :
 *  ulOffset : Offset from shared memory beginning.
 *  ptrData  : Pointer to data to set.
 *  ulLength : Length in byte(s) of data to set.
 *
 * Note : this function is defined on DLL side.
 *
 * Return written data size, or zero if DLL couldn't be loaded.
**/
typedef unsigned long (*Fct_VparWrite)(unsigned long, unsigned long, void*, unsigned long);
VPAR_DLLEXPORT unsigned long VparWrite(unsigned long ulMtxList, unsigned long ulOffset, void* ptrData, unsigned long ulLength);


/**
 * VparRead
 *
 * Read shared memory from given offset and size.
 *
 * Parameters :
 *  ptrData  : Pointer where to put data to read.
 *  ulOffset : Offset from shared memory beginning.
 *  ulLength : Length in byte(s) of data to set.
 *
 * Note : this function is defined on DLL side.
 *
 * Return read data size, or zero if DLL couldn't be loaded.
**/
typedef unsigned long (*Fct_VparRead)(unsigned long, void*, unsigned long, unsigned long);
VPAR_DLLEXPORT unsigned long VparRead(unsigned long ulMtxList, void* ptrData, unsigned long ulOffset, unsigned long ulLength);


/**
 * VparDump
 *
 * Dump whole shared memory.
 *
 * Parameter :
 *  ptrMem : Pointer where to retrieve shared memory contents.
 *
 * Note : this function is defined on wrapper side.
 *
 * Return read data size, or zero if DLL couldn't be loaded.
**/
unsigned long VparDump(vpar_shared_memory_t* ptrMem);


/**
 * VparGetIo/VparSetIo
 *
 * Get/Set Yabause/SatLink I/O parameters in shared memory.
 *
 * Parameter :
 *  ulIo  : Yabause/SatLink ID.
 *  ptrIo : Pointer of parameters to store in shared memory.
 *
 * Note : this function is defined on wrapper side.
 *
 * Return read/written data size, or zero if DLL couldn't be loaded.
**/
unsigned long VparGetIo(unsigned long ulIo, vpar_io_t* ptrIo);
unsigned long VparSetIo(unsigned long ulIo, vpar_io_t* ptrIo);


/**
 * VparGetYabauseParameters/VparSetYabauseParameters
 *
 * Get/Set Yabause parameters in shared memory.
 *
 * Parameter :
 *  ptrParams : Pointer of parameters to retrieve from/store in shared memory.
 *
 * Note : this function is defined on wrapper side.
 *
 * Return read/written data size, or zero if DLL couldn't be loaded.
**/
unsigned long VparGetYabauseParameters(vpar_yabause_set_t* ptrParams);
unsigned long VparSetYabauseParameters(vpar_yabause_set_t* ptrParams);


/**
 * VparGetSatLinkParameters/VparSetSatLinkParameters
 *
 * Get/Set SatLink parameters in shared memory.
 *
 * Parameter :
 *  ptrParams : Pointer of parameters to retrieve from/store in shared memory.
 *
 * Note : this function is defined on wrapper side.
 *
 * Return read/written data size, or zero if DLL couldn't be loaded.
**/
unsigned long VparGetSatLinkParameters(vpar_satlink_set_t* ptrParams);
unsigned long VparSetSatLinkParameters(vpar_satlink_set_t* ptrParams);


/**
 * VparGetBreakpoints/VparSetBreakpoints
 *
 * Get/Set breakpoints settings in shared memory.
 *
 * Parameter :
 *  ptrBp : Pointer of settings to retrieve from/store in shared memory.
 *
 * Note : this function is defined on wrapper side.
 *
 * Return read/written data size, or zero if DLL couldn't be loaded.
**/
unsigned long VparGetBreakpoints(vpar_bp_settings* ptrBp);
unsigned long VparSetBreakpoints(vpar_bp_settings* ptrBp);





/**
 * Define stuff for log output function, needed on Yabause, SatLink and DLL sides.
 *
 * Please define VPAR_LOG_ENABLE when some debug is needed, 
 * and don't define it when making release build.
 *
 * Borland C++ Builder doesn't seems to be at ease with variadic macros, 
 * hence it is defined differently when building for SatLink.
**/
#define VPAR_LOG_ENABLE


/**
 * Full path to VPar log file, shared by both Yabause and SatLink.
**/
#define VPAR_LOG_FILE "R:\\vpar.log"


#ifdef VPAR_SATLINK_BUILD
#ifdef VPAR_LOG_ENABLE
#define VPAR_WRAPPER_GLOBAL_LOG_DECLARATIONS()  \
unsigned long _ulLogIndex = 0;                                                                          \
void VparLogOut(char *strString, ...)                                                                   \
{                                                                                                       \
    va_list argptr;                                                                                     \
    char strLog[2048];                                                                                  \
    sprintf(strLog, "[TH%08X][ID%08X]", GetCurrentThreadId(), _ulLogIndex++);                           \
    va_start(argptr, strString);                                                                        \
    vsnprintf(strLog+strlen(strLog), sizeof(strLog)-strlen(strLog)-1, strString, argptr);               \
    strLog[strlen(strLog)]=0;                                                                         \
    va_end(argptr);                                                                                     \
    OutputDebugStringA(strLog);                                                                         \
    FILE* fp = fopen(VPAR_LOG_FILE, "ab");                                                                   \
    if(fp)  \
    {        \
        if(strlen(strLog) != (sizeof(strLog) - 4))                      \
        {                                                               \
            sprintf(strLog+strlen(strLog), "\r\n");               \
        }                                                               \
        strLog[strlen(strLog)] = '0';               \
        fwrite(strLog, strlen(strLog), 1, fp);               \
        fclose(fp);               \
    }               \
}
#else // !VPAR_LOG_ENABLE
#define VPAR_WRAPPER_GLOBAL_LOG_DECLARATIONS()  \
void VparLogOut(char *strString, ...) {;}
#endif

#else // !VPAR_SATLINK_BUILD

#define VPAR_WRAPPER_GLOBAL_LOG_DECLARATIONS()  \
unsigned long _ulLogIndex = 0;                                                                          \
void VparLogOutInternal(char* strFilePath, int iLine, char* strFunc, char *strString, ...)              \
{                                                                                                       \
    va_list argptr;                                                                                     \
    char strLog[2048];                                                                                  \
    char* strFile = strFilePath;                                                                        \
    int i;                                                                                              \
    for(i=(int)strlen(strFilePath)-2; i>=0; i--)                                                        \
    {                                                                                                   \
        if(strFilePath[i] == 0x5C)                                                                      \
        {                                                                                               \
            strFile = strFilePath+i+1; break;                                                           \
        }                                                                                               \
    }                                                                                                   \
    sprintf(strLog, "[TH%08X][ID%08X][%s::%d][%s]", GetCurrentThreadId(), _ulLogIndex++, strFile, iLine, strFunc); \
    va_start(argptr, strString);                                                                        \
    vsnprintf(strLog+strlen(strLog), sizeof(strLog)-strlen(strLog)-1, strString, argptr);               \
    strLog[strlen(strLog)]=0;                                                                         \
    va_end(argptr);                                                                                     \
    OutputDebugStringA(strLog);                                                                         \
    FILE* fp = fopen(VPAR_LOG_FILE, "ab");                                                                   \
    if(fp)  \
    {        \
        if(strlen(strLog) != (sizeof(strLog) - 4))                      \
        {                                                               \
            sprintf(strLog+strlen(strLog), "\r\n");               \
        }                                                               \
        strLog[strlen(strLog)] = '0';               \
        fwrite(strLog, strlen(strLog), 1, fp);               \
        fclose(fp);               \
    }               \
}

#ifdef VPAR_LOG_ENABLE
#   define VparLogOut(_STR_, ...) VparLogOutInternal(__FILE__, __LINE__, __FUNCTION__, _STR_, __VA_ARGS__)
#else // !VPAR_LOG_ENABLE
#   define VparLogOut(_STR_, ...) {;}
#endif

#endif











/**
 * Define wrapper global variables and functions.
 * This needs to be declared somewhere in Yabause/SatLink source.
 *
 * Then following functions need to be called :
 *  - VparInit, on program startup.
 *  - VparClose, on program close.
 *
 * VparInit returns 1 if DLL could be loaded, zero else.
**/
#define VPAR_WRAPPER_GLOBAL_MAIN_DECLARATIONS() \
HINSTANCE _hVpar = NULL;                                                                                \
Fct_VparRead  _hVparRead  = NULL;                                                                       \
Fct_VparWrite _hVparWrite = NULL;                                                                       \
Fct_VparWaitForSingleObject _hVparWaitForSingleObject = NULL;                                           \
Fct_VparReleaseMutex        _hVparReleaseMutex        = NULL;                                           \
                                                                                                        \
int VparInit(void)                                                                                      \
{                                                                                                       \
    int iRet = 1;                                                                                       \
                                                                                                        \
    _hVpar = LoadLibraryA(VPAR_FILE_NAME);                                                              \
    if(_hVpar == NULL) _hVpar = LoadLibraryA("satlink\\Vpar\\lib\\" VPAR_FILE_NAME);                    \
                                                                                                        \
    VparLogOut("VparDll LoadLibrary = 0x%08X", _hVpar);                                                 \
                                                                                                        \
    _hVparRead  = (Fct_VparRead )(_hVpar ? GetProcAddress(_hVpar, "VparRead" ) : NULL);                 \
    _hVparWrite = (Fct_VparWrite)(_hVpar ? GetProcAddress(_hVpar, "VparWrite") : NULL);                 \
    _hVparWaitForSingleObject = (Fct_VparWaitForSingleObject)(_hVpar ? GetProcAddress(_hVpar, "VparWaitForSingleObject") : NULL); \
    _hVparReleaseMutex        = (Fct_VparReleaseMutex       )(_hVpar ? GetProcAddress(_hVpar, "VparReleaseMutex"       ) : NULL); \
                                                                                                        \
    VparLogOut(" | Read  = 0x%08X", _hVparRead);                                                        \
    VparLogOut(" | Write = 0x%08X", _hVparWrite);                                                       \
    VparLogOut(" | WaitForSingleObject = 0x%08X", _hVparWaitForSingleObject);                           \
    VparLogOut(" | ReleaseMutex        = 0x%08X", _hVparReleaseMutex       );                           \
                                                                                                        \
    if((void*)_hVpar == NULL) iRet = 0;                                                                 \
    if((void*)_hVparWrite == NULL) iRet = 0;                                                            \
    if((void*)_hVparRead  == NULL) iRet = 0;                                                            \
    if((void*)_hVparWaitForSingleObject == NULL) iRet = 0;                                              \
    if((void*)_hVparReleaseMutex        == NULL) iRet = 0;                                              \
                                                                                                        \
    return iRet;                                                                                        \
}                                                                                                       \
\
void VparClose(void)                                                                                    \
{                                                                                                       \
    VparLogOut("VparClose STT");                                                                        \
    if(_hVpar != NULL)                                                                                  \
    {                                                                                                   \
        _hVparRead  = NULL;                                                                             \
        _hVparWrite = NULL;                                                                             \
        _hVparWaitForSingleObject = NULL;                                                               \
        _hVparReleaseMutex        = NULL;                                                               \
        FreeLibrary(_hVpar);                                                                            \
        _hVpar = NULL;                                                                                  \
    }                                                                                                   \
    VparLogOut("VparClose END");                                                                        \
}                                                                                                       \
\
unsigned long VparWaitForSingleObject(unsigned long ulMtxList, vpar_shared_memory_t** pptrSharedMem)    \
{                                                                                                       \
    unsigned long dwRet = WAIT_ABANDONED;                                                               \
                                                                                                        \
    if(_hVparWaitForSingleObject)                                                                       \
    {                                                                                                   \
        VparLogOut("VparWaitForSingleObject STT ulMtxList=0x%08X", ulMtxList);                          \
        dwRet = VparWaitForSingleObject(ulMtxList, pptrSharedMem);                                      \
        VparLogOut("VparWaitForSingleObject END");                                                      \
    }                                                                                                   \
                                                                                                        \
    return dwRet;                                                                                       \
}                                                                                                       \
\
void VparReleaseMutex(unsigned long ulMtxList)                                                          \
{                                                                                                       \
    if(_hVparReleaseMutex)                                                                              \
    {                                                                                                   \
        VparLogOut("VparReleaseMutex STT ulMtxList=0x%08X", ulMtxList);                                 \
        _hVparReleaseMutex(ulMtxList);                                                                  \
        VparLogOut("VparReleaseMutex END");                                                             \
    }                                                                                                   \
}                                                                                                       \
\
unsigned long VparRead(unsigned long ulMtxList, void* ptrData, unsigned long ulOffset, unsigned long ulLength) \
{                                                                                                       \
    unsigned long ulRet = 0;                                                                            \
                                                                                                        \
    if(_hVparRead)                                                                                      \
    {                                                                                                   \
        VparLogOut("VparRead STT ulOffset=%d, ulLength=%d", ulOffset, ulLength);                        \
        ulRet = _hVparRead(ulMtxList, ptrData, ulOffset, ulLength);                                     \
        VparLogOut("VparRead END ulRet=%d", ulRet);                                                     \
    }                                                                                                   \
    else                                                                                                \
    {                                                                                                   \
        memset(ptrData, 0, ulLength);                                                                   \
    }                                                                                                   \
                                                                                                        \
    return ulRet;                                                                                       \
}                                                                                                       \
\
unsigned long VparWrite(unsigned long ulMtxList, unsigned long ulOffset, void* ptrData, unsigned long ulLength)                  \
{                                                                                                       \
    unsigned long ulRet = 0;                                                                            \
                                                                                                        \
    if(_hVparWrite)                                                                                     \
    {                                                                                                   \
        VparLogOut("VparWrite STT ulOffset=%d, ulLength=%d", ulOffset, ulLength);                       \
        ulRet = _hVparWrite(ulMtxList, ulOffset, ptrData, ulLength);                                               \
        VparLogOut("VparWrite END ulRet=%d", ulRet);                                                    \
    }                                                                                                   \
                                                                                                        \
    return ulRet;                                                                                       \
}                                                                                                       \
\
unsigned long VparDump(vpar_shared_memory_t* ptrMem)                                                    \
{                                                                                                       \
    unsigned long ulRet;                                                                                \
                                                                                                        \
    VparLogOut("VparDump STT");                                                                         \
    ulRet = VparRead(VPAR_MTX_ALL, (void*)ptrMem, 0, sizeof(vpar_shared_memory_t));                                   \
    VparLogOut("VparDump END ulRet=%d", ulRet);                                                         \
                                                                                                        \
    return ulRet;                                                                                       \
}                                                                                                       \
\
unsigned long VparGetIo(unsigned long ulIo, vpar_io_t* ptrIo)                                           \
{                                                                                                       \
    unsigned long ulRet;                                                                                \
                                                                                                        \
    VparLogOut("VparGetIo(IO=%d) STT", ulIo);                                                           \
    ulRet = VparRead(VPAR_MTX_LINK, (void*)ptrIo, IO_OFFSET(ulIo), sizeof(vpar_io_t));                                 \
    VparLogOut("VparGetIo END ulRet=%d", ulRet);                                                        \
                                                                                                        \
    return ulRet;                                                                                       \
}                                                                                                       \
\
unsigned long VparSetIo(unsigned long ulIo, vpar_io_t* ptrIo)                                           \
{                                                                                                       \
    unsigned long ulRet;                                                                                \
                                                                                                        \
    VparLogOut("VparSetIo(IO=%d) STT", ulIo);                                                           \
    ulRet = VparWrite(VPAR_MTX_LINK, IO_OFFSET(ulIo), (void*)ptrIo, sizeof(vpar_io_t));                                \
    VparLogOut("VparSetIo END ulRet=%d", ulRet);                                                        \
                                                                                                        \
    return ulRet;                                                                                       \
}                                                                                                       \
\
unsigned long VparGetYabauseParameters(vpar_yabause_set_t* ptrParams)                                   \
{                                                                                                       \
    unsigned long ulRet;                                                                                \
                                                                                                        \
    VparLogOut("VparGetYabauseParameters STT");                                                         \
    ulRet = VparRead(VPAR_MTX_COMMON, (void*)ptrParams, YABAUSE_SET_OFFSET, sizeof(vpar_yabause_set_t));                 \
    VparLogOut("VparGetYabauseParameters END ulRet=%d", ulRet);                                         \
                                                                                                        \
    return ulRet;                                                                                       \
}                                                                                                       \
\
unsigned long VparSetYabauseParameters(vpar_yabause_set_t* ptrParams)                                   \
{                                                                                                       \
    unsigned long ulRet;                                                                                \
                                                                                                        \
    VparLogOut("VparSetYabauseParameters STT");                                                         \
    ulRet = VparWrite(VPAR_MTX_COMMON, YABAUSE_SET_OFFSET, (void*)ptrParams, sizeof(vpar_yabause_set_t));                \
    VparLogOut("VparSetYabauseParameters END ulRet=%d", ulRet);                                         \
                                                                                                        \
    return ulRet;                                                                                       \
}                                                                                                       \
\
unsigned long VparGetSatLinkParameters(vpar_satlink_set_t* ptrParams)                                   \
{                                                                                                       \
    unsigned long ulRet;                                                                                \
                                                                                                        \
    VparLogOut("VparGetSatLinkParameters STT");                                                         \
    ulRet = VparRead(VPAR_MTX_COMMON, (void*)ptrParams, SATLINK_SET_OFFSET, sizeof(vpar_satlink_set_t));                 \
    VparLogOut("VparGetSatLinkParameters END ulRet=%d", ulRet);                                         \
                                                                                                        \
    return ulRet;                                                                                       \
}                                                                                                       \
\
unsigned long VparSetSatLinkParameters(vpar_satlink_set_t* ptrParams)                                   \
{                                                                                                       \
    unsigned long ulRet;                                                                                \
                                                                                                        \
    VparLogOut("VparSetSatLinkParameters STT");                                                         \
    ulRet = VparWrite(VPAR_MTX_COMMON, SATLINK_SET_OFFSET, (void*)ptrParams, sizeof(vpar_satlink_set_t));                \
    VparLogOut("VparSetSatLinkParameters END ulRet=%d", ulRet);                                         \
                                                                                                        \
    return ulRet;                                                                                       \
}                                                                                                       \
\
unsigned long VparGetBreakpoints(vpar_bp_settings* ptrBp)                                               \
{                                                                                                       \
    unsigned long ulRet;                                                                                \
                                                                                                        \
    VparLogOut("VparGetBreakpoints STT");                                                               \
    ulRet = VparRead(VPAR_MTX_COMMON, (void*)ptrBp, BREAKPOINTS_OFFSET, sizeof(vpar_bp_settings));                       \
    VparLogOut("VparGetBreakpoints END ulRet=%d", ulRet);                                               \
                                                                                                        \
    return ulRet;                                                                                       \
}                                                                                                       \
\
unsigned long VparSetBreakpoints(vpar_bp_settings* ptrBp)                                               \
{                                                                                                       \
    unsigned long ulRet;                                                                                \
                                                                                                        \
    VparLogOut("VparSetBreakpoints STT");                                                               \
    ulRet = VparWrite(VPAR_MTX_COMMON, BREAKPOINTS_OFFSET, (void*)ptrBp, sizeof(vpar_bp_settings));                      \
    VparLogOut("VparSetBreakpoints END ulRet=%d", ulRet);                                               \
                                                                                                        \
    return ulRet;                                                                                       \
}                                                                                                       \



#ifdef  __cplusplus
}
#endif


#endif // _INCLUDE_VPAR_H_

// Vpar.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"
#include <windows.h>
#include <memory.h>

#include "lib/Vpar.h"

/* Log output function from library wrapper stuff. */
VPAR_WRAPPER_GLOBAL_LOG_DECLARATIONS();


static LPVOID lpvMem = NULL;						/* pointer to shared memory. */
static vpar_shared_memory_t* ptrSharedMem = NULL;	/* pointer to shared memory. */
static HANDLE hMapObject = NULL;					/* handle to file mapping. */

/*
 * Declare several mutexes for each main areas in shared memory.
 * Mutex(es) are selected with bitfield, so multiple selection is possible.
 */
HANDLE hShrdMemMtx[SHRDMEM_MUTEX_COUNT] = {NULL};




/*
 * The DLL entry-point function sets up shared memory using a
 * named file-mapping object.
 */
BOOL WINAPI DllMain(HINSTANCE hinstDLL,	/* DLL module handle. */
	DWORD fdwReason,					/* reason called. */
	LPVOID lpvReserved)					/* reserved. */
{
	BOOL fInit, fIgnore;

	switch (fdwReason)
	{
	/* DLL load due to process initialization or LoadLibrary. */
	case DLL_PROCESS_ATTACH:

		VparLogOut("@[DLL_PROCESS_ATTACH]VPAR DLL build date : "__DATE__ ", time :" __TIME__);
		VparLogOut("@[DLL_PROCESS_ATTACH]Shared memory total size : %d bytes.", sizeof(vpar_shared_memory_t));

		/* Create mutexes for safe memory access between every process. */
		VparLogOut("@[DLL_PROCESS_ATTACH]CreateMutex (cnt=%d) ...", SHRDMEM_MUTEX_COUNT);
		for(int i=0; i<SHRDMEM_MUTEX_COUNT; i++)
		{
			char strMutexName[64];
			sprintf(strMutexName, "Global\\SlnYabMutex%03d", i);
			hShrdMemMtx[i] = CreateMutex(NULL, FALSE, strMutexName);
		}

		/* Create a named file mapping object. */
		VparLogOut("@[DLL_PROCESS_ATTACH]CreateFileMapping ...");
		hMapObject = CreateFileMapping(
			INVALID_HANDLE_VALUE,			/* use paging file. */
			NULL,							/* default security attributes. */
			PAGE_READWRITE,					/* read/write access. */
			0,								/* size: high 32-bits. */
			sizeof(vpar_shared_memory_t),	/* size: low 32-bits. */
			TEXT("SlnYabShrdMem"));			/* name of map object. */
		if (hMapObject == NULL)
			return FALSE;

		/* The first process to attach initializes memory. */
		fInit = (GetLastError() != ERROR_ALREADY_EXISTS);

		/* Get a pointer to the file-mapped shared memory. */
		VparLogOut("@[DLL_PROCESS_ATTACH]MapViewOfFile ...");
		lpvMem = MapViewOfFile(
			hMapObject,		/* object to map view of. */
			FILE_MAP_WRITE, /* read/write access. */
			0,				/* high offset:	map from. */
			0,				/* low offset:	beginning. */
			0);				/* default: map entire file. */
		if (lpvMem == NULL)
		{
			return FALSE;
		}
		ptrSharedMem = (vpar_shared_memory_t*)lpvMem;

		/* Initialize memory if this is the first process. */
		if(fInit)
		{
			memset(lpvMem, '\0', sizeof(vpar_shared_memory_t));

			/* Init internal log output switch. */
			ptrSharedMem->satlink_set.vpar_logout = 0;

#ifdef VPAR_LOG_ENABLE
			/* Clear the log file on shared memory creation. */
			DeleteFileA(VPAR_LOG_FILE);
#endif
		}

		break;

		/* The attached process creates a new thread. */
		case DLL_THREAD_ATTACH:
			break;

		/* The thread of the attached process terminates. */
		case DLL_THREAD_DETACH:
			break;

		/* DLL unload due to process termination or FreeLibrary. */
		case DLL_PROCESS_DETACH:

			/* Unmap shared memory from the process's address space. */
			fIgnore = UnmapViewOfFile(lpvMem);
			lpvMem = NULL;
			ptrSharedMem = NULL;

			/* Close the process's handle to the file-mapping object. */
			fIgnore = CloseHandle(hMapObject);

			/* Close each mutex handles. */
			for(int i=0; i<SHRDMEM_MUTEX_COUNT; i++)
			{
				HANDLE hTmp = hShrdMemMtx[i];
				hShrdMemMtx[i] = NULL;
				CloseHandle(hTmp);
			}

			break;

		default:
			break;
	}

	return TRUE;
	UNREFERENCED_PARAMETER(hinstDLL);
	UNREFERENCED_PARAMETER(lpvReserved);
}

/*
 * The export mechanism used here is the __declspec(export)
 * method supported by Microsoft Visual Studio, but any
 * other export method supported by your development
 * environment may be substituted.
 */

#ifdef __cplusplus
extern "C" {		/* If used by C++ code, we need to export the C interface. */
#endif


/* (Internal use) Read from Shared-Memory. */
unsigned long GetSharedMem(unsigned char* pcBuff, unsigned long ulOffset, unsigned long ulSize)
{
	unsigned long ulRet = ulSize;
	unsigned char* lpszTmp;
	unsigned long i;

	/* Don't do anything if shared memory no longer exists. */
	if(lpvMem == NULL)
	{
		return 0;
	}

	/* Get the address of the shared memory block. */
	lpszTmp = (unsigned char*)lpvMem;
	lpszTmp += ulOffset;

	/* Copy from shared memory into the caller's buffer. */
	for(i=0; i<ulSize; i++)
	{
		*pcBuff++ = *lpszTmp++;
	}

	return ulRet;
}

/* (Internal use) Write to Shared-Memory. */
unsigned long SetSharedMem(unsigned char* pcBuff, unsigned long ulOffset, unsigned long ulSize)
{
	unsigned long ulRet = ulSize;
	unsigned char* lpszTmp;
	unsigned long i;

	/* Don't do anything if shared memory no longer exists. */
	if(lpvMem == NULL)
	{
		return 0;
	}

	/* Get the address of the shared memory block. */
	lpszTmp = (unsigned char*)lpvMem;
	lpszTmp += ulOffset;

	/* Copy the array into shared memory. */
	for(i=0; i<ulSize; i++)
	{
		*lpszTmp++ = *pcBuff++;
	}

	return ulRet;
}


VPAR_DLLEXPORT unsigned long VparWaitForSingleObject(unsigned long ulMtxList, vpar_shared_memory_t** pptrSharedMem)
{
	DWORD dwRet = WAIT_OBJECT_0;

	for(int i=0; i<SHRDMEM_MUTEX_COUNT; i++)
	{
		if(ulMtxList & (1 << i))
		{
			if((hShrdMemMtx[i] != NULL))
			{
				DWORD dwWaitResult = WaitForSingleObject(hShrdMemMtx[i], INFINITE);
				if(dwWaitResult != WAIT_OBJECT_0)
				{
					dwRet = dwWaitResult;
				}
			}
			else
			{
				/* Mutex no longer available ? Too bad, but I can't do anything for you. */
				dwRet = WAIT_ABANDONED;
			}
		}
	}

	/* If success, return pointer to shared memory. */
	if(pptrSharedMem)
	{
		if(dwRet == WAIT_OBJECT_0)
		{
			*pptrSharedMem = ptrSharedMem;
		}
		else
		{
			*pptrSharedMem = NULL;
		}
	}

	return (unsigned long)dwRet;
}


VPAR_DLLEXPORT void VparReleaseMutex(unsigned long ulMtxList)
{
	for(int i=0; i<SHRDMEM_MUTEX_COUNT; i++)
	{
		if((ulMtxList & (1 << i)) && (hShrdMemMtx[i] != NULL))
		{
			ReleaseMutex(hShrdMemMtx[i]);
		}
	}
}



VPAR_DLLEXPORT unsigned long VparRead(unsigned long ulMtxList, void* ptrData, unsigned long ulOffset, unsigned long ulLength)
{
	unsigned long ulRet = 0;

	/* Get stats ID from selected mutex. */
	unsigned long ulStatsId = 0;
	for(int i=0; i<SHRDMEM_MUTEX_COUNT; i++)
	{
		if(ulMtxList & (1 << i))
		{
			ulStatsId = i;
			break;
		}
	}

	/* Lock access to shared memory. */
	DWORD dwWaitResult = VparWaitForSingleObject(ulMtxList, NULL);

	if((dwWaitResult == WAIT_OBJECT_0 || dwWaitResult == WAIT_ABANDONED))
	{
		if(ptrSharedMem != NULL)
		{
			if (dwWaitResult == WAIT_ABANDONED)
			{
				/* Shared memory is maybe in inconsistent state because other program
				 * crashed while holding the mutex. Check the memory for consistency
				 */
				VparLogOut("@[VPortReadByte]dwWaitResult == WAIT_ABANDONED !");
				ptrSharedMem->vpar_stats[ulStatsId].error_cnt++;
			}
			else
			{
				VparLogOut("@[VparRead ]ulOffset=0x%08X (%6d), ulLength=0x%08X (%6d) ...", 
					ulOffset, ulOffset, ulLength, ulLength);

				ulRet = GetSharedMem((unsigned char*)ptrData, ulOffset, ulLength);

				/* Update shared memory statistics stuff. */
				ptrSharedMem->vpar_stats[ulStatsId].read_cnt++;
				ptrSharedMem->vpar_stats[ulStatsId].read_size += ulLength;
			}
		}

		/* After this line other processes can access shared memory. */
		VparReleaseMutex(ulMtxList);
	}

	return ulRet;
}



VPAR_DLLEXPORT unsigned long VparWrite(unsigned long ulMtxList, unsigned long ulOffset, void* ptrData, unsigned long ulLength)
{
	unsigned long ulRet = 0;

	/* Get stats ID from selected mutex. */
	unsigned long ulStatsId = 0;
	for(int i=0; i<SHRDMEM_MUTEX_COUNT; i++)
	{
		if(ulMtxList & (1 << i))
		{
			ulStatsId = i;
			break;
		}
	}

	/* Lock access to shared memory. */
	DWORD dwWaitResult = VparWaitForSingleObject(ulMtxList, NULL);

	if((dwWaitResult == WAIT_OBJECT_0 || dwWaitResult == WAIT_ABANDONED))
	{
		if(ptrSharedMem != NULL)
		{
			if (dwWaitResult == WAIT_ABANDONED)
			{
				/* Shared memory is maybe in inconsistent state because other program
				 * crashed while holding the mutex. Check the memory for consistency
				 */
				VparLogOut("@[SetYabauseParameters]dwWaitResult == WAIT_ABANDONED !");
				ptrSharedMem->vpar_stats[ulStatsId].error_cnt++;
			}
			else
			{
				VparLogOut("@[VparWrite]ulOffset=0x%08X (%6d), ulLength=0x%08X (%6d) ...", 
					ulOffset, ulOffset, ulLength, ulLength);

				ulRet = SetSharedMem((unsigned char*)ptrData, ulOffset, ulLength);

				/* Update shared memory statistics stuff. */
				ptrSharedMem->vpar_stats[ulStatsId].write_cnt++;
				ptrSharedMem->vpar_stats[ulStatsId].write_size += ulLength;
			}
		}

		/* After this line other processes can access shared memory. */
		VparReleaseMutex(ulMtxList);
	}

	return ulRet;
}


#ifdef __cplusplus
}
#endif


//---------------------------------------------------------------------------

#ifndef MainH
#define MainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Grids.hpp>
#include <ExtCtrls.hpp>

#include <stdio.h>
#include <string.h>

//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE �Ǘ��̃R���|�[�l���g
        TStringGrid *sgData;
        TEdit *edtWriteVal;
        TButton *btnGet;
        TCheckBox *CheckBox1;
        TButton *btnSet;
        TTimer *Timer1;
        TCheckBox *cbError;
        TEdit *edtID;
        TEdit *edtMultiplier;
        TButton *btnDump;
        TButton *btnRead;
        TButton *btnWrite;
        TCheckBox *CheckBox2;
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TCheckBox *CheckBox3;
        TEdit *edtOffset;
        TCheckBox *CheckBox4;
        TButton *btnExchange;
        void __fastcall StringGridKeyPress(TObject *Sender, char &Key);
        void __fastcall btnGetClick(TObject *Sender);
        void __fastcall btnSetClick(TObject *Sender);
        void __fastcall Timer1Timer(TObject *Sender);
        void __fastcall btnDumpClick(TObject *Sender);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall btnWriteClick(TObject *Sender);
        void __fastcall btnReadClick(TObject *Sender);
        void __fastcall btnExchangeClick(TObject *Sender);
private:	// ���[�U�[�錾
public:		// ���[�U�[�錾
        __fastcall TForm1(TComponent* Owner);
        unsigned long ulCnt;
        unsigned char ucExcData;
        unsigned long ulErrorCnt;
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif

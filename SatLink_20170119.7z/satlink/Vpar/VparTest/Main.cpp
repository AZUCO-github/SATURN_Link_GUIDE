//---------------------------------------------------------------------------

#include <vector>
#include <vcl.h>
#pragma hdrstop
#include "Main.h"

#include "..\lib\Vpar.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------

unsigned char char2pchar(unsigned char c)
{
    if(c < ' ') return '.';
    if(c > 127) return '?';
    return c;
}


/* DLL dynamic load stuff. */
typedef void          (*Fct_Vpar_SetProcID       )(unsigned char);
typedef unsigned char (*Fct_Vpar_VPortReadByte   )(unsigned long ulAddr);
typedef void          (*Fct_Vpar_VPortWriteByte  )(unsigned long, unsigned char);
typedef unsigned long (*Fct_Vpar_DumpSharedMemory)(unsigned char*, unsigned long);


HINSTANCE vpar_h = 0;
Fct_Vpar_SetProcID        vpar_SetProcID        = 0;
Fct_Vpar_VPortReadByte    vpar_VPortReadByte    = 0;
Fct_Vpar_VPortWriteByte   vpar_VPortWriteByte   = 0;
Fct_Vpar_DumpSharedMemory vpar_DumpSharedMemory = 0;


__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
        , ulCnt(0)
        , ucExcData(0x42)
{
    /* Vpar init STT vvv */
    char tmp[1024];
    int i;
    if(vpar_h != 0)
    {
        FreeLibrary(vpar_h); vpar_h = 0;
    }
    vpar_h = LoadLibrary("Vpar.dll");
    if(vpar_h)
    {
        vpar_SetProcID        = (Fct_Vpar_SetProcID       )GetProcAddress(vpar_h, "SetProcID"       );
        vpar_VPortReadByte    = (Fct_Vpar_VPortReadByte   )GetProcAddress(vpar_h, "VPortReadByte"   );
        vpar_VPortWriteByte   = (Fct_Vpar_VPortWriteByte  )GetProcAddress(vpar_h, "VPortWriteByte"  );
        vpar_DumpSharedMemory = (Fct_Vpar_DumpSharedMemory)GetProcAddress(vpar_h, "DumpSharedMemory");

        sprintf(tmp, "=== Vpar init success ! (h: 0x%08X)(ptr: 0x%08X, 0x%08X, 0x%08X) ===", vpar_h, vpar_SetProcID, vpar_VPortReadByte, vpar_VPortWriteByte); OutputDebugString(tmp);

        vpar_SetProcID(0/*ucProcessId : PROCESS_ID_YABAUSE*/);

        ///* For debug purpose. */
        //vpar_VPortWriteByte(0x378 + 0, 0x10);
        //vpar_VPortWriteByte(0x378 + 1, 0x20);
        //vpar_VPortWriteByte(0x378 + 2, 0x30);
        //unsigned char c = vpar_VPortReadByte(0x378 + 0);
        //sprintf(tmp, "=== vpar_VPortReadByte(0x378 + 0) = 0x%02X ===", c); OutputDebugString(tmp);

        //unsigned char buff[4];
        //vpar_DumpSharedMemory(buff, sizeof(buff));
        //for(i=0; i<4; i++)
        //{
        //    sprintf(tmp, "=== SharedMem[%d] = 0x%02X 0x%02X ===", i, buff[0+i], buff[8+i]); OutputDebugString(tmp);
        //}
        btnDumpClick(NULL);
    }
    else
    {
        sprintf(tmp, "=== Vpar init failure ==="); OutputDebugString(tmp);
    }
    /* Vpar init STT ^^^ */
}
//---------------------------------------------------------------------------





void __fastcall TForm1::StringGridKeyPress(TObject *Sender, char &Key)
{
    int col = sgData->Col;
    int row = sgData->Row;
    String str = sgData->Cells[col][row] + Key;
    sgData->Cells[col][row] = str;
}
//---------------------------------------------------------------------------


void __fastcall TForm1::btnGetClick(TObject *Sender)
{ ulCnt++;

unsigned long ulID = edtID->Text.ToInt();
unsigned long ulOffset = edtOffset->Text.ToInt();
    vpar_SetProcID(ulID%2/*ucProcessId*/);
    unsigned char c = vpar_VPortReadByte(ulOffset);

AnsiString str;
str.printf("R%d->0x%02X", ulOffset, c);
sgData->Cells[1][1] = str;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnSetClick(TObject *Sender)
{ ulCnt++;
unsigned long ulID = edtID->Text.ToInt();
unsigned long ulOffset = edtOffset->Text.ToInt();
    vpar_SetProcID(ulID%2/*ucProcessId*/);
unsigned char c = rand() % 0x77;
if(edtWriteVal->Text != "") c = edtWriteVal->Text.ToInt();
        vpar_VPortWriteByte(ulOffset, c);

AnsiString str;
str.printf("W%d->0x%02X", ulOffset, c);
sgData->Cells[0][0] = str;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
unsigned long ulID = edtID->Text.ToInt();
int iMult = edtMultiplier->Text.ToInt();
if(CheckBox1->Checked)
{
        for(int i=0; i<iMult; i++)
        {
            btnSetClick(Sender);
            btnGetClick(Sender);
        }
}
if(CheckBox2->Checked)
{
        for(int i=0; i<iMult; i++)
        {
            btnReadClick(Sender);
            btnWriteClick(Sender);
        }
}
if(CheckBox3->Checked)
{
        btnDumpClick(Sender);
}
if(CheckBox4->Checked)
{
    for(int i=0; i<iMult; i++)
    {
        btnExchangeClick(Sender);
    }
}

}
//---------------------------------------------------------------------------


void __fastcall TForm1::btnDumpClick(TObject *Sender)
{
    int i;
    unsigned char buff[8];
    vpar_DumpSharedMemory(buff, sizeof(buff));
sgData->Cells[0][6] = "C_OUT";
sgData->Cells[1][6] = "C_STAT";
sgData->Cells[2][6] = "C_IN";

sgData->Cells[0][9] = "P_IO";
sgData->Cells[1][9] = "-";
sgData->Cells[2][9] = "P_BUSY";
    for(i=0; i<4; i++)
    {
        AnsiString str;
        str.printf("0x%02X (%c)", buff[0+i], char2pchar(buff[0+i])); sgData->Cells[i][7] = str;
        str.printf("0x%02X (%c)", buff[4+i], char2pchar(buff[4+i])); sgData->Cells[i][10] = str;
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormClose(TObject *Sender, TCloseAction &Action)
{
    if(vpar_h)
    {
        FreeLibrary(vpar_h); vpar_h = NULL;
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnWriteClick(TObject *Sender)
{ ulCnt++;
    unsigned long ulID = edtID->Text.ToInt();
    vpar_SetProcID(ulID%2/*ucProcessId*/);
    for(int i=0; i<3; i++)
    {
        unsigned char c = rand() % 0x77;
        if(edtWriteVal->Text != "") c = edtWriteVal->Text.ToInt();
        vpar_VPortWriteByte(0x378+i, c);

        AnsiString str;
        str.printf("Wr 0x%02X", c);
        sgData->Cells[i][2] = str;

        str.printf("%d", ulCnt); sgData->Cells[2][0] = str;
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnReadClick(TObject *Sender)
{ ulCnt++;
    unsigned long ulID = edtID->Text.ToInt();
    vpar_SetProcID(ulID%2/*ucProcessId*/);
    for(int i=0; i<3; i++)
    {
        unsigned char c = vpar_VPortReadByte(0x378+i);

        AnsiString str;
        str.printf("Rd 0x%02X", c);
        sgData->Cells[i][3] = str;

        str.printf("%d", ulCnt); sgData->Cells[2][1] = str;
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnExchangeClick(TObject *Sender)
{
unsigned long ulID = edtID->Text.ToInt();
int iMult = edtMultiplier->Text.ToInt();
        AnsiString str;
        sgData->Cells[4][0] = "-";
        vpar_SetProcID(ulID%2/*ucProcessId*/);

            if(ulID == 0)
            { /* Yabause */
                unsigned char temp;
                unsigned long ucCount = 0;
                while((vpar_VPortReadByte(1) & 1) == 0)
                {
                 ucCount++;
                 if(ucCount > 10000)
                 {
                     sgData->Cells[4][0] = "X";
                     return;
                 }
                }
                temp = vpar_VPortReadByte(2);
                vpar_VPortWriteByte(0, temp+1);

                if((ucExcData != 0x42) && (ucExcData != 0xFF))
                {
                        if(temp != (ucExcData+1)) ulErrorCnt++;
                }
                ucExcData = temp;

                ulCnt++;
                str.printf("Cnt %d", ulCnt);
                sgData->Cells[3][0] = str;

                str.printf("Sat 0x%02X", ucExcData);
                sgData->Cells[3][1] = str;

                str.printf("SEr %d", ulErrorCnt);
                sgData->Cells[4][1] = str;
            }
            else
            { /* SatLink */
                unsigned char temp;
                unsigned long ucCount = 0;

                vpar_VPortWriteByte(0x378, ucExcData);
                while(vpar_VPortReadByte(0x378 + 2) & 1)
                {
                 ucCount++;
                 if(ucCount > 80000)
                 {
                     sgData->Cells[4][0] = "X";
                     return;
                 }
                }

                temp = vpar_VPortReadByte(0x378);

                if((ucExcData != 0x42) && (ucExcData != 0xFF))
                {
                        if(temp != (ucExcData+1)) ulErrorCnt++;
                }
                ucExcData = temp;

                ulCnt++;
                str.printf("Cnt %d", ulCnt);
                sgData->Cells[3][0] = str;

                str.printf("pc 0x%02X", ucExcData);
                sgData->Cells[3][2] = str;

                str.printf("PEr %d", ulErrorCnt);
                sgData->Cells[4][2] = str;
            }
        sgData->Cells[4][0] = ".";
}
//---------------------------------------------------------------------------


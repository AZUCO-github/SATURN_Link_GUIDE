Satcom -~- by cafe-alpha, http://ppcenter.free.fr/

This folder contains stuff for Saturn link program (SatLink) for use on PC.
 - source code in this folder is for SatLink itself.
 - source code in "parlink" folder is used by SatLink when communicating with parallel-port based devices, such as commslink, freewing, etc.
 - source code in "usbdl" folder is used by SatLink when communicating with USB Data Link devices.
 - source code in "common" folder is common to "parlink" and "usbdl", such as log functions, etc.




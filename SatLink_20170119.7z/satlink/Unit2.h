//---------------------------------------------------------------------------

#ifndef Unit2H
#define Unit2H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Grids.hpp>
#include <ExtCtrls.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class TForm2 : public TForm
{
__published:	// IDE-managed Components
        TCheckBox *cbDbgUse;
        TCheckBox *cbDbgEnable;
        TButton *btnFastExec2;
        TEdit *edtLogPath;
        TButton *btnLogSave;
        TButton *btnLogClear;
        TStringGrid *sgDbgText;
        TLabel *lblDbgInfos1;
        TLabel *lblDbgInfos2;
        TLabel *lblDbgInfos3;
        TButton *btnPromptSend;
        TEdit *edtDbgPrompt;
        TLabel *Label18;
        TMemo *mDbgText;
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall btnClick(TObject *Sender);
        void __fastcall edtDbgPromptKeyPress(TObject *Sender, char &Key);
        void __fastcall edtKeyPress(TObject *Sender, char &Key);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm2(TComponent* Owner);
        /*--- Settings related. ---*/
        AnsiString __fastcall MakeSettingsFilePath(void);
        void __fastcall LoadSettingsFile(void);
        void __fastcall SaveSettingsFile(void);

        void __fastcall InitFormItems(void);
        void __fastcall SaveFormItems(void);

        void __fastcall SaveToUserData(void);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm2 *Form2;
//---------------------------------------------------------------------------
#endif

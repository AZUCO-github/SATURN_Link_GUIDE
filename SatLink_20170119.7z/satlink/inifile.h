#ifndef _INIFILE_H_
#define _INIFILE_H_

/* Maximum ini file size. */
#define INIFILE_MAXSIZE (32*1024)
void parse_satlink_inifile(char* inifilebuffer, char* filename, int* argc, char** argv);

/* Maximum arguments allowed. */
#define MAXARGS 4096


/*--- The command line switches used in slnk/SatLink ---*/

/* Open DLL (Par1 = path to DLL). */
#define CMDSW_DEVICE     "-dev"
#define CMDCNT_DEVICE    1

/* Set parameter (Par1 = name, Par2 = value). */
#define CMDSW_SETPARAM   "-s"
#define CMDCNT_SETPARAM  2

/* Set log settings (Par1 = ini file name). */
#define CMDSW_LOGSETTS   "-logsettings"
#define CMDCNT_LOGSETTS  1

/* Set log level (Par1 = level). */
#define CMDSW_LOGLEVEL  "-loglevel"
#define CMDCNT_LOGLEVEL  1

/* Set file where to put log into (Par1 = name). */
#define CMDSW_LOGFILE    "-logfile"
#define CMDCNT_LOGFILE   1

/* Set log buffer size (Par1 = size in KB). */
#define CMDSW_LOGBUFFER  "-logbuffer"
#define CMDCNT_LOGBUFFER 1

/* Log informations, useful for debuging (No parameter). */
#define CMDSW_LOGINFOS   "-loginfos"
#define CMDCNT_LOGINFOS  0


/* Load file to Saturn memory (Par1 = file, Par2 = start address). */
#define CMDSW_LOADFILE  "-l"
#define CMDCNT_LOADFILE 2

/* Execute file to Saturn memory (Par1 = file, Par2 = start address). */
#define CMDSW_EXECFILE  "-x"
#define CMDCNT_EXECFILE  2

/* Execute + soft reset file to Saturn memory (Par1 = file, Par2 = start address, Par3 = reset flags). */
#define CMDSW_EXEC_EXT  "-xx"
#define CMDCNT_EXEC_EXT  3

/* Memset memory (Par1 = address, Par2 = value (8bits), Par3 = length (byte unit)). */
#define CMDSW_MEMSET  "-memset"
#define CMDCNT_MEMSET  3

/* Dump data from Saturn memory (Par1 = file, Par2 = start address, Par3 = length). */
#define CMDSW_DUMPFILE  "-d"
#define CMDCNT_DUMPFILE 3


/* Dump BIOS from Saturn memory (Par1 = file). */
#define CMDSW_DUMPBIOS  "-db"
#define CMDCNT_DUMPBIOS 1

/* Dump ARP FirmWare from Saturn memory (Par1 = file). */
#define CMDSW_DUMPFIRM  "-df"
#define CMDCNT_DUMPFIRM 1

/* Dump backup memory from Saturn memory (Par1 = file). */
#define CMDSW_BATSAVE   "-bs"
#define CMDCNT_BATSAVE  1

/* Send backup memory to Saturn memory (Par1 = file). */
#define CMDSW_BATLOAD   "-bl"
#define CMDCNT_BATLOAD  1


/* Display some informations about the target Saturn (No parameter). */
#define CMDSW_TGTINFO   "-target_info"
#define CMDCNT_TGTINFO  0

/* Takes a snapshot of the VDP1 framebuffer (No parameter). */
#define CMDSW_VDP1VIEW  "-vdp1view"
#define CMDCNT_VDP1VIEW 0

/* Show log window. */
#define CMDSW_SHOWLOG   "-showlog"
#define CMDCNT_SHOWLOG  0

/* Exit application. */
#define CMDSW_EXIT  "-exit"
#define CMDCNT_EXIT 0

/* Set something in GUI (Par1 = GUI object, Par2 = value). */
#define CMDSW_GUISET  "-gui_set"
#define CMDCNT_GUISET 2




#endif // _INIFILE_H_



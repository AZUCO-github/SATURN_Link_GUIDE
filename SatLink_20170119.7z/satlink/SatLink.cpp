//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("SatLink.res");
USEFORM("Unit1.cpp", Form1);
USEUNIT("ProcessThread.cpp");
USEUNIT("inifile.cpp");
USEUNIT("common\log.c");
USEUNIT("usbdl\usbdl.cpp");
USEUNIT("common\misc.c");
USEUNIT("common\portlib.c");
USEUNIT("parlink\parlink.cpp");
USEUNIT("parlink\parlink_legacy.cpp");
USEUNIT("..\satcom_lib\sc_common.c");
USEUNIT("dummy\dummy.cpp");
USEUNIT("common\lodepng.c");
USEUNIT("sh2\sh2d.c");
USEUNIT("sh2\iasm.c");
USEUNIT("usb_dev_cart\usbdc.cpp");
USEFORM("Unit2.cpp", Form2);
USEUNIT("ylink\sc_ylink.cpp");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->CreateForm(__classid(TForm1), &Form1);
                 Application->CreateForm(__classid(TForm2), &Form2);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------

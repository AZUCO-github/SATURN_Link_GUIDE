//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <Dialogs.hpp>

#include <stdio.h>
#include <stdarg.h>


#include "ProcessThread.h"
#include "inifile.h"
#include "ylink/sc_ylink.h" /* For vpar declarations. */
#include <ExtCtrls.hpp>
#include <Grids.hpp>
#include <Menus.hpp>
#include <ToolWin.hpp>

/* Status bar fields index. */
#define SB_TRANSFER_INDEX 0
#define SB_DEBUGGER_INDEX 1
#define SB_LOG_INDEX      2
#define SB_SPEED_INDEX    3
#define SB_VERSION_INDEX  4
/*
 * Status bar activity field.
 *  0~SB_ACTIVITY_MAXCOUNT-1 : transfering ...
 */
#define SB_ACTIVITY_MAXCOUNT 4
/*
 * Prompt display rate
 */
#define SB_PROMPT_DISP_RATE 6



/* Settings file related stuff. */
#define SET_FILE "satlink.ini"
#define SET_SECTION "satlink"
#define SET_BP_SECTION "breakpoints"
#define SET_STRSZ 8192
#define SET_MAXITEMS 256
//---------------------------------------------------------------------------
typedef struct
{
    TEdit* obj;
    char*  ent;
    char*  def;
} setting_edit_t;
typedef struct
{
    TCheckBox* obj;
    char*      ent;
    int        def;
} setting_checkbox_t;
typedef struct
{
    TComboBox* obj;
    char*      ent;
    int        typ; //0: save index, 1:save string
    int        save_itm;
    int        def0;
    char*      def1;
} setting_combobox_t;


//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TOpenDialog *odFile;
        TSaveDialog *sdFile;
        TStatusBar *StatusBar;
        TPageControl *pcSettings;
        TTabSheet *tsReadWrite;
        TGroupBox *GroupBox6;
        TLabel *Label9;
        TButton *btnDownSelect;
        TButton *btnDownload;
        TGroupBox *GroupBox7;
        TLabel *Label10;
        TButton *btnUpSelect;
        TButton *btnUpload;
        TGroupBox *GroupBox8;
        TLabel *Label6;
        TLabel *Label7;
        TLabel *Label8;
        TButton *btnTemplateSet;
        TComboBox *cbbTemplate;
        TLabel *Label3;
        TGroupBox *GroupBox3;
        TButton *btnOpen;
        TLabel *Label5;
        TTabSheet *tsMemView;
        TLabel *Label1;
        TButton *btnParamSet;
        TLabel *Label2;
        TButton *btnIniOpen;
        TProgressBar *pbTransfer;
        TTimer *tmStatusBarRefresh;
        TLabel *Label4;
        TLabel *Label11;
        TButton *btnMemView;
        TCheckBox *cbMemViewAuto;
        TButton *btnAdrDown;
        TButton *btnAdrUp;
        TComboBox *cbbParamText;
        TComboBox *cbbParamValue;
        TButton *btnClose;
        TTimer *tmMemviewRefresh;
        TButton *btnTest2;
        TButton *btnTest3;
        TTabSheet *tsDataLinkDBG;
        TButton *btnTest1;
        TTabSheet *tsExtra1;
        TGroupBox *GroupBox5;
        TButton *btnTargetInfo;
        TGroupBox *GroupBox11;
        TButton *btnVDP1View;
        TPanel *pnVDP1;
        TImage *imgVDP1;
        TMainMenu *MainMenu1;
        TMenuItem *mniDevice;
        TMenuItem *mniSend;
        TMenuItem *mniReceive;
        TMenuItem *mniReceiveBackupMemory;
        TMenuItem *mniReceiveBIOS;
        TMenuItem *mniReceiveCartFlash;
        TMenuItem *mniSendBackupMemory;
        TMenuItem *mniSetUSBDataLinkParameters;
        TMenuItem *mniOpenUSBDataLink;
        TMenuItem *mniExecProgram;
        TGroupBox *GroupBox12;
        TButton *btnUDLGo;
        TLabel *Label20;
        TEdit *edtUDLPort;
        TEdit *edtUDLColor;
        TLabel *Label25;
        TLabel *Label26;
        TEdit *edtUDLAddress;
        TEdit *edtUDLLen;
        TLabel *Label27;
        TLabel *Label28;
        TEdit *edtUDLCount;
        TGroupBox *GroupBox13;
        TEdit *edtParWriteVal;
        TLabel *Label29;
        TLabel *Label30;
        TEdit *edtParReadVal;
        TLabel *Label31;
        TLabel *Label32;
        TButton *btnParExchange;
        TButton *btnParOpen;
        TButton *btnParClose;
        TComboBox *cbParOffset;
        TButton *btnParRead;
        TButton *btnParWrite;
        TCheckBox *cbParExcInc;
        TButton *btnParMacro;
        TEdit *edtParExchangeLoop;
        TButton *btnParExchangeLoop;
        TLabel *Label34;
        TTabSheet *tsRegisters;
        TLabel *Label35;
        TEdit *edtRegisterLength;
        TLabel *Label37;
        TButton *btnRegisterWrite;
        TMemo *mRegisterLog;
        TEdit *edtRegistersMacro;
        TLabel *Label38;
        TButton *btnRegisterExec;
        TComboBox *cbbRegistersAddress;
        TButton *btnRegisterRead;
        TLabel *Label36;
        TEdit *edtRegisterValue;
        TButton *btnRegLogClear;
        TTabSheet *tsDebuggerSub2;
        TTabSheet *tsSettings;
        TGroupBox *GroupBox18;
        TButton *btnMemViewVDP2CRAM;
        TButton *btnMemViewDbgData;
        TTimer *tmVparRefresh;
        TButton *btnMemViewGlobalDataL;
        TPageControl *pcMemEdit;
        TTabSheet *tsMemViewBinary;
        TTabSheet *tsMemViewDisasm;
        TGroupBox *GroupBox14;
        TStringGrid *sgMemConvert;
        TGroupBox *GroupBox9;
        TComboBox *cbbMemoryConvert;
        TComboBox *cbbMemSize;
        TGroupBox *GroupBox20;
        TStringGrid *sgSh2Dis;
        TButton *btnAdrPrev2;
        TButton *btnAdrNext2;
        TGroupBox *GroupBox21;
        TLabel *Label41;
        TEdit *edtMemFindVal;
        TLabel *Label43;
        TEdit *edtMemFindRange;
        TButton *btnMemFind;
        TTabSheet *tsMemViewIAsm;
        TMenuItem *mniOpenCurrentDevice;
        TGroupBox *GroupBox22;
        TCheckBox *cbDisasmMem;
        TGroupBox *GroupBox23;
        TLabel *Label44;
        TEdit *edtIasmText;
        TButton *btnIasmExec;
        TButton *btnAsmExec;
        TEdit *edtIasmOpCode;
        TLabel *Label45;
        TTabSheet *tsMemViewRGB;
        TPanel *pnMemViewRGB;
        TImage *imgMemViewRGB;
        TButton *btnMemViewRGB;
        TLabel *Label46;
        TLabel *Label47;
        TEdit *edtMemViewRGBw;
        TEdit *edtMemViewRGBh;
        TLabel *Label48;
        TPageControl *pcYabause;
        TTabSheet *tsYabVdp;
        TCheckBox *cbYabVdp2Log;
        TCheckBox *cbYabAllDisp;
        TCheckBox *cbYabDiffDisp;
        TCheckBox *cbYabSaveRef;
        TCheckBox *cbYabDump;
        TCheckBox *cbYabVdp1Log;
        TCheckBox *cbYabVdp1Reg;
        TCheckBox *cbYabVdp1Cmd;
        TCheckBox *cbYabVdp1Dmp;
        TTabSheet *tsYabCommon;
        TLabel *Label42;
        TLabel *Label40;
        TEdit *edtYabPollInterval;
        TEdit *edtYabLogPath;
        TTabSheet *tsYabExtra;
        TCheckBox *cbSatCartEmu;
        TTabSheet *tsYabDbg;
        TEdit *edtParPortAddress;
        TLabel *Label33;
        TGroupBox *GroupBox15;
        TLabel *Label49;
        TEdit *edtYabPC;
        TLabel *Label50;
        TEdit *edtYabRWAddr;
        TLabel *Label51;
        TEdit *edtYabMoniInterval;
        TLabel *Label52;
        TComboBox *cbbIniPath;
        TCheckBox *cdFDisasm;
        TEdit *edtFDisasmPath;
        TEdit *edtFDisasmOffset;
        TLabel *Label53;
        TLabel *Label54;
        TLabel *Label55;
        TEdit *edtFDisasmAddress;
        TCheckBox *cbYabSH2Trace;
        TGroupBox *GroupBox24;
        TLabel *Label56;
        TEdit *edtDisasmLen;
        TButton *btnDisassemble;
        TCheckBox *cbYabSH2KeyTrace;
        TLabel *Label58;
        TGroupBox *GroupBox25;
        TCheckBox *cbYabLogEtc;
        TCheckBox *cbYabLogSCSP;
        TCheckBox *cbYabLogCD;
        TCheckBox *cbYabLogSMPC;
        TCheckBox *cbYabLogVDP1;
        TCheckBox *cbYabLogVDP2;
        TGroupBox *GroupBox26;
        TCheckBox *cbYabLogsEtc;
        TGroupBox *GroupBox27;
        TCheckBox *cbVparLogOut;
        TCheckBox *cbYabLinkEmuLog;
        TCheckBox *cbYabLogsInterrupt;
        TCheckBox *cbYabLogsUbc;
        TCheckBox *cbYabLogsVdp1;
        TCheckBox *cbYabLogsVdp2;
        TCheckBox *cbYabLogsDbgr;
        TLabel *Label59;
        TEdit *edtYabSdPath;
        TCheckBox *cbYabLogsSdc;
        TLabel *Label61;
        TLabel *Label63;
        TButton *btnMemViewGlobalDataS;
        TMenuItem *OpenUSBDevCart;
        TLabel *Label64;
        TCheckBox *cbYabLogSh2;
        TCheckBox *cbMemViewRGBRfrsh;
        TTrackBar *tbMemViewRGBRefreshMemory;
        TLabel *Label65;
        TTabSheet *tsMemset;
        TLabel *Label66;
        TEdit *edtMemsetLength;
        TLabel *Label67;
        TEdit *edtMemsetValue;
        TButton *btnMemset;
        TButton *btnRegLogSave;
        TLabel *Label68;
        TMenuItem *mniShowLogOutput;
        TButton *btnSdCmd0Test;
        TStringGrid *sgSdTest;
        TLabel *Label12;
        TLabel *Label14;
        TEdit *edtSdRetry;
        TLabel *Label15;
        TEdit *edtSdWait;
        TPageControl *pcLog;
        TTabSheet *tsAppliLog;
        TMemo *mLog;
        TTabSheet *tsYabauseLog;
        TGroupBox *GroupBox17;
        TLabel *Label21;
        TLabel *Label39;
        TLabel *Label57;
        TEdit *edtYabUpdtCntrs;
        TEdit *edtYabLastFile;
        TEdit *edtYabKeyTrace;
        TGroupBox *GroupBox16;
        TStringGrid *sgYabLinkMonitor;
        TComboBox *cbbMemViewAddress;
        TComboBox *cbbStartAddress;
        TComboBox *cbbDownFile;
        TComboBox *cbbUpFile;
        TComboBox *cbbLength;
        TCheckBox *cbYabLogNetLink;
        TCheckBox *cbYabLinkEmu;
        TCheckBox *cbSatCartSw1;
        TLabel *Label16;
        TEdit *edtSatCartId;
        TGroupBox *GroupBox2;
        TCheckBox *cbSoftResHram;
        TCheckBox *cbSoftResLram;
        TCheckBox *cbSoftResVDP1regs;
        TCheckBox *cbSoftResVDP1ram;
        TCheckBox *cbSoftResVDP2regs;
        TCheckBox *cbSoftResVDP2ram;
        TButton *btnExecute;
        TPageControl *psSettingsTab;
        TTabSheet *tsDebuggerSettings;
        TTabSheet *tsLogSettings;
        TGroupBox *GroupBox10;
        TLabel *Label22;
        TLabel *Label23;
        TLabel *Label24;
        TLabel *Label19;
        TComboBox *cbbLogType;
        TComboBox *cbbLogOutput;
        TButton *btnLogLevelSet;
        TComboBox *cbbLogLevel;
        TEdit *edtLogSettings;
        TButton *btnLogLdSettings;
        TCheckBox *cbSilentDbg;
        TButton *btnLogSilent;
        TButton *btnLogOn;
        TGroupBox *GroupBox19;
        TLabel *Label13;
        TButton *btnMainLogSave;
        TButton *btnMainLogClear;
        TEdit *edtMainLogPath;
        TGroupBox *GroupBox1;
        TButton *btnClearHistory;
        TGroupBox *gbLogLevels;
        TMemo *mLogLevels;
        TButton *btnLogLevelsGet;
        TGroupBox *GroupBox4;
        TLabel *Label18;
        TLabel *Label60;
        TLabel *Label62;
        TLabel *Label69;
        TLabel *lblDebugFolder;
        TEdit *edtDbgFile;
        TEdit *edtDbgStartAddress;
        TButton *btnFastExec;
        TButton *btnSetDbgFolder;
        TEdit *edtDbgFolder;
        TGroupBox *GroupBox28;
        TLabel *Label70;
        TEdit *edtDebugSleep;
        TCheckBox *cbDbgLogDate;
        TCheckBox *cbDbgLogFlush;
        TCheckBox *cbWhOnLog;
        TTabSheet *tsYabBreakPoints;
        TStringGrid *sgBpList;
        TGroupBox *GroupBox29;
        TLabel *Label71;
        TComboBox *cbBpType;
        TLabel *Label72;
        TButton *btnBpCopy;
        TButton *btnBpPaste;
        TCheckBox *cbBpReadByte;
        TCheckBox *cbBpReadWord;
        TCheckBox *cbBpReadLong;
        TLabel *lblBpReadAccess;
        TCheckBox *cbBpWriteByte;
        TCheckBox *cbBpWriteWord;
        TCheckBox *cbBpWriteLong;
        TEdit *edtBpAddress;
        TEdit *edtBpValue;
        TButton *btnBpSave;
        TCheckBox *cbBpAddressCheck;
        TLabel *lblRegisterValue;
        TLabel *lblBpWriteAccess;
        TLabel *Label81;
        TLabel *Label82;
        TLabel *Label83;
        TGroupBox *GroupBox30;
        TCheckBox *cbYabLogFileLine;
        TCheckBox *cbYabLogPcReg;
        TCheckBox *cbYabausePcTrace;
        TEdit *edtYabauseTraceAddr;
        TLabel *Label17;
        TCheckBox *cbYabRlog;
        TLabel *Label84;
        TComboBox *cbSatLinkLogLevel;
        TCheckBox *CheckBox1;
        TLabel *Label85;
        TEdit *Edit1;
        TButton *Button1;
        TMemo *Memo1;
        TLabel *lblAddressVal;
        TLabel *lblAddressMask;
        TLabel *lblValueMask;
        TLabel *lblValueVal;
        TLabel *Label74;
        TEdit *edtBpName;
        TLabel *lblBpAddressText;
        TMemo *Memo2;
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall btnClick(TObject *Sender);
        void __fastcall btnDownSelectClick(TObject *Sender);
        void __fastcall btnUpSelectClick(TObject *Sender);
        void __fastcall btnIniOpenClick(TObject *Sender);
        void __fastcall btnTemplateSetClick(TObject *Sender);
        void __fastcall tmStatusBarRefreshTimer(TObject *Sender);
        void __fastcall sgMemorySelectCell(TObject *Sender, int ACol,
          int ARow, bool &CanSelect);
        void __fastcall cbbMemoryConvertChange(TObject *Sender);
        void __fastcall tmMemviewRefreshTimer(TObject *Sender);
        void __fastcall btnTest2Click(TObject *Sender);
        void __fastcall btnTest3Click(TObject *Sender);
        void __fastcall btnUDLGoClick(TObject *Sender);
        void __fastcall sgMemConvertDrawCell(TObject *Sender, int ACol,
          int ARow, TRect &Rect, TGridDrawState State);
        void __fastcall btnMemViewVDP2CRAMClick(TObject *Sender);
        void __fastcall btnLogLevelsGetClick(TObject *Sender);
        void __fastcall mniClick(TObject *Sender);
        void __fastcall mniSetUSBDataLinkParametersClick(TObject *Sender);
        void __fastcall btnParExchangeClick(TObject *Sender);
        void __fastcall btnParOpenClick(TObject *Sender);
        void __fastcall btnParCloseClick(TObject *Sender);
        void __fastcall btnParWriteClick(TObject *Sender);
        void __fastcall btnParReadClick(TObject *Sender);
        void __fastcall btnParMacroClick(TObject *Sender);
        void __fastcall btnParExchangeLoopClick(TObject *Sender);
        void __fastcall cbbRegistersAddressChange(TObject *Sender);
        void __fastcall btnMemViewDbgDataClick(TObject *Sender);
        void __fastcall tmVparRefreshTimer(TObject *Sender);
        void __fastcall btnMemViewGlobalDataLClick(TObject *Sender);
        void __fastcall sgMemConvertSetEditText(TObject *Sender, int ACol,
          int ARow, const AnsiString Value);
        void __fastcall sgMemConvertKeyPress(TObject *Sender, char &Key);
        void __fastcall edtMemViewAddressKeyPress(TObject *Sender,
          char &Key);
        void __fastcall sgSh2DisDrawCell(TObject *Sender, int ACol,
          int ARow, TRect &Rect, TGridDrawState State);
        void __fastcall edtMemFindValKeyPress(TObject *Sender, char &Key);
        void __fastcall mniOpenCurrentDeviceClick(TObject *Sender);
        void __fastcall btnIasmExecClick(TObject *Sender);
        void __fastcall edtIasmTextKeyPress(TObject *Sender, char &Key);
        void __fastcall btnAsmExecClick(TObject *Sender);
        void __fastcall edtIasmOpCodeKeyPress(TObject *Sender, char &Key);
        void __fastcall btnMemViewGlobalDataSClick(TObject *Sender);
        void __fastcall edtKeyPress(TObject *Sender, char &Key);
        void __fastcall tbMemViewRGBRefreshMemoryChange(TObject *Sender);
        void __fastcall btnRegLogSaveClick(TObject *Sender);
        void __fastcall mniShowLogOutputClick(TObject *Sender);
        void __fastcall btnSdCmd0TestClick(TObject *Sender);
        void __fastcall btnClearHistoryClick(TObject *Sender);
        void __fastcall sgBpListClick(TObject *Sender);
        void __fastcall btnBpSaveClick(TObject *Sender);
        void __fastcall cbBpTypeChange(TObject *Sender);
        void __fastcall FormDestroy(TObject *Sender);
private:	// User declarations
        unsigned long ulCloseCount;
        void __fastcall ProcessThreadEnd(TObject *Sender);
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);

        /*--- Command line related ---*/
        char cl_buffer[8192];
        char inifilebuffer[INIFILE_MAXSIZE];
        int argc;
        char* argv[MAXARGS];
        int iShowLogWindow;

        ProcessThread *thProcessThread;

        /*--- VPar DLL related ---*/
        vpar_shared_memory_t* vpar_sm;

        void /*__fastcall*/ VparElementDisplay(int row, char* s, char* fmt, ...);
        void __fastcall VparSeparatorDisplay(int row, char* s);


        /*--- Logging related. ---*/
        void /*__fastcall*/ LogOut(const char *string, ...);

        /*--- Settings related. ---*/
        AnsiString __fastcall MakeSettingsFilePath(void);
        void __fastcall GUI_Set_Object(char* obj, char* val);
        void __fastcall LoadSettingsFile(void);
        void __fastcall SaveSettingsFile(void);

        /*--- GUI related. ---*/
        char app_path[MAX_PATH];
        char app_name[MAX_PATH];
        UserData udGUI;
        int iDebugUse;
        int iVDP1ScreenID;
        void __fastcall RemoveComboBoxItems(TComboBox* obj);
        void __fastcall AddComboBoxItem(TComboBox* obj);
        void __fastcall InitFormItems(void);
        void __fastcall SaveFormItems(void);
        unsigned long __fastcall ConvertLengthToByte(char* str);

        /*--- Yabause Breakpoints stuff. ---*/
        int iYabBpCurrentId;
        vpar_bp_settings clsYabBpSet;
        void __fastcall YabauseBpParseValMask(char* str, unsigned long* val, unsigned long* mask);
        void __fastcall YabauseBpHideShowItems(void);
        void __fastcall YabauseBpLoadToGui(int id);
        void __fastcall YabauseBpLoadFromGuiAndSave(int id);

#define GUI_STRCPY(_DST_, _SRC_, _LEN_) strncpy((_DST_), (_SRC_), (_LEN_)-1); (_DST_)[(_LEN_) - 1] = '\0';
        void __fastcall SaveToUserData(void);
        void __fastcall LoadFromUserData(void);

        // For SD card SPI test.
        unsigned short __fastcall SdSpiSend(unsigned char cs, unsigned char val, unsigned long wait_val);

};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif

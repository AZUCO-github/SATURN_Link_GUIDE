/* 
 * This software is licensed under terms of the GNU GENERAL PUBLIC LICENSE
 *
 * This software is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This software  is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this software.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Source code is available at http://ppcenter.free.fr
 */

#ifndef _INCLUDE_PARLINK_H_
#define _INCLUDE_PARLINK_H_


#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <malloc.h>
#include <string.h>


#include "../common/satcom.h"
#include "sc_parlink.h"

#include "../common/portlib.h"
#include "../common/misc.h"


////////////////////////////////////////////////////////////////////////
// Generic parallel port interface DLL
// Supported links :
//  - Commslink (UNTESTED)
//  - Freewing  (UNTESTED)
// (based from satutil by Charles MacDonald, http://cgfm2.emuviews.com )
////////////////////////////////////////////////////////////////////////

/* Used for transmission statistics. */
void par_reset_exchanged_bytes(void);
unsigned long par_get_exchanged_bytes(void);


/* Transmission parameters. */
extern unsigned long _port_init;
extern unsigned long _port_value;

/* Supported link devices. */
#define LINK_DEVICE_COMMS    0
#define LINK_DEVICE_FREEWING 1
#define LINK_DEVICE_EXSTAND  2
extern unsigned long _link_type;


/* Max loop count when polling data (in order to avoid infinite loops) */
extern unsigned long _loop_max;

/* Max retry count when getting a packet.                              */
extern unsigned long _checksum_retry;

/* Size of the packets used when receiving/sending data.               */
extern unsigned long _rcv_packet_size;
extern unsigned long _snd_packet_size;

/* Recovery alogrithm to use when receiving/sending data.              */
extern unsigned long _rcv_recovery;
extern unsigned long _snd_recovery;


/* Freewing : Max iteration until waiting Busy signal to become `H'                                                  */
/*  Setting to 0 (original Freewing software driver) makes polling fast, but PC->Sat transmission errors may happen. */
/*  Setting to 5 should be reasonable trade-off between speed and data realiability.                                 */
extern unsigned long _busyon_loop_max;

/* Use (or not) compression when sending/receiving data.               */
extern unsigned long _use_compression;


/* Legacy functions. */
void par_reset_signals(void);
unsigned char par_exchange_byte(unsigned char value);
unsigned short par_exchange_word(unsigned short data);
unsigned long par_exchange_long(unsigned long data);


#endif // _INCLUDE_PARLINK_H_


//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "Unit2.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm2 *Form2;
//---------------------------------------------------------------------------
__fastcall TForm2::TForm2(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm2::FormClose(TObject *Sender, TCloseAction &Action)
{
    // SaveFormItems, etc is called from form1
    Form1->Close();
}
//---------------------------------------------------------------------------
void __fastcall TForm2::btnClick(TObject *Sender)
{
    TButton* pButton = (TButton*)Sender;
    Form1->udGUI.btn[pButton->Tag] = 1;
}
//---------------------------------------------------------------------------



/* Settings file related stuff. */
setting_edit_t _setting_f2_edit[SET_MAXITEMS];
setting_checkbox_t _setting_f2_checkbox[SET_MAXITEMS];
setting_combobox_t _setting_f2_combobox[SET_MAXITEMS];

AnsiString __fastcall TForm2::MakeSettingsFilePath(void)
{
    /* Must init items list after the form constructor has been called. */
    int i;
    /* Set edit stuff. */
    i = 0;
    _setting_f2_edit[i].obj = edtLogPath         ; _setting_f2_edit[i].ent = "dbg_log"            ; _setting_f2_edit[i].def = "satlink_dbg.log"     ; i++;
    _setting_f2_edit[i].obj = edtDbgPrompt       ; _setting_f2_edit[i].ent = "dbg_prompt"         ; _setting_f2_edit[i].def = "hello!"              ; i++;
    _setting_f2_edit[i].obj = NULL               ; _setting_f2_edit[i].ent = NULL                 ; _setting_f2_edit[i].def = NULL                  ; //i++;


    /* Set checkbox stuff. */
    i = 0;
    _setting_f2_checkbox[i].obj = cbDbgEnable        ; _setting_f2_checkbox[i].ent = "dbg_enable"        ; _setting_f2_checkbox[i].def = 1; i++;
    _setting_f2_checkbox[i].obj = NULL               ; _setting_f2_checkbox[i].ent = NULL                ; _setting_f2_checkbox[i].def = 0; //i++;

    /* Set combo box stuff. */
    i = 0;

    _setting_f2_combobox[i].obj = NULL               ; _setting_f2_combobox[i].ent = NULL           ; _setting_f2_combobox[i].typ = 0; _setting_f2_combobox[i].def0 = 0;  _setting_f2_combobox[i].def1 = NULL               ; //i++;



    /* Set settings file path. */
    AnsiString sIniPath = Form1->app_path;
    sIniPath += SET_FILE;

    return sIniPath;
}

//---------------------------------------------------------------------------
void __fastcall TForm2::LoadSettingsFile(void)
{
    AnsiString sIniPath = MakeSettingsFilePath();
    char sData[SET_STRSZ];

    int i;
    int iValue;
    /* Edit. */
    i=0; while(_setting_f2_edit[i].obj != NULL)
    {
        GetPrivateProfileString(SET_SECTION, _setting_f2_edit[i].ent, _setting_f2_edit[i].def, sData, SET_STRSZ, sIniPath.c_str());
        _setting_f2_edit[i].obj->Text = sData;
        i++;
    }
    /* Check box. */
    i=0; while(_setting_f2_checkbox[i].obj != NULL)
    {
        iValue = (int)GetPrivateProfileInt(SET_SECTION, _setting_f2_checkbox[i].ent, _setting_f2_checkbox[i].def, sIniPath.c_str());
        _setting_f2_checkbox[i].obj->Checked = (iValue ? true : false);
        i++;
    }
    /* Combo box. */
    i=0; while(_setting_f2_combobox[i].obj != NULL)
    {
        if(_setting_f2_combobox[i].typ == 0)
        { /* Use combo box index. */
            iValue = (int)GetPrivateProfileInt(SET_SECTION, _setting_f2_combobox[i].ent, _setting_f2_combobox[i].def0, sIniPath.c_str());
            _setting_f2_combobox[i].obj->ItemIndex = (iValue == -1 ? 0 : iValue);
        }
        else
        { /* Use combo box text. */
            GetPrivateProfileString(SET_SECTION, _setting_f2_combobox[i].ent, _setting_f2_combobox[i].def1, sData, SET_STRSZ, sIniPath.c_str());
            _setting_f2_combobox[i].obj->Text = sData;
        }
        i++;
    }

    /* Window position. */
    Form2->Top  = (int)GetPrivateProfileInt(SET_SECTION, "form2_top" , 0, sIniPath.c_str());
    Form2->Left = (int)GetPrivateProfileInt(SET_SECTION, "form2_left", 0, sIniPath.c_str());
}

//---------------------------------------------------------------------------
void __fastcall TForm2::SaveSettingsFile(void)
{
    AnsiString sIniPath = MakeSettingsFilePath();

    int i;
    char str[128];
    /* Edit. */
    i=0; while(_setting_f2_edit[i].obj != NULL)
    {
        WritePrivateProfileString(SET_SECTION, _setting_f2_edit[i].ent, _setting_f2_edit[i].obj->Text.c_str(), sIniPath.c_str());
        i++;
    }
    /* Check box. */
    unsigned long ulValue;
    i=0; while(_setting_f2_checkbox[i].obj != NULL)
    {
        WritePrivateProfileString(SET_SECTION, _setting_f2_checkbox[i].ent, (_setting_f2_checkbox[i].obj->Checked ? "1" : "0"), sIniPath.c_str());
        i++;
    }
    /* Combo box. */
    i=0; while(_setting_f2_combobox[i].obj != NULL)
    {
        if(_setting_f2_combobox[i].typ == 0)
        { /* Use combo box index. */
            sprintf(str, "%d", _setting_f2_combobox[i].obj->ItemIndex);
            WritePrivateProfileString(SET_SECTION, _setting_f2_combobox[i].ent, str, sIniPath.c_str());
        }
        else
        { /* Use combo box text. */
            WritePrivateProfileString(SET_SECTION, _setting_f2_combobox[i].ent, _setting_f2_combobox[i].obj->Text.c_str(), sIniPath.c_str());
        }
        i++;
    }

    /* Window position. */
    sprintf(str, "%d", Form2->Top ); WritePrivateProfileString(SET_SECTION, "form2_top" , str, sIniPath.c_str());
    sprintf(str, "%d", Form2->Left); WritePrivateProfileString(SET_SECTION, "form2_left", str, sIniPath.c_str());
}

/* Init, and load form contents from file. */
void __fastcall TForm2::InitFormItems(void)
{
    btnFastExec2->Tag     = BTN_FASTEXEC;
    btnLogClear->Tag      = BTN_LOGCLEAR;
    btnLogSave->Tag       = BTN_LOGSAVE;
    btnPromptSend->Tag    = BTN_PROMPTSEND;

    /* Load GUI settings. */
    LoadSettingsFile();
}
//---------------------------------------------------------------------------

/* Save form contents to file. */
void __fastcall TForm2::SaveFormItems(void)
{
    /* Don't save anything in the case this form hasn't been displayed. */
    if(!Form2->Visible) return;

    /* save GUI settings. */
    SaveSettingsFile();
}


/* Save GUI contents to UserData (called by ProcessThread) */
void __fastcall TForm2::SaveToUserData(void)
{
    Form1->udGUI.dbg_use      = (cbDbgUse->Checked ? 1 : 0);
    Form1->udGUI.dbg_enable   = (cbDbgEnable->Checked ? 1 : 0);
    GUI_STRCPY(Form1->udGUI.log_file      , edtLogPath->Text.c_str()         , STR_LEN);
    GUI_STRCPY(Form1->udGUI.prompt_answer , edtDbgPrompt->Text.c_str()       , STR_LEN);
}

void __fastcall TForm2::edtDbgPromptKeyPress(TObject *Sender, char &Key)
{
    //if(udGUI.prompt_on)
    //{
    if((Key == '\r') || (Key == '\n'))
    {
        btnClick((TObject *)btnPromptSend);
    }
    //}       
}
//---------------------------------------------------------------------------

void __fastcall TForm2::edtKeyPress(TObject *Sender, char &Key)
{
    if((Key == '\r') || (Key == '\n'))
    {
        TEdit*     edtSrc = (TEdit    *)Sender;
        TComboBox*  cbSrc = (TComboBox*)Sender;

        /* [Debugger]Save to disk when log file is entered. */
        if(edtSrc == edtLogPath)
        {
            btnClick((TObject*)btnLogSave);
        }

    }
}
//---------------------------------------------------------------------------


void __fastcall TForm2::FormShow(TObject *Sender)
{
    /* Init form items. */
    InitFormItems();

    // Automatically enable satcom log output.
    cbDbgUse->Checked = true;
}
//---------------------------------------------------------------------------

void __fastcall TForm2::FormCreate(TObject *Sender)
{

    /* Log grid init. */
    sgDbgText->RowCount = 256;
    sgDbgText->ColCount = 2;
    sgDbgText->Cells[0][0] = "ID";
    for(int i=1; i<sgDbgText->RowCount; i++) sgDbgText->Cells[0][i] = IntToStr(i);
    sgDbgText->ColWidths[0] = 30;
    sgDbgText->Cells[1][0] = "Message";
    sgDbgText->ColWidths[1] = 268;
}
//---------------------------------------------------------------------------





//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "Unit2.h"
#include "UserData.h"


//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
        , thProcessThread(NULL)
        , ulCloseCount(0)
        , iDebugUse(0)
{
    /* Get path where the program is. */
    char szPath[MAX_PATH];
    GetModuleFileName(GetModuleHandle(NULL), szPath, MAX_PATH);
    AnsiString sAppPath;
    sAppPath.printf("%s", szPath);
    int iLast = sAppPath.LastDelimiter("\\");
    sAppPath = sAppPath.SubString(1, iLast);
    strcpy(app_path, sAppPath.c_str());
    AnsiString sAppName;
    sAppName.printf("%s", szPath);
    sAppName = sAppName.SubString(iLast+1, MAX_PATH-iLast);
    strcpy(app_name, sAppName.c_str());


    /* Allocate buffer for SatLink <-> Yabause shared memory. */
    vpar_sm = (vpar_shared_memory_t*)malloc(sizeof(vpar_shared_memory_t));
    memset((void*)vpar_sm, 0, sizeof(vpar_shared_memory_t));

    /* Load Vpar DLL. */
    _vpar_init = (VparInit() == 0 ? 0 : 1);


    /* Reset buttons state. */
    memset((void*)(&udGUI), 0, sizeof(UserData));
    /* Request debug folder init. */
    udGUI.btn[BTN_DBGFOLDER] = 1;
}
//---------------------------------------------------------------------------
//http://gnuwin32.sourceforge.net/version.c.txt
BOOL GetAppVersion( char *LibName, WORD *MajorVersion, WORD *MinorVersion, WORD *BuildNumber, WORD *RevisionNumber )
{
    DWORD dwHandle, dwLen;
    UINT BufLen;
    LPTSTR lpData;
    VS_FIXEDFILEINFO *pFileInfo;
    dwLen = GetFileVersionInfoSize( LibName, &dwHandle );
    if (!dwLen)
    {
        return FALSE;
    }

    lpData = (LPTSTR) malloc (dwLen);
    if (!lpData)
    {
        return FALSE;
    }

    if( !GetFileVersionInfo( LibName, dwHandle, dwLen, lpData ) )
    {
        free (lpData);
        return FALSE;
    }
    if( VerQueryValue( lpData, "\\", (LPVOID *) &pFileInfo, (PUINT)&BufLen ) )
    {
        *MajorVersion = HIWORD(pFileInfo->dwFileVersionMS);
        *MinorVersion = LOWORD(pFileInfo->dwFileVersionMS);
        *BuildNumber = HIWORD(pFileInfo->dwFileVersionLS);
        *RevisionNumber = LOWORD(pFileInfo->dwFileVersionLS);
        free (lpData);
        return TRUE;
    }
    free (lpData);
    return FALSE;
}
//---------------------------------------------------------------------------
scl_settings_t _log_global_settings;
void __fastcall TForm1::FormCreate(TObject *Sender)
{
    WORD ver[4];
    GetAppVersion(Application->ExeName.c_str(), ver+0, ver+1, ver+2, ver+3);
    AnsiString str;
    str.printf("SatCom debugger Ver.%d.%d.%d%d [Build %s, %s]", ver[0], ver[1], ver[2], ver[3], __DATE__, __TIME__);
    Form1->Caption = str;

    /* Init log engine. */
    scl_init(&_log_global_settings, 1/*satlink_init*/);

    /* Init form items. */
    InitFormItems();

    /* Parse command line. */
    memset((void*)cl_buffer, 0, sizeof(cl_buffer));
    argc=0;
    for(int i=0; i<MAXARGS; i++) argv[i] = NULL;

    int cl_buffer_pos = 0;
    for(int i=0; i<=ParamCount(); i++)
    {
        if(i==1)
        {
            /* Append parameters from ini file. */
            parse_satlink_inifile(inifilebuffer, ParamStr(i).c_str()/*filename*/, &argc, argv);
        }
        else
        {
            /* Append parameters from command line. */
            AnsiString str = ParamStr(i);
            int strl = str.Length();
            argv[argc] = cl_buffer + cl_buffer_pos; argc++;
            for(int i=0; i<strl; i++)
            {
                cl_buffer[cl_buffer_pos] = str[i+1]; cl_buffer_pos++;
            }
            cl_buffer[cl_buffer_pos] = '\0'; cl_buffer_pos++;
        }
    }


    /* Register Write stuff. */
    int i=0;
    cbbRegistersAddress->Items->Clear();
    while(regs_list[i].siz != 0)
    {
        cbbRegistersAddress->Items->Add(regs_list[i].nam);
        i++;
    }


    /* Start Send/Receive/Debuger thread. */
    this->iShowLogWindow = 0;

    thProcessThread = new ProcessThread(false);
    thProcessThread->OnTerminate = ProcessThreadEnd;
    strcpy(thProcessThread->app_path, app_path);

    /* Start status bar refresh timer. */
    tmStatusBarRefresh->Enabled = true;
    /* Start memview convert refresh timer. */
    tmMemviewRefresh->Enabled = true;
    /* Start VPar set/refresh timer. */
    tmVparRefresh->Enabled = true;

    //EnableWindow(Handle, false);
}
//---------------------------------------------------------------------------
void __fastcall  TForm1::ProcessThreadEnd(TObject *Sender)
{
    //EnableWindow(Handle, true);

    delete thProcessThread;
    thProcessThread = NULL;

    //this->DoDestroy();
    DoClose(caFree);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormClose(TObject *Sender, TCloseAction &Action)
{
    SaveFormItems();
    Form2->SaveFormItems();

    if(thProcessThread)
    {
        /* Abort current transfer, if any. */
        SatCom* pSc = thProcessThread->pSc;
        if(pSc)
        {
            pSc->AbortTransfer();
        }

        /* End logging engine. */
        scl_end();

        Form1->mLog->Lines->Add("Waiting for thread to close ...");
        ulCloseCount++;
        /* If it is the first time exit button is clicked,
         * give some time for the thread to exit.
         */
        if(ulCloseCount < 2) Action = caNone;
        thProcessThread->Terminate();
        thProcessThread->iTerminateRequest = 1;

        /* Stop timers. */
        tmStatusBarRefresh->Enabled = false;
        tmMemviewRefresh->Enabled = false;
        tmVparRefresh->Enabled = false;
    }
    else
    {
        /* End logging engine. */
        scl_end();

        Form1->mLog->Lines->Add("Thread ended. You can exit the application.");
        Action = caFree;
        exit(0);
    }
}

//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
    /* Release VPar DLL handle and associated local buffer(s). */
    _vpar_init = 0;
    VparClose();

    if(vpar_sm)
    {
        free(vpar_sm);
        vpar_sm = NULL;
    }
}

//---------------------------------------------------------------------------
void /*__fastcall*/ TForm1::LogOut(const char *string, ...)
{
    /* Format to memory */
    char str[8192];
    va_list argptr;
    va_start(argptr, string);
    vsnprintf(str, sizeof(str), string, argptr);
    va_end(argptr);

    /* Add date */
    char strout[8192];
    if(strlen(str) != 0)
    {
        SYSTEMTIME sTime;
        GetLocalTime(&sTime);
        snprintf(strout, sizeof(strout), "[%02d:%02d:%02d:%03d]%s",
                    sTime.wHour, sTime.wMinute, sTime.wSecond, sTime.wMilliseconds,
                    str);
    }
    else
    {
        snprintf(strout, sizeof(strout), "");
    }

    mLog->Lines->Add(strout);
}
//---------------------------------------------------------------------------


/* Settings file related stuff. */
setting_edit_t _setting_edit[SET_MAXITEMS];
setting_checkbox_t _setting_checkbox[SET_MAXITEMS];
setting_combobox_t _setting_combobox[SET_MAXITEMS];

AnsiString __fastcall TForm1::MakeSettingsFilePath(void)
{
    /* Must init items list after the form constructor has been called. */
    int i;
    /* Set edit stuff. */
    i = 0;
    _setting_edit[i].obj = edtMainLogPath     ; _setting_edit[i].ent = "main_dbg_log"       ; _setting_edit[i].def = "satlink_main.log"    ; i++;
    _setting_edit[i].obj = edtLogSettings     ; _setting_edit[i].ent = "dbg_settings"       ; _setting_edit[i].def = "log_settings.ini"    ; i++;
    _setting_edit[i].obj = edtMemsetValue     ; _setting_edit[i].ent = "memset_val"         ; _setting_edit[i].def = "0xFF"                ; i++;
    _setting_edit[i].obj = edtMemsetLength    ; _setting_edit[i].ent = "memset_len"         ; _setting_edit[i].def = "256"                 ; i++;
    _setting_edit[i].obj = edtMemFindVal      ; _setting_edit[i].ent = "memfind_val"        ; _setting_edit[i].def = "0x4253"              ; i++;
    _setting_edit[i].obj = edtMemFindRange    ; _setting_edit[i].ent = "memfind_range"      ; _setting_edit[i].def = "1"                   ; i++;
    _setting_edit[i].obj = edtRegisterLength  ; _setting_edit[i].ent = "reg_length"         ; _setting_edit[i].def = "4"                   ; i++;
    _setting_edit[i].obj = edtRegisterValue   ; _setting_edit[i].ent = "reg_value"          ; _setting_edit[i].def = "0x8000"              ; i++;
    _setting_edit[i].obj = edtRegistersMacro  ; _setting_edit[i].ent = "reg_macro"          ; _setting_edit[i].def = "regs_macro.txt"      ; i++;
    _setting_edit[i].obj = edtYabLogPath      ; _setting_edit[i].ent = "yab_logpath"        ; _setting_edit[i].def = "D:\\log"             ; i++;
    _setting_edit[i].obj = edtYabSdPath       ; _setting_edit[i].ent = "yab_sdpath"         ; _setting_edit[i].def = "D:\\SD"              ; i++;
    _setting_edit[i].obj = edtYabPollInterval ; _setting_edit[i].ent = "yab_poll_interval"  ; _setting_edit[i].def = "100"                 ; i++;
    _setting_edit[i].obj = edtYabMoniInterval ; _setting_edit[i].ent = "yab_moni_interval"  ; _setting_edit[i].def = "0"                   ; i++;
    _setting_edit[i].obj = edtSatCartId       ; _setting_edit[i].ent = "yab_satcart_id"     ; _setting_edit[i].def = "0x80"                ; i++;
    _setting_edit[i].obj = edtDisasmLen       ; _setting_edit[i].ent = "disasm_len"         ; _setting_edit[i].def = "1024"                ; i++;
    _setting_edit[i].obj = edtIasmText        ; _setting_edit[i].ent = "iasm_text"          ; _setting_edit[i].def = "nop"                 ; i++;
    _setting_edit[i].obj = edtIasmOpCode      ; _setting_edit[i].ent = "iasm_opcode"        ; _setting_edit[i].def = "0x0009 (9)"          ; i++;
    _setting_edit[i].obj = edtMemViewRGBw     ; _setting_edit[i].ent = "memrgb_width"       ; _setting_edit[i].def = "80"                  ; i++;
    _setting_edit[i].obj = edtMemViewRGBh     ; _setting_edit[i].ent = "memrgb_height"      ; _setting_edit[i].def = "80"                  ; i++;
    _setting_edit[i].obj = edtFDisasmPath     ; _setting_edit[i].ent = "fdis_path"          ; _setting_edit[i].def = "file.bin"            ; i++;
    _setting_edit[i].obj = edtFDisasmOffset   ; _setting_edit[i].ent = "fdis_offset"        ; _setting_edit[i].def = "0"                   ; i++;
    _setting_edit[i].obj = edtFDisasmAddress  ; _setting_edit[i].ent = "fdis_address"       ; _setting_edit[i].def = "0x06004000"          ; i++;
    _setting_edit[i].obj = edtYabauseTraceAddr; _setting_edit[i].ent = "yab_trace_trig_adr" ; _setting_edit[i].def = "0x06004000"          ; i++;
    _setting_edit[i].obj = edtDbgFile         ; _setting_edit[i].ent = "dbg_binary"         ; _setting_edit[i].def = "myproject\\cd\\0.bin"; i++;
    _setting_edit[i].obj = edtDbgStartAddress ; _setting_edit[i].ent = "dbg_address"        ; _setting_edit[i].def = "06004000"            ; i++;
    _setting_edit[i].obj = edtDbgFolder       ; _setting_edit[i].ent = "dbg_folder"         ; _setting_edit[i].def = ""                    ; i++;
    _setting_edit[i].obj = edtDebugSleep      ; _setting_edit[i].ent = "dbg_interval"       ; _setting_edit[i].def = "100"                 ; i++;
    _setting_edit[i].obj = NULL               ; _setting_edit[i].ent = NULL                 ; _setting_edit[i].def = NULL                  ; //i++;


    /* Set checkbox stuff. */
    i = 0;
    _setting_checkbox[i].obj = cbSilentDbg        ; _setting_checkbox[i].ent = "silent_dbg"        ; _setting_checkbox[i].def = 1; i++;
    _setting_checkbox[i].obj = cbYabRlog          ; _setting_checkbox[i].ent = "yab_rlog"          ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbSoftResHram      ; _setting_checkbox[i].ent = "softres_hram"      ; _setting_checkbox[i].def = 1; i++;
    _setting_checkbox[i].obj = cbSoftResLram      ; _setting_checkbox[i].ent = "softres_lram"      ; _setting_checkbox[i].def = 1; i++;
    _setting_checkbox[i].obj = cbSoftResVDP1regs  ; _setting_checkbox[i].ent = "softres_vdp1regs"  ; _setting_checkbox[i].def = 1; i++;
    _setting_checkbox[i].obj = cbSoftResVDP1ram   ; _setting_checkbox[i].ent = "softres_vdp1ram"   ; _setting_checkbox[i].def = 1; i++;
    _setting_checkbox[i].obj = cbSoftResVDP2regs  ; _setting_checkbox[i].ent = "softres_vdp2regs"  ; _setting_checkbox[i].def = 1; i++;
    _setting_checkbox[i].obj = cbSoftResVDP2ram   ; _setting_checkbox[i].ent = "softres_vdp2ram"   ; _setting_checkbox[i].def = 1; i++;

    _setting_checkbox[i].obj = cbYabLogFileLine   ; _setting_checkbox[i].ent = "yab_log_fileline"  ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabLogPcReg      ; _setting_checkbox[i].ent = "yab_log_pcreg"     ; _setting_checkbox[i].def = 1; i++;
    _setting_checkbox[i].obj = cbYabLogsEtc       ; _setting_checkbox[i].ent = "yab_logs_etc"      ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabLogsDbgr      ; _setting_checkbox[i].ent = "yab_logs_dbgr"     ; _setting_checkbox[i].def = 1; i++;
    _setting_checkbox[i].obj = cbYabLogsInterrupt ; _setting_checkbox[i].ent = "yab_logs_inter"    ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabLogsUbc       ; _setting_checkbox[i].ent = "yab_logs_ubc"      ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabLogsVdp1      ; _setting_checkbox[i].ent = "yab_logs_vdp1"     ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabLogsVdp2      ; _setting_checkbox[i].ent = "yab_logs_vdp2"     ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabLogsSdc       ; _setting_checkbox[i].ent = "yab_logs_sdc"      ; _setting_checkbox[i].def = 0; i++;

    _setting_checkbox[i].obj = cbYabLogEtc        ; _setting_checkbox[i].ent = "yab_logy_etc"      ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabLogCD         ; _setting_checkbox[i].ent = "yab_logy_cd"       ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabLogSCSP       ; _setting_checkbox[i].ent = "yab_logy_scsp"     ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabLogVDP1       ; _setting_checkbox[i].ent = "yab_logy_vdp1"     ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabLogVDP2       ; _setting_checkbox[i].ent = "yab_logy_vdp2"     ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabLogSMPC       ; _setting_checkbox[i].ent = "yab_logy_smpc"     ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabLogSh2        ; _setting_checkbox[i].ent = "yab_logy_sh2"      ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabLogNetLink    ; _setting_checkbox[i].ent = "yab_logy_net"      ; _setting_checkbox[i].def = 0; i++;

    _setting_checkbox[i].obj = cbYabVdp2Log       ; _setting_checkbox[i].ent = "yab_vdp2log"       ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabAllDisp       ; _setting_checkbox[i].ent = "yab_alldisp"       ; _setting_checkbox[i].def = 1; i++;
    _setting_checkbox[i].obj = cbYabDiffDisp      ; _setting_checkbox[i].ent = "yab_diffdisp"      ; _setting_checkbox[i].def = 1; i++;
    _setting_checkbox[i].obj = cbYabSaveRef       ; _setting_checkbox[i].ent = "yab_saveref"       ; _setting_checkbox[i].def = 1; i++;
    _setting_checkbox[i].obj = cbYabVdp1Log       ; _setting_checkbox[i].ent = "yab_vdp1log"       ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabVdp1Reg       ; _setting_checkbox[i].ent = "yab_vdp1_reglog"   ; _setting_checkbox[i].def = 1; i++;
    _setting_checkbox[i].obj = cbYabVdp1Cmd       ; _setting_checkbox[i].ent = "yab_vdp1_cmdlog"   ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabVdp1Dmp       ; _setting_checkbox[i].ent = "yab_vdp1_regsdump" ; _setting_checkbox[i].def = 1; i++;
    _setting_checkbox[i].obj = cbVparLogOut       ; _setting_checkbox[i].ent = "cbVparLogOut"      ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabausePcTrace   ; _setting_checkbox[i].ent = "yab_pc_trace"      ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabLinkEmu       ; _setting_checkbox[i].ent = "yab_linkemu"       ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbSatCartEmu       ; _setting_checkbox[i].ent = "yab_cardemu"       ; _setting_checkbox[i].def = 1; i++;
    _setting_checkbox[i].obj = cbSatCartSw1       ; _setting_checkbox[i].ent = "yab_cardsw1"       ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabLinkEmuLog    ; _setting_checkbox[i].ent = "yab_linkemu_log"   ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabSH2Trace      ; _setting_checkbox[i].ent = "yab_sh2_trace"     ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabSH2KeyTrace   ; _setting_checkbox[i].ent = "yab_sh2_keytrace"  ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbDisasmMem        ; _setting_checkbox[i].ent = "disasm_mem"        ; _setting_checkbox[i].def = 1; i++;
    _setting_checkbox[i].obj = cdFDisasm          ; _setting_checkbox[i].ent = "fdis_use"          ; _setting_checkbox[i].def = 0; i++;

    _setting_checkbox[i].obj = cbDbgLogDate       ; _setting_checkbox[i].ent = "dbglog_date"       ; _setting_checkbox[i].def = 1; i++;
    _setting_checkbox[i].obj = cbDbgLogFlush      ; _setting_checkbox[i].ent = "dbg_logflush"      ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbWhOnLog          ; _setting_checkbox[i].ent = "dbg_wh_on_log"     ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = NULL               ; _setting_checkbox[i].ent = NULL                ; _setting_checkbox[i].def = 0; //i++;

    /* Set combo box stuff. */
    i = 0;
    _setting_combobox[i].obj = cbbIniPath         ; _setting_combobox[i].ent = "ini_file"           ; _setting_combobox[i].typ = 1; _setting_combobox[i].save_itm = 0; _setting_combobox[i].def0 =-1;  _setting_combobox[i].def1 = "usb_dev_cart.ini" ; i++;
    _setting_combobox[i].obj = cbbLogType         ; _setting_combobox[i].ent = "log_type"           ; _setting_combobox[i].typ = 0; _setting_combobox[i].save_itm = 0; _setting_combobox[i].def0 = 0;  _setting_combobox[i].def1 = NULL               ; i++;
    _setting_combobox[i].obj = cbbLogOutput       ; _setting_combobox[i].ent = "log_output"         ; _setting_combobox[i].typ = 0; _setting_combobox[i].save_itm = 0; _setting_combobox[i].def0 = 1;  _setting_combobox[i].def1 = NULL               ; i++;
    _setting_combobox[i].obj = cbbLogLevel        ; _setting_combobox[i].ent = "log_level"          ; _setting_combobox[i].typ = 0; _setting_combobox[i].save_itm = 0; _setting_combobox[i].def0 =10;  _setting_combobox[i].def1 = NULL               ; i++;
    _setting_combobox[i].obj = cbbParamText       ; _setting_combobox[i].ent = "param_text"         ; _setting_combobox[i].typ = 1; _setting_combobox[i].save_itm = 0; _setting_combobox[i].def0 =-1;  _setting_combobox[i].def1 = "port"             ; i++;
    _setting_combobox[i].obj = cbbParamValue      ; _setting_combobox[i].ent = "param_value"        ; _setting_combobox[i].typ = 1; _setting_combobox[i].save_itm = 0; _setting_combobox[i].def0 =-1;  _setting_combobox[i].def1 = "COM3"             ; i++;
    _setting_combobox[i].obj = cbbTemplate        ; _setting_combobox[i].ent = "adr_tmplt"          ; _setting_combobox[i].typ = 0; _setting_combobox[i].save_itm = 0; _setting_combobox[i].def0 = 0;  _setting_combobox[i].def1 = NULL               ; i++;
    _setting_combobox[i].obj = cbbMemSize         ; _setting_combobox[i].ent = "memview_size"       ; _setting_combobox[i].typ = 0; _setting_combobox[i].save_itm = 0; _setting_combobox[i].def0 = 0;  _setting_combobox[i].def1 = NULL               ; i++;
    _setting_combobox[i].obj = cbbMemoryConvert   ; _setting_combobox[i].ent = "memview_disp"       ; _setting_combobox[i].typ = 0; _setting_combobox[i].save_itm = 0; _setting_combobox[i].def0 = 0;  _setting_combobox[i].def1 = NULL               ; i++;
    _setting_combobox[i].obj = cbbRegistersAddress; _setting_combobox[i].ent = "reg_adress"         ; _setting_combobox[i].typ = 1; _setting_combobox[i].save_itm = 0; _setting_combobox[i].def0 =-1;  _setting_combobox[i].def1 = "TVMD"             ; i++;
    _setting_combobox[i].obj = cbbMemViewAddress  ; _setting_combobox[i].ent = "memview_adr"        ; _setting_combobox[i].typ = 1; _setting_combobox[i].save_itm = 1; _setting_combobox[i].def0 =-1;  _setting_combobox[i].def1 = "06004000"         ; i++;
    _setting_combobox[i].obj = cbbStartAddress    ; _setting_combobox[i].ent = "param_start_address"; _setting_combobox[i].typ = 1; _setting_combobox[i].save_itm = 1; _setting_combobox[i].def0 =-1;  _setting_combobox[i].def1 = "06004000"         ; i++;
    _setting_combobox[i].obj = cbbDownFile        ; _setting_combobox[i].ent = "dst_file"           ; _setting_combobox[i].typ = 1; _setting_combobox[i].save_itm = 1; _setting_combobox[i].def0 =-1;  _setting_combobox[i].def1 = "receivefile.bin"  ; i++;
    _setting_combobox[i].obj = cbbUpFile          ; _setting_combobox[i].ent = "src_file"           ; _setting_combobox[i].typ = 1; _setting_combobox[i].save_itm = 1; _setting_combobox[i].def0 =-1;  _setting_combobox[i].def1 = "sendfile.bin"     ; i++;
    _setting_combobox[i].obj = cbbLength          ; _setting_combobox[i].ent = "param_len"          ; _setting_combobox[i].typ = 1; _setting_combobox[i].save_itm = 1; _setting_combobox[i].def0 =-1;  _setting_combobox[i].def1 = "442364"           ; i++;
    _setting_combobox[i].obj = NULL               ; _setting_combobox[i].ent = NULL                 ; _setting_combobox[i].typ = 0; _setting_combobox[i].save_itm = 0; _setting_combobox[i].def0 = 0;  _setting_combobox[i].def1 = NULL               ; //i++;



    /* Set settings file path. */
    AnsiString sIniPath = app_path;
    sIniPath += SET_FILE;

    return sIniPath;
}

//---------------------------------------------------------------------------
void __fastcall TForm1::GUI_Set_Object(char* obj, char* val)
{
    int i;

    /* Edit. */
    i=0; while(_setting_edit[i].obj != NULL)
    {
        if(strcmp(_setting_edit[i].ent, obj) == 0)
        {
            _setting_edit[i].obj->Text = val;
        }
        i++;
    }

    /* Check box. */
    i=0; while(_setting_checkbox[i].obj != NULL)
    {
        if(strcmp(_setting_checkbox[i].ent, obj) == 0)
        {
            _setting_checkbox[i].obj->Checked = strtoul(val, NULL, 0);
        }
        i++;
    }

    /* Combo box. */
    i=0; while(_setting_combobox[i].obj != NULL)
    {
        if(strcmp(_setting_combobox[i].ent, obj) == 0)
        {
            if(_setting_combobox[i].typ == 0)
            { /* Use combo box index. */
                _setting_combobox[i].obj->ItemIndex = strtoul(val, NULL, 0);
            }
            else
            { /* Use combo box text. */
                _setting_combobox[i].obj->Text = val;
            }
        }
        i++;
    }
}

//---------------------------------------------------------------------------
void __fastcall TForm1::LoadSettingsFile(void)
{
    AnsiString sIniPath = MakeSettingsFilePath();
    char sData[SET_STRSZ];

    int i;
    int iValue;
    /* Edit. */
    i=0; while(_setting_edit[i].obj != NULL)
    {
        GetPrivateProfileString(SET_SECTION, _setting_edit[i].ent, _setting_edit[i].def, sData, SET_STRSZ, sIniPath.c_str());
        _setting_edit[i].obj->Text = sData;
        i++;
    }
    /* Check box. */
    i=0; while(_setting_checkbox[i].obj != NULL)
    {
        iValue = (int)GetPrivateProfileInt(SET_SECTION, _setting_checkbox[i].ent, _setting_checkbox[i].def, sIniPath.c_str());
        _setting_checkbox[i].obj->Checked = (iValue ? true : false);
        i++;
    }
    /* Combo box. */
    i=0; while(_setting_combobox[i].obj != NULL)
    {
        if(_setting_combobox[i].typ == 0)
        { /* Use combo box index. */
            iValue = (int)GetPrivateProfileInt(SET_SECTION, _setting_combobox[i].ent, _setting_combobox[i].def0, sIniPath.c_str());
            _setting_combobox[i].obj->ItemIndex = (iValue == -1 ? 0 : iValue);
        }
        else
        { /* Use combo box text. */
            GetPrivateProfileString(SET_SECTION, _setting_combobox[i].ent, _setting_combobox[i].def1, sData, SET_STRSZ, sIniPath.c_str());
            _setting_combobox[i].obj->Text = sData;
        }

        /* Restore items in list. */
        if(_setting_combobox[i].save_itm)
        {
            int iCnt;
            char strEnt[256];
            sprintf(strEnt, "%s_cnt", _setting_combobox[i].ent);
            iCnt = (int)GetPrivateProfileInt(SET_SECTION, strEnt, 0, sIniPath.c_str());

            _setting_combobox[i].obj->Items->Clear();
            for(int j=0; j<iCnt; j++)
            {
                sprintf(strEnt, "%s_%03d", _setting_combobox[i].ent, j);
                GetPrivateProfileString(SET_SECTION, strEnt, _setting_combobox[i].def1, sData, SET_STRSZ, sIniPath.c_str());
                _setting_combobox[i].obj->Items->Insert(j, sData);
            }
        }

        i++;
    }

    /* VDP1 View Screen save ID. */
    iVDP1ScreenID = (int)GetPrivateProfileInt(SET_SECTION, "vdp1screen_id", 0, sIniPath.c_str());

    /* Yabause breakpoints settings. */
    memset((void*)&clsYabBpSet, 0, sizeof(vpar_bp_settings));
    for(i=0; i<VPAR_BP_COUNT; i++)
    {
        char strEnt[256];
        char strDefault[256];

        sprintf(strEnt, "type_%03d", i);
        iValue = (int)GetPrivateProfileInt(SET_BP_SECTION, strEnt, 0, sIniPath.c_str());
        clsYabBpSet.bp[i].type = iValue;

        sprintf(strEnt, "name_%03d", i);
        sprintf(strDefault, "My Breakpoint %02d", i+1);
        GetPrivateProfileString(SET_BP_SECTION, strEnt, strDefault, sData, SET_STRSZ, sIniPath.c_str());
        strncpy(clsYabBpSet.bp[i].name, sData, sizeof(clsYabBpSet.bp[i].name)-1);

        sprintf(strEnt, "read_byte_%03d", i);
        iValue = (int)GetPrivateProfileInt(SET_BP_SECTION, strEnt, 1, sIniPath.c_str());
        clsYabBpSet.bp[i].read_access[0] = iValue;
        sprintf(strEnt, "read_word_%03d", i);
        iValue = (int)GetPrivateProfileInt(SET_BP_SECTION, strEnt, 1, sIniPath.c_str());
        clsYabBpSet.bp[i].read_access[1] = iValue;
        sprintf(strEnt, "read_long_%03d", i);
        iValue = (int)GetPrivateProfileInt(SET_BP_SECTION, strEnt, 1, sIniPath.c_str());
        clsYabBpSet.bp[i].read_access[2] = iValue;

        sprintf(strEnt, "write_byte_%03d", i);
        iValue = (int)GetPrivateProfileInt(SET_BP_SECTION, strEnt, 1, sIniPath.c_str());
        clsYabBpSet.bp[i].write_access[0] = iValue;
        sprintf(strEnt, "write_word_%03d", i);
        iValue = (int)GetPrivateProfileInt(SET_BP_SECTION, strEnt, 1, sIniPath.c_str());
        clsYabBpSet.bp[i].write_access[1] = iValue;
        sprintf(strEnt, "write_long_%03d", i);
        iValue = (int)GetPrivateProfileInt(SET_BP_SECTION, strEnt, 1, sIniPath.c_str());
        clsYabBpSet.bp[i].write_access[2] = iValue;

        sprintf(strEnt, "addr_check_%03d", i);
        iValue = (int)GetPrivateProfileInt(SET_BP_SECTION, strEnt, 1, sIniPath.c_str());
        clsYabBpSet.bp[i].address_check = iValue;
        sprintf(strEnt, "addr_str_%03d", i);
        GetPrivateProfileString(SET_BP_SECTION, strEnt, "06004000", sData, SET_STRSZ, sIniPath.c_str());
        strncpy(clsYabBpSet.bp[i].address_str, sData, sizeof(clsYabBpSet.bp[i].address_str)-1);

        sprintf(strEnt, "value_str_%03d", i);
        GetPrivateProfileString(SET_BP_SECTION, strEnt, "12345678", sData, SET_STRSZ, sIniPath.c_str());
        strncpy(clsYabBpSet.bp[i].value_str, sData, sizeof(clsYabBpSet.bp[i].value_str)-1);
    }
    /* Load first breakpoint entry to screen. */
    iYabBpCurrentId = 0;
    YabauseBpLoadToGui(iYabBpCurrentId);

    /* Window position. */
    Form1->Top  = (int)GetPrivateProfileInt(SET_SECTION, "form1_top" , 0, sIniPath.c_str());
    Form1->Left = (int)GetPrivateProfileInt(SET_SECTION, "form1_left", 0, sIniPath.c_str());

    /* Extra : debug mode check. */
    iValue = (int)GetPrivateProfileInt(SET_SECTION, "debug", 0, sIniPath.c_str());
    iDebugUse = iValue;
    btnTest1->Visible = (iValue ? true : false);
    btnTest2->Visible = (iValue ? true : false);
    btnTest3->Visible = (iValue ? true : false);
    if(iValue == 0)
    { /* In not debug mode, hide the "Data Link test" page and "Log levels" group. */
        pcSettings->Pages[4]->TabVisible = false;
        gbLogLevels->Visible = false;
    }
}

//---------------------------------------------------------------------------
void __fastcall TForm1::SaveSettingsFile(void)
{
    AnsiString sIniPath = MakeSettingsFilePath();

    int i;
    char str[128];
    /* Edit. */
    i=0; while(_setting_edit[i].obj != NULL)
    {
        WritePrivateProfileString(SET_SECTION, _setting_edit[i].ent, _setting_edit[i].obj->Text.c_str(), sIniPath.c_str());
        i++;
    }
    /* Check box. */
    unsigned long ulValue;
    i=0; while(_setting_checkbox[i].obj != NULL)
    {
        WritePrivateProfileString(SET_SECTION, _setting_checkbox[i].ent, (_setting_checkbox[i].obj->Checked ? "1" : "0"), sIniPath.c_str());
        i++;
    }
    /* Combo box. */
    i=0; while(_setting_combobox[i].obj != NULL)
    {
        if(_setting_combobox[i].typ == 0)
        { /* Use combo box index. */
            sprintf(str, "%d", _setting_combobox[i].obj->ItemIndex);
            WritePrivateProfileString(SET_SECTION, _setting_combobox[i].ent, str, sIniPath.c_str());
        }
        else
        { /* Use combo box text. */
            WritePrivateProfileString(SET_SECTION, _setting_combobox[i].ent, _setting_combobox[i].obj->Text.c_str(), sIniPath.c_str());
        }

        /* Save items from list. */
        if(_setting_combobox[i].save_itm)
        {
            int iCnt = _setting_combobox[i].obj->Items->Count;
            char strEnt[256];
            sprintf(strEnt, "%s_cnt", _setting_combobox[i].ent);
            sprintf(str, "%d", iCnt);
            WritePrivateProfileString(SET_SECTION, strEnt, str, sIniPath.c_str());

            for(int j=0; j<iCnt; j++)
            {
                sprintf(strEnt, "%s_%03d", _setting_combobox[i].ent, j);
                WritePrivateProfileString(SET_SECTION, strEnt, _setting_combobox[i].obj->Items->Strings[j].c_str(), sIniPath.c_str());
            }
        }

        i++;
    }

    /* VDP1 View Screen save ID. */
    sprintf(str, "%d", iVDP1ScreenID); WritePrivateProfileString(SET_SECTION, "vdp1screen_id" , str, sIniPath.c_str());

    /* Yabause breakpoints settings. */
    YabauseBpLoadFromGuiAndSave(iYabBpCurrentId);
    for(i=0; i<VPAR_BP_COUNT; i++)
    {
        char strEnt[256];

        sprintf(strEnt, "type_%03d", i);
        sprintf(str, "%d", clsYabBpSet.bp[i].type);
        WritePrivateProfileString(SET_BP_SECTION, strEnt, str, sIniPath.c_str());

        sprintf(strEnt, "name_%03d", i);
        WritePrivateProfileString(SET_BP_SECTION, strEnt, clsYabBpSet.bp[i].name, sIniPath.c_str());

        sprintf(strEnt, "read_byte_%03d", i);
        sprintf(str, "%d", clsYabBpSet.bp[i].read_access[0]);
        WritePrivateProfileString(SET_BP_SECTION, strEnt, str, sIniPath.c_str());
        sprintf(strEnt, "read_word_%03d", i);
        sprintf(str, "%d", clsYabBpSet.bp[i].read_access[1]);
        WritePrivateProfileString(SET_BP_SECTION, strEnt, str, sIniPath.c_str());
        sprintf(strEnt, "read_long_%03d", i);
        sprintf(str, "%d", clsYabBpSet.bp[i].read_access[2]);
        WritePrivateProfileString(SET_BP_SECTION, strEnt, str, sIniPath.c_str());

        sprintf(strEnt, "write_byte_%03d", i);
        sprintf(str, "%d", clsYabBpSet.bp[i].write_access[0]);
        WritePrivateProfileString(SET_BP_SECTION, strEnt, str, sIniPath.c_str());
        sprintf(strEnt, "write_word_%03d", i);
        sprintf(str, "%d", clsYabBpSet.bp[i].write_access[1]);
        WritePrivateProfileString(SET_BP_SECTION, strEnt, str, sIniPath.c_str());
        sprintf(strEnt, "write_long_%03d", i);
        sprintf(str, "%d", clsYabBpSet.bp[i].write_access[2]);
        WritePrivateProfileString(SET_BP_SECTION, strEnt, str, sIniPath.c_str());

        sprintf(strEnt, "addr_check_%03d", i);
        sprintf(str, "%d", clsYabBpSet.bp[i].address_check);
        WritePrivateProfileString(SET_BP_SECTION, strEnt, str, sIniPath.c_str());
        sprintf(strEnt, "addr_str_%03d", i);
        WritePrivateProfileString(SET_BP_SECTION, strEnt, clsYabBpSet.bp[i].address_str, sIniPath.c_str());

        sprintf(strEnt, "value_str_%03d", i);
        WritePrivateProfileString(SET_BP_SECTION, strEnt, clsYabBpSet.bp[i].value_str, sIniPath.c_str());
    }

    /* Window position. */
    sprintf(str, "%d", Form1->Top ); WritePrivateProfileString(SET_SECTION, "form1_top" , str, sIniPath.c_str());
    sprintf(str, "%d", Form1->Left); WritePrivateProfileString(SET_SECTION, "form1_left", str, sIniPath.c_str());
}

//---------------------------------------------------------------------------
void __fastcall TForm1::RemoveComboBoxItems(TComboBox* obj)
{
    AnsiString str = obj->Text;

    while(obj->Items->Count != 0)
    {
        obj->Items->Delete(0);
    };

    /* Bugfix, prevent obj->Text to be cleared. */
    obj->Text = str;

    /* Initialize list with current text. */
    AddComboBoxItem(obj);
}

//---------------------------------------------------------------------------
void __fastcall TForm1::btnClearHistoryClick(TObject *Sender)
{
    RemoveComboBoxItems(cbbDownFile);
    RemoveComboBoxItems(cbbUpFile);
    RemoveComboBoxItems(cbbMemViewAddress);
    RemoveComboBoxItems(cbbStartAddress);
    RemoveComboBoxItems(cbbLength);
}

//---------------------------------------------------------------------------
void __fastcall TForm1::AddComboBoxItem(TComboBox* obj)
{
    AnsiString str = obj->Text;
#define COMBOBOX_MAXCNT 42
    /* Restrict the number of items. */
    while(obj->Items->Count >= COMBOBOX_MAXCNT)
    {
        obj->Items->Delete(obj->Items->Count-1);
    };

    /* Look if item is already in list. */
    int iAlreadyHereId = -1;
    for(int i=0; i<obj->Items->Count; i++)
    {
        if(SameText(obj->Items->Strings[i], str))
        {
            iAlreadyHereId = i;
        }
    }

    if(iAlreadyHereId < 0)
    {
        /* If item is not already in list, add it. */
        obj->Items->Insert(0, obj->Text);
    }
    else
    {
        /* If item is already in list, move it to the top of the list. */
        obj->Items->Exchange(0, iAlreadyHereId);
    }

    /* Bugfix, prevent obj->Text to be cleared. */
    obj->Text = str;
}

//---------------------------------------------------------------------------
/* Init, and load form contents from file. */
void __fastcall TForm1::InitFormItems(void)
{
    cbbTemplate->ItemIndex = 0; btnTemplateSetClick(NULL);

    /* Menu bar stuff start. */
    mniSetUSBDataLinkParameters->Tag  = MNI_SETUDLPARAMS;
    mniOpenUSBDataLink->Tag           = MNI_OPENUDL;
    OpenUSBDevCart->Tag               = MNI_OPENUDC;
    mniSendBackupMemory->Tag          = MNI_SENDBRAM;
    mniExecProgram->Tag               = MNI_EXECPROG;
    mniReceiveBackupMemory->Tag       = MNI_RCVBRAM;
    mniReceiveBIOS->Tag               = MNI_RCVBIOS;
    mniReceiveCartFlash->Tag          = MNI_RCVCARTFLASH;
    /* Menu bar stuff end. */


    btnOpen->Tag          = BTN_OPEN;
    btnClose->Tag         = BTN_CLOSE;
    btnParamSet->Tag      = BTN_PARAMSET;
    btnUpload->Tag        = BTN_SEND;
    btnExecute->Tag       = BTN_EXEC;
    btnDownload->Tag      = BTN_RECEIVE;

    btnMainLogSave->Tag   = BTN_MAINLOGSAVE;
    btnMainLogClear->Tag  = BTN_MAINLOGCLEAR;
    btnLogLevelSet->Tag   = BTN_LOGLEVELSET;

    btnLogLdSettings->Tag = BTN_LOGLDSETTINGS;

    btnAdrDown->Tag       = BTN_ADDRDOWN;
    btnAdrUp->Tag         = BTN_ADDRUP;

    btnAdrPrev2->Tag      = BTN_ADDRPREV2;
    btnAdrNext2->Tag      = BTN_ADDRNEXT2;

    btnMemView->Tag       = BTN_MVREAD;
    //btnMemViewWrite->Tag  = BTN_MVWRITE;
    btnDisassemble->Tag   = BTN_DISASM;

    btnMemViewRGB->Tag    = BTN_MVRGB;
    btnMemFind->Tag       = BTN_MFIND;
    btnMemset->Tag        = BTN_MVMEMSET;

    btnTargetInfo->Tag    = BTN_TARGETINFO;
    btnVDP1View->Tag      = BTN_VDP1VIEW;

    btnLogOn->Tag         = BTN_SILENTOFF;
    btnLogSilent->Tag     = BTN_SILENTON;

    btnRegisterRead->Tag  = BTN_REGREAD;
    btnRegisterWrite->Tag = BTN_REGWRITE;
    btnRegisterExec->Tag  = BTN_REGEXEC;
    btnRegLogClear->Tag   = BTN_REGLOGCLEAR;

    btnFastExec->Tag      = BTN_FASTEXEC;
    btnSetDbgFolder->Tag  = BTN_DBGFOLDER; edtDbgFolder->Tag = BTN_DBGFOLDER;

    btnTest1->Tag         = BTN_TEST1;

    /* Load GUI settings. */
    LoadSettingsFile();

    /*cbMemSize->ItemIndex = 0; cbMemoryConvert->ItemIndex = 0; */ cbbMemoryConvertChange(NULL);

    /* Break points stuff. */
    sgBpList->RowCount = VPAR_BP_COUNT;
}
/* Save form contents to file. */
void __fastcall TForm1::SaveFormItems(void)
{
    /* save GUI settings. */
    SaveSettingsFile();
}


/* Convert string length to number in bytes (ex: "128KB" => 131072) */
unsigned long __fastcall TForm1::ConvertLengthToByte(char* str)
{
    unsigned long ret;
    double tmp;

    char c;
    int i, d;
    int len = strlen(str);
    char digits[30];
    unsigned long mult = 1;
    unsigned long divd = 1;

    memset((void*)digits, '\0', sizeof(digits));

    d=0;
    for(i=0; i<len; i++)
    {
        c = str[i];
        if(((c >= '0') && (c <= '9')) || (c == '.'))
        {
            digits[d] = c;
            d = (d+1) % (sizeof(digits));
        }
        else if(c == 'K')
        {
            mult = 1024;
        }
        else if(c == 'M')
        {
            mult = 1024 * 1024;
        }
        else if(c == 'b')
        {
            divd = 8;
        }
        else if(c == 'B')
        {
            divd = 1;
        }
    }
    digits[sizeof(digits)-1] = '\0';

    tmp = strtod(digits, NULL);
    tmp = tmp * mult;
    tmp = tmp / divd;
    ret = (unsigned long)tmp;

    /* Avoid too large values, because doesn't make sense with Saturn. */
    if(ret > (16*1024*1024))
    {
        ret = 16*1024*1024;
    }

    return ret;
}


/* Save GUI contents to UserData (called by ProcessThread) */
void __fastcall TForm1::SaveToUserData(void)
{
    /* [READ-ONLY]CheckBox/RadioButtons states */
    udGUI.address          = strtoul(cbbStartAddress->Text.c_str(), NULL, 16);
    udGUI.length           = ConvertLengthToByte(cbbLength->Text.c_str());
    udGUI.silent_dbg       = (cbSilentDbg->Checked ? 1 : 0);
    udGUI.disasm_mem       = (cbDisasmMem->Checked ? 1 : 0);
    udGUI.disasm_len       = strtoul(edtDisasmLen->Text.c_str(), NULL, 0);
    udGUI.softres_hram     = (cbSoftResHram    ->Checked ? 1 : 0);
    udGUI.softres_lram     = (cbSoftResLram    ->Checked ? 1 : 0);
    udGUI.softres_vdp1regs = (cbSoftResVDP1regs->Checked ? 1 : 0);
    udGUI.softres_vdp1ram  = (cbSoftResVDP1ram ->Checked ? 1 : 0);
    udGUI.softres_vdp2regs = (cbSoftResVDP2regs->Checked ? 1 : 0);
    udGUI.softres_vdp2ram  = (cbSoftResVDP2ram ->Checked ? 1 : 0);

    /* MemView stuff */
    udGUI.mv_address   = strtoul(cbbMemViewAddress->Text.c_str(), NULL, 16);
    udGUI.mv_msval     = strtoul(edtMemsetValue->Text.c_str(), NULL, 0);  // Memset related
    udGUI.mv_mslen     = strtoul(edtMemsetLength->Text.c_str(), NULL, 0); // Memset related
    udGUI.mv_autoread  = (cbMemViewAuto->Checked ? 1 : 0);
    /* MemView stuff */
    udGUI.mf_data      = strtoul(edtMemFindVal->Text.c_str(), NULL, 0);
    udGUI.mf_range     = strtoul(edtMemFindRange->Text.c_str(), NULL, 0);

    /* File disassembler. */
    udGUI.fdis_use = (cdFDisasm->Checked ? 1 : 0);
    GUI_STRCPY(udGUI.fdis_path, edtFDisasmPath->Text.c_str(), STR_LEN);
    udGUI.fdis_offset = strtoul(edtFDisasmOffset->Text.c_str(), NULL, 0);
    udGUI.fdis_address = strtoul(edtFDisasmAddress->Text.c_str(), NULL, 0);

    /* MemView (RGB555) stuff */
    udGUI.mv_rgbw      = strtoul(edtMemViewRGBw->Text.c_str(), NULL, 10);
    udGUI.mv_rgbh      = strtoul(edtMemViewRGBh->Text.c_str(), NULL, 10);
    udGUI.mv_rcv       = (cbMemViewRGBRfrsh->Checked ? 1 : 0);
    /* [READ-ONLY]Text fields */
    GUI_STRCPY(udGUI.main_log_file , edtMainLogPath->Text.c_str()     , STR_LEN);

    GUI_STRCPY(udGUI.log_settings  , edtLogSettings->Text.c_str()     , STR_LEN);
    GUI_STRCPY(udGUI.log_settings  , edtLogSettings->Text.c_str()     , STR_LEN);

    GUI_STRCPY(udGUI.ini_file      , cbbIniPath->Text.c_str()         , STR_LEN);

    GUI_STRCPY(udGUI.param_text    , cbbParamText->Text.c_str()       , STR_LEN);
    GUI_STRCPY(udGUI.param_value   , cbbParamValue->Text.c_str()      , STR_LEN);

    udGUI.log_type   = cbbLogType->ItemIndex;
    udGUI.log_output = cbbLogOutput->ItemIndex;
    udGUI.log_level  = cbbLogLevel->ItemIndex;

    GUI_STRCPY(udGUI.up_file       , cbbUpFile->Text.c_str()          , STR_LEN);
    GUI_STRCPY(udGUI.down_file     , cbbDownFile->Text.c_str()        , STR_LEN);

    GUI_STRCPY(udGUI.reg_address   , cbbRegistersAddress->Text.c_str(), STR_LEN);
    GUI_STRCPY(udGUI.reg_len       , edtRegisterLength->Text.c_str()  , STR_LEN);
    GUI_STRCPY(udGUI.reg_value     , edtRegisterValue->Text.c_str()   , STR_LEN);
    GUI_STRCPY(udGUI.reg_macro     , edtRegistersMacro->Text.c_str()  , STR_LEN);

    udGUI.dbg_address   = strtoul(edtDbgStartAddress->Text.c_str(), NULL, 16);
    udGUI.dbg_sleep     = strtoul(edtDebugSleep->Text.c_str(), NULL, 10);
    udGUI.dbglog_date   = (cbDbgLogDate->Checked ? 1 : 0);
    udGUI.dbg_logflush  = (cbDbgLogFlush->Checked ? 1 : 0);
    udGUI.dbg_wh_on_log = (cbWhOnLog->Checked ? 1 : 0);
    GUI_STRCPY(Form1->udGUI.dbg_file      , edtDbgFile->Text.c_str()         , STR_LEN);
    GUI_STRCPY(Form1->udGUI.dbg_folder    , edtDbgFolder->Text.c_str()       , STR_LEN);
}
/* Set UserData contents to GUI */
void __fastcall TForm1::LoadFromUserData(void)
{
}


//---------------------------------------------------------------------------
void __fastcall TForm1::btnClick(TObject *Sender)
{
    TButton* pButton = (TButton*)Sender;
    udGUI.btn[pButton->Tag] = 1;

    /* If "close" button is pushed, abort current transfer, if any. */
    if(pButton->Tag == BTN_CLOSE)
    {
        SatCom* pSc = thProcessThread->pSc;
        if(pSc)
        {
            pSc->AbortTransfer();
        }

    }

    /* Add string to combobox items. */
    if(pButton->Tag == BTN_RECEIVE)
    {
        AddComboBoxItem(cbbDownFile);
        AddComboBoxItem(cbbLength);
    }
    if((pButton->Tag == BTN_SEND)
    || (pButton->Tag == BTN_EXEC))
    {
        AddComboBoxItem(cbbUpFile);
    }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::mniClick(TObject *Sender)
{
    TMenuItem* pMenuItem = (TMenuItem*)Sender;
    udGUI.btn[pMenuItem->Tag] = 1;
}

//---------------------------------------------------------------------------
void __fastcall TForm1::mniOpenCurrentDeviceClick(TObject *Sender)
{
    btnClick(btnOpen);
}

//---------------------------------------------------------------------------
void __fastcall TForm1::btnDownSelectClick(TObject *Sender)
{
    SetCurrentDirectory(app_path);
    sdFile->Filter = "Binary File (*.bin)|*.bin|Any File (*.*)|*.*";
    if(sdFile->Execute() == true)
    {
        AnsiString str = "Set download file to: ";
        str += sdFile->FileName;
        mLog->Lines->Add(str);
        cbbDownFile->Text = sdFile->FileName;
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnUpSelectClick(TObject *Sender)
{
    SetCurrentDirectory(app_path);
    odFile->Filter = "Binary File (*.bin)|*.bin|Any File (*.*)|*.*";
    if(odFile->Execute() == true)
    {
        AnsiString str = "Set upload file to: ";
        str += odFile->FileName;
        mLog->Lines->Add(str);
        cbbUpFile->Text = odFile->FileName;
    }
}
//---------------------------------------------------------------------------


void __fastcall TForm1::btnIniOpenClick(TObject *Sender)
{
    odFile->Filter = "Ini File (*.ini)|*.ini|Any File (*.*)|*.*";
    if(odFile->Execute() == true)
    {
        cbbIniPath->Text = odFile->FileName;
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnTemplateSetClick(TObject *Sender)
{
    int index = cbbTemplate->ItemIndex;
    switch(index)
    {
    case(0): /* Exec area (0x06004000) */
        cbbStartAddress->Text = "06004000";
        cbbLength->Text       = "442364";
        break;

    case(1): /* BIOS */
        cbbStartAddress->Text = "00000000";
        cbbLength->Text       = "512K";
        break;

    case(2): /* SMPC Registers */
        cbbStartAddress->Text = "00100000";
        cbbLength->Text       = "128";
        break;

    case(3): /* Backup RAM */
        cbbStartAddress->Text = "00180000";
        cbbLength->Text       = "64K";
        break;

    case(4): /* Work RAM (Low) */
        cbbStartAddress->Text = "00200000";
        cbbLength->Text       = "1024K";
        break;

    case(5): /* Work RAM (High) */
        cbbStartAddress->Text = "06000000";
        cbbLength->Text       = "1024K";
        break;

    case(6): /* Cartridge ROM */
        cbbStartAddress->Text = "02000000";
        cbbLength->Text       = "1024K";
        break;

    case(7): /* Cartridge RAM (1st 512K) */
        cbbStartAddress->Text = "02400000";
        cbbLength->Text       = "512K";
        break;

    case(8): /* Cartridge RAM (2nd 512K) */
        cbbStartAddress->Text = "02600000";
        cbbLength->Text       = "512K";
        break;

    case(9): /* Backup Memory Cartridge */
        cbbStartAddress->Text = "04000000";
        cbbLength->Text       = "1024K";
        break;

    case(10): /* CD-ROM Registers */
        cbbStartAddress->Text = "05800000";
        cbbLength->Text       = "64";
        break;

    case(11): /* VDP1 VRAM */
        cbbStartAddress->Text = "05C00000";
        cbbLength->Text       = "512K";
        break;

    case(12): /* VDP1 Framebuffer */
        cbbStartAddress->Text = "05C80000";
        cbbLength->Text       = "256K";
        break;

    case(13): /* VDP1 Registers */
        cbbStartAddress->Text = "05D00000";
        cbbLength->Text       = "1M";
        break;

    case(14): /* VDP2 VRAM */
        cbbStartAddress->Text = "05E00000";
        cbbLength->Text       = "512K";
        break;

    case(15): /* VDP2 CRAM */
        cbbStartAddress->Text = "05F00000";
        cbbLength->Text       = "4K";
        break;

    case(16): /* VDP2 Registers */
        cbbStartAddress->Text = "05F80000";
        cbbLength->Text       = "512";
        break;

    case(17): /* SCU Registers */
        cbbStartAddress->Text = "05FE0000";
        cbbLength->Text       = "256";
        break;

    case(18): /* SatCom global (LRAM) */
        cbbStartAddress->Text = "002FFFF8";
        cbbLength->Text       = "8";
        break;

    case(19): /* SatCom global (SRAM) */
        cbbStartAddress->Text = "02700000";
        cbbLength->Text       = "8";
        break;

    case(20): /* SRAM (128KB) */
        cbbStartAddress->Text = "02700000";
        cbbLength->Text       = "128K";
        break;
    }
}
//---------------------------------------------------------------------------
unsigned char _ucTransfer = 0;
unsigned char _ucDebugger = 0;
void __fastcall TForm1::tmStatusBarRefreshTimer(TObject *Sender)
{
    /* Asked to show Log window ? */
    if(this->iShowLogWindow)
    {
        Form2->Show();
        this->iShowLogWindow = 0;
    }


    /* Debug stuff. (Q&D !) */
    if(iDebugUse)
    {
        btnLogLevelsGetClick(NULL);
    }


    /* Update transfer status. */
    if(udGUI.transfer_on)
    {
        _ucTransfer = (_ucTransfer+1)%SB_ACTIVITY_MAXCOUNT;
        switch(_ucTransfer%SB_ACTIVITY_MAXCOUNT)
        {
        case(0):
            Form1->StatusBar->Panels->Items[SB_TRANSFER_INDEX]->Text = "LINK: |*    |";
            break;
        case(1):
            Form1->StatusBar->Panels->Items[SB_TRANSFER_INDEX]->Text = "LINK: |  *  |";
            break;
        case(2):
            Form1->StatusBar->Panels->Items[SB_TRANSFER_INDEX]->Text = "LINK: |    *|";
            break;
        default:
        case(3):
            Form1->StatusBar->Panels->Items[SB_TRANSFER_INDEX]->Text = "LINK: |  *  |";
            break;
        }
    }
    else
    {
        Form1->StatusBar->Panels->Items[SB_TRANSFER_INDEX]->Text = "LINK: OFF";
    }

    /* Update debugger status. */
    if((udGUI.transfer_on == 0) && (udGUI.debugger_on))
    {
        char active;
        char status[20];

        if(udGUI.prompt_on == 1)
        { /* Waiting for prompt data. */
            _ucDebugger = (_ucDebugger+1)%SB_PROMPT_DISP_RATE;
            if(_ucDebugger > (SB_PROMPT_DISP_RATE/2))
            {
                sprintf(status, "PROMPT");
            }
            else
            {
                sprintf(status, "");
            }
        }
        else
        { /* Normal debugger. */
            _ucDebugger = (_ucDebugger+1)%SB_ACTIVITY_MAXCOUNT;
            switch(_ucDebugger%SB_ACTIVITY_MAXCOUNT)
            {
            case(0):
                active = '+';
                break;
            case(1):
                active = 'o';
                break;
            case(2):
                active = '*';
                break;
            default:
            case(3):
                active = 'O';
                break;
            }
            sprintf(status, "DBG: %c [%02X]", active, udGUI.debugger_count);
        }
        Form1->StatusBar->Panels->Items[SB_DEBUGGER_INDEX]->Text = status;
    }
    else
    {
        Form1->StatusBar->Panels->Items[SB_DEBUGGER_INDEX]->Text = "DBG: OFF";
    }
}
//---------------------------------------------------------------------------


/* Send prompt answer when enter key is pressed. */

int _mv_row = 0;
int _mv_col = 0;

void __fastcall TForm1::sgMemorySelectCell(TObject *Sender, int ACol,
      int ARow, bool &CanSelect)
{
    _mv_row = ARow;
    _mv_col = ACol;

//     mMemoryValues->Clear();
//     //LogOut("SelectCell AClo = %d, ARow = %d", ACol, ARow);
//     unsigned long index = ARow * /*sgMemory->ColCount*/16 + ACol;
//     unsigned long adr = udGUI.mv_address + index;
// #if 0
//     unsigned char data[4];
//     data[0] = (index+0 < MEMVIEW_DATASIZE ? udGUI.mv_data[index+0] : 0);
//     data[1] = (index+1 < MEMVIEW_DATASIZE ? udGUI.mv_data[index+1] : 0);
//     data[2] = (index+2 < MEMVIEW_DATASIZE ? udGUI.mv_data[index+2] : 0);
//     data[3] = (index+3 < MEMVIEW_DATASIZE ? udGUI.mv_data[index+3] : 0);
//
//     char buff[1024];
//     sprintf(buff, "*(volatile unsigned char  *)(0x%08X) = 0x%02X"            , adr, data[0]);
//     mMemoryValues->Lines->Add(buff);
//     sprintf(buff, "*(volatile unsigned short *)(0x%08X) = 0x%02X%02X"        , adr, data[0], data[1]);
//     mMemoryValues->Lines->Add(buff);
//     sprintf(buff, "*(volatile unsigned long  *)(0x%08X) = 0x%02X%02X%02X%02X", adr, data[0], data[1], data[2], data[3]);
//     mMemoryValues->Lines->Add(buff);
// #else
//     unsigned char data = udGUI.mv_data[index];
//
//     char buff[1024];
//     sprintf(buff, "*(volatile unsigned char  *)(0x%08X) = 0x%02X;", adr, data);
//     mMemoryValues->Lines->Add(buff);
// #endif
}
//---------------------------------------------------------------------------


#include "sh2/sh2d.h"
void __fastcall TForm1::cbbMemoryConvertChange(TObject *Sender)
{
    int w = /*sgMemConvert->ColCount*/16;
    int h = sgMemConvert->RowCount;
    int i, j, k;
    char tmp[256];

    int datasize = 1;
    int index;

    index = cbbMemSize->ItemIndex;
    switch(index)
    {
    default:
    case(0): /* 1 byte */
        sgMemConvert->ColCount = 16;
        sgMemConvert->DefaultColWidth = 24;
        datasize = 1;
        break;

    case(3): /* RGB555 -> 2 bytes */
        cbbMemoryConvert->ItemIndex = 1; // HEX
    case(1): /* 2 bytes */
        sgMemConvert->ColCount = 8;
        sgMemConvert->DefaultColWidth = 49;
        datasize = 2;
        break;

    case(2): /* 4 bytes */
        sgMemConvert->ColCount = 4;
        sgMemConvert->DefaultColWidth = 99;
        datasize = 4;
        break;
    }


    unsigned long data = 0;
    index = cbbMemoryConvert->ItemIndex;
    for(j=0; j<h; j++)
    {
        for(i=0; i<w; i+=datasize)
        {
            data = 0;
            for(k=0; k<datasize; k++)
            {
                data |= udGUI.mv_data[j*w + i + k] << (24 - 8*k);
            }
            data = data >> (32-8*datasize);


            switch(index)
            {
            default:
            case(0): /* Char */
                sprintf(tmp, "%c", char2pchar(data & 0x000000FF));
                break;

            case(1): /* Hex */
                if(datasize == 1)
                {
                    sprintf(tmp, "%02X", data);
                }
                else if(datasize == 2)
                {
                    sprintf(tmp, "%04X", data);
                }
                else
                {
                    sprintf(tmp, "%08X", data);
                }
                break;

            case(2): /* Dec */
                sprintf(tmp, "%u", data);
                break;
            }

            sgMemConvert->Cells[i/datasize][j] = tmp;
        }
    }


    sgSh2Dis->ColWidths[0] = 60;
    sgSh2Dis->ColWidths[1] = 40;
    sgSh2Dis->ColWidths[2] = sgSh2Dis->Width - sgSh2Dis->ColWidths[0]-1 - sgSh2Dis->ColWidths[1]-1 - 25/*scrollbar width*/;
    /* SH2 Disassembler by Bart Trzynadlowski. */
    datasize = 2; // 2bytes code
    h = sgSh2Dis->RowCount * datasize;
    j=0;
    unsigned long stt_addr = udGUI.mv_address;
    for(i=0; i<h; i+=datasize)
    {
        unsigned long v_addr = stt_addr + i;

        // Get op
        data = 0;
        for(k=0; k<datasize; k++)
        {
            data |= udGUI.mv_data[i + k] << (24 - 8*k);
        }
        data = data >> (32-8*datasize);

        // Print address
        sprintf(tmp, "%08X", v_addr);
        sgSh2Dis->Cells[0][j] = tmp;

        // Print op binary value
        sprintf(tmp, "%04X", data);
        sgSh2Dis->Cells[1][j] = tmp;

        // Print corresponding asm code.
        SH2Disasm(udGUI.disasm_mem_address, (udGUI.disasm_mem_use ? DISASM_MEMSIZE : 0), udGUI.disasm_mem_data,
                  v_addr, (unsigned short)data, 0/*mode:sh2*/, tmp);
        sgSh2Dis->Cells[2][j] = tmp;

        j++;
    }

    /* Output disassembler result to log file. */
    FILE* fp = fopen("disasm_log.s", "at");
    if(fp)
    { /* Size check. */
        fseek(fp, 0, SEEK_END);
        unsigned long length = ftell(fp);
        fseek(fp, 0, SEEK_SET);
        if(length > (500*1024))
        {
            fclose(fp);
            fp = fopen("disasm_log.s", "wt");
        }
    }
    if(fp)
    {
        char str[2048];
        for(int i=0; i<sgSh2Dis->RowCount; i++)
        {
            memset((void*)str, ' ', sizeof(str));
            sprintf(str+ 0, "    %s !;", sgSh2Dis->Cells[2][i].c_str()); str[strlen(str)] = ' ';
            sprintf(str+80, " 0x%s %s\n", sgSh2Dis->Cells[0][i].c_str(), sgSh2Dis->Cells[1][i].c_str());
            fwrite(str, strlen(str), 1, fp);
        }
        sprintf(str, "\n"); fwrite(str, strlen(str), 1, fp);
        fclose(fp);
    }
}
//---------------------------------------------------------------------------


#include <cassert>
void __fastcall TForm1::sgSh2DisDrawCell(TObject *Sender, int ACol,
      int ARow, TRect &Rect, TGridDrawState State)
{
    /* Get cell to draw. */
    TStringGrid* StringGrid = static_cast<TStringGrid*>(Sender);
    assert(StringGrid != NULL);
    AnsiString text(StringGrid->Cells[ACol][ARow]);

    /* Normal mode : display in standard color. */
    StringGrid->Canvas->Brush->Color = clWindow;
    /* Set text color. */
    StringGrid->Canvas->Font->Color = clBlack;

    StringGrid->Canvas->FillRect(Rect);

    /* Display cell's text. */
    RECT RText = static_cast<RECT>(Rect);
    InflateRect(&RText, -3, -3);
    DrawText(StringGrid->Canvas->Handle,
            text.c_str(), text.Length(), &RText,
            (ACol == 2 ? DT_LEFT : DT_CENTER) | DT_SINGLELINE | DT_VCENTER);        
}
//---------------------------------------------------------------------------


int _mv_prevrow = _mv_row;
int _mv_prevcol = _mv_col;
void __fastcall TForm1::tmMemviewRefreshTimer(TObject *Sender)
{
    /* Refresh only when needed. */
    if((udGUI.mv_cntr != Form1->udGUI.mv_cver)
    || (_mv_prevrow != _mv_row)
    || (_mv_prevcol != _mv_col))
    {
        cbbMemoryConvertChange(Sender);

        /* Acknowledge refresh. */
        udGUI.mv_cntr = Form1->udGUI.mv_cver;
        _mv_prevrow = _mv_row;
        _mv_prevcol = _mv_col;
    }
}
//---------------------------------------------------------------------------


#include <cassert>
void __fastcall TForm1::sgMemConvertDrawCell(TObject *Sender, int ACol,
      int ARow, TRect &Rect, TGridDrawState State)
{
    //AnsiString str;
    //str.printf("ARow = %d, ACol = %d", ARow, ACol); Form1->mLog->Lines->Add(str.c_str());

    /* Get cell to draw. */
    TStringGrid* StringGrid = static_cast<TStringGrid*>(Sender);
    assert(StringGrid != NULL);
    AnsiString text(StringGrid->Cells[ACol][ARow]);

    /* Need to draw in colors ? */
    int index = cbbMemSize->ItemIndex;
    bool bColor = (cbbMemSize->ItemIndex == 3 ? true : false);

    if(bColor)
    {
        /* Colors mode : extract value from cell's text (HEX value). */
        unsigned short val = strtoul(text.c_str(), NULL, 16);
        int r = (val >>  0 & 0x1F) << 3;
        int g = (val >>  5 & 0x1F) << 3;
        int b = (val >> 10 & 0x1F) << 3;
        StringGrid->Canvas->Brush->Color = (TColor)((b<<16) | (g << 8) | (r));

        /* Set text color (yeah, Q&D !). */
        StringGrid->Canvas->Font->Color = ((r+g+b) <= 384 ? clWhite : clBlack);
    }
    else
    {
        /* Normal mode : display in standard color. */
        StringGrid->Canvas->Brush->Color = clWindow;
        /* Set text color. */
        StringGrid->Canvas->Font->Color = clBlack;
    }
    StringGrid->Canvas->FillRect(Rect);

    /* Display cell's text. */
    RECT RText = static_cast<RECT>(Rect);
    InflateRect(&RText, -3, -3);
    DrawText(StringGrid->Canvas->Handle,
            text.c_str(), text.Length(), &RText,
            DT_CENTER | DT_SINGLELINE | DT_VCENTER);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnMemViewVDP2CRAMClick(TObject *Sender)
{
    cbbMemViewAddress->Text = "05F00000";
    cbbMemSize->ItemIndex = 3/* RGB555. */;
    cbbMemoryConvert->ItemIndex = 1/* Hexadecimal */;
    btnClick((TObject*)btnMemView);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnMemViewGlobalDataLClick(TObject *Sender)
{
    cbbMemViewAddress->Text = "002FFF80";
    cbbMemSize->ItemIndex = 2/* ULONG */;
    cbbMemoryConvert->ItemIndex = 1/* Hexadecimal. */;
    btnClick((TObject*)btnMemView);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnMemViewGlobalDataSClick(TObject *Sender)
{
    cbbMemViewAddress->Text = "02700000";
    cbbMemSize->ItemIndex = 2/* ULONG */;
    cbbMemoryConvert->ItemIndex = 1/* Hexadecimal. */;
    btnClick((TObject*)btnMemView);
}
//---------------------------------------------------------------------------


void __fastcall TForm1::btnMemViewDbgDataClick(TObject *Sender)
{
    AnsiString str;

    if(thProcessThread == NULL)
    {
        Application->MessageBox("Internal error !", "SatLink", MB_OK | MB_ICONWARNING);
        return;
    }
    scd_info_t* ptr = thProcessThread->ptrDebuggerActivity;
    if(ptr == NULL)
    {
        Application->MessageBox("You need to run debugger at least once\nbefore using this functionality !", "SatLink", MB_OK | MB_ICONWARNING);
        return;
    }

    str.printf("%08X", ptr->struct_start_addr);
    cbbMemViewAddress->Text = str;
    cbbMemSize->ItemIndex = 0/* UCHAR*/;
    cbbMemoryConvert->ItemIndex = 2/* Decimal. */;
    btnClick((TObject*)btnMemView);
}
//---------------------------------------------------------------------------


void __fastcall TForm1::tbMemViewRGBRefreshMemoryChange(TObject *Sender)
{
    edtMemViewRGBw->Text = tbMemViewRGBRefreshMemory->Position;
    btnClick((TObject*)btnMemViewRGB);
}
//---------------------------------------------------------------------------



/* Query USB Data Link parameters, and if needed, create a usbdl.ini file. */
void __fastcall TForm1::mniSetUSBDataLinkParametersClick(TObject *Sender)
{
    char udl_comport[256];
    char udl_ledcolor[256];
    AnsiString str;

    str = "COM3";
    if ( InputQuery("USB Data Link - COM port", "Enter COM port (COMx)", str) && Trim(str) != "" )
    {
        sprintf(udl_comport, "%s", str.c_str());

        str = "red";
        if ( InputQuery("USB Data Link - LED color", "Enter LED color (red/green)", str) && Trim(str) != "" )
        {
            sprintf(udl_ledcolor, "%s", str.LowerCase().c_str());

            /* Input OK, so that output a usbdl.ini file. */
            scl_log(SCLT_HOSTPG, 0/*level*/, "Create usbdl.ini (%s %s)", udl_comport, udl_ledcolor);
            cbbIniPath->Text = "usbdl.ini";
            FILE* f=fopen("usbdl.ini", "wb");
            if(f)
            {
                fprintf(f, "-logsettings\r\n");
                fprintf(f, "log_settings.ini\r\n");
                fprintf(f, "-loginfos\r\n");
                fprintf(f, "\r\n");

                fprintf(f, "-dev\r\n");
                fprintf(f, "usbdl\r\n");
                fprintf(f, "\r\n");

                fprintf(f, "-s\r\n");
                fprintf(f, "port\r\n");
                fprintf(f, "%s\r\n", udl_comport);
                fprintf(f, "\r\n");

                fprintf(f, "-s\r\n");
                fprintf(f, "device_led\r\n");
                fprintf(f, "%s\r\n", udl_ledcolor);
                fprintf(f, "\r\n");

                fprintf(f, "display\r\n");
                fprintf(f, "1\r\n");

                fclose(f); f=NULL;
            }
        }
    }
}
//---------------------------------------------------------------------------




#include "common/portlib.h"
void __fastcall TForm1::btnTest2Click(TObject *Sender)
{
AnsiString strA = "12345A";
bool bRet = InputQuery("TEST", "Enter Value: ", strA);
return;
//btnClick(btnOpen);
    AnsiString str;
    unsigned char val;

    port_init();
    val = port_read_byte(0x0378);
    str.printf("Port[0x0378] = 0x%02X", val); Form1->mLog->Lines->Add(str.c_str());
    port_close();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnTest3Click(TObject *Sender)
{
    reg_convert_t r;
    r.i_reg_address = udGUI.reg_address;
    r.i_reg_size    = udGUI.reg_len;
    r.i_reg_value   = udGUI.reg_value;
    thProcessThread->register_convert(&r);
}
//---------------------------------------------------------------------------



#include "common/SerialComm.h"
/* DataLink packet, any protocol. */
#pragma pack(1)	
typedef struct _dlPacket
{
    unsigned char directn;   /* PC->AR : 0x5A, AR->PC : 0xA5.                 */
    unsigned char pktsize;   /* packet size (counted from next byte).         */
    unsigned char pktflag;   /* packet type.                                  */
    unsigned long address;   /* read (write) address.                         */
    unsigned char datalen;   /* data length.                                  */
    unsigned char data[300]; /* data (max 191 bytes), then checksum (1 byte). */
}dlPacket;
/**
 *Note : data[300]
 * data[192] (191 data bytes + checksum) may be enough, but 
 * 300 bytes allows to avoid bug when reading bad-formed 
 * packets (example : datalen == 0xFF).
**/
#pragma pack()

void pck_reset(dlPacket* p);
unsigned char pck_get_checksum(dlPacket* p);
unsigned long ulong_swap(unsigned long data);
void pck_print(dlPacket* p);

void __fastcall TForm1::btnUDLGoClick(TObject *Sender)
{
    AnsiString str;
    unsigned long i;
    unsigned long adr = strtoul(edtUDLAddress->Text.c_str(), NULL, 16);
    unsigned long len = strtoul(edtUDLLen->Text.c_str(), NULL, 0);
    unsigned long count = strtoul(edtUDLCount->Text.c_str(), NULL, 0);
    char port[256];

    mLog->Lines->Clear();

    str.printf("Start address = 0x%08X", adr); Form1->mLog->Lines->Add(str.c_str());
    str.printf("Download length = %d bytes", len); Form1->mLog->Lines->Add(str.c_str());
    str.printf("Download count = %d times", count); Form1->mLog->Lines->Add(str.c_str());

    strcpy(port, edtUDLPort->Text.c_str());
    str.printf("COM port = %s", port); Form1->mLog->Lines->Add(str.c_str());

    /* Open COM port. */
    SerialComm* _com = NULL;
    if(edtUDLColor->Text != "green")
    { // original HW
        _com = new SerialComm(port, "baud=288000 parity=N data=8 stop=2", 1000, 1000);
    }
    else
    { // final HW
        _com = new SerialComm(port, "baud=375000 parity=N data=8 stop=2", 1000, 1000);
    }
    _com->Start();

    /* Download packets. */
    for(i=0; i<count; i++)
    {
        dlPacket pkt;
        unsigned char pktflag;
        if(i == 0)
            pktflag = 0x01; /* Start packet. */
        else if(i == (count-1))
            pktflag = 0x21; /* End packet. */
        else
            pktflag = 0x11; /* Middle packet. */


        /* Set a "receive data" request. */
        pck_reset(&pkt);
        pkt.directn = 0x5A;
        pkt.pktflag = pktflag;
        pkt.address = ulong_swap(adr);
        pkt.pktsize = 7;
        pkt.datalen = len;
        pkt.data[pkt.pktsize-7] = pck_get_checksum(&pkt);

        Form1->mLog->Lines->Add("Send a \"receive data\" request ..."); pck_print(&pkt);
        _com->Send((void*)(&pkt), 9, NULL);

        /* Receive header from USB DataLink. */
        pck_reset(&pkt);
        Form1->mLog->Lines->Add("Waiting for answer header ...");
        _com->Receive((void*)(&pkt), 9+pkt.datalen, NULL);

        pck_print(&pkt);
    }

    /* Close connection. */
    delete _com; _com = NULL;
}
//---------------------------------------------------------------------------


/* Display current log levels (DEBUG use). */
void __fastcall TForm1::btnLogLevelsGetClick(TObject *Sender)
{
    scl_settings_t* ptr =  &_log_global_settings;
    AnsiString str;
    int i, j;

    mLogLevels->Lines->Clear();

    str.printf("silent_on=%d", ptr->silent_on); mLogLevels->Lines->Add(str.c_str());
    char tmp1[50];
    char tmp2[50];
    for(i = 0; i < SCLT_COUNT; i++)
    {
        tmp1[0] = '\0';
        for(j = 0; j < SCLO_COUNT; j++)
        {
            sprintf(tmp2, "%X ", ptr->levels[i][j]);
            strcat(tmp1, tmp2);
        }
        str.printf("l[%d]=%s", i, tmp1); mLogLevels->Lines->Add(str.c_str());
    }
}
//---------------------------------------------------------------------------







#include "parlink/parlink.h"


unsigned char _ucParEXC = 0x49;
void __fastcall TForm1::btnParExchangeClick(TObject *Sender)
{
    AnsiString str;
    unsigned char wrval = strtoul(edtParWriteVal->Text.c_str(), NULL, 0);
    if(cbParExcInc->Checked)
    {
        wrval = _ucParEXC;
        _ucParEXC++;
    }

    unsigned char rdval = par_exchange_byte(wrval);
    LogOut("par_exchange_byte(0x%02X (%d)) = 0x%02X (%d)", wrval, wrval, rdval, rdval);

    str.printf("0x%02X (%d)", rdval, rdval); edtParReadVal->Text = str;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::btnParExchangeLoopClick(TObject *Sender)
{
    int loopcnt = strtoul(edtParExchangeLoop->Text.c_str(), NULL, 0);
    int i;

    for(i=0; i<loopcnt; i++)
    {
        unsigned char wrval = strtoul(edtParWriteVal->Text.c_str(), NULL, 0);
        if(cbParExcInc->Checked)
        {
            //wrval = _ucParEXC;
            wrval += i;
            _ucParEXC++;
        }

        unsigned char rdval = par_exchange_byte(wrval);

        if((i<=2) || (i>=(loopcnt-3)))
        {
            AnsiString str;
            LogOut("[%3d]par_exchange_byte(0x%02X (%d)) = 0x%02X (%d)", i, wrval, wrval, rdval, rdval);
            str.printf("0x%02X (%d)", rdval, rdval); edtParReadVal->Text = str;
        }
        else if(i==3)
        {
            LogOut("...");
        }
    }
        
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnParOpenClick(TObject *Sender)
{
    btnOpen->OnClick((TObject *)btnOpen);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnParCloseClick(TObject *Sender)
{
    btnClose->OnClick((TObject *)btnClose);
}
//---------------------------------------------------------------------------


void __fastcall TForm1::btnParWriteClick(TObject *Sender)
{
    int i = cbParOffset->ItemIndex;
    AnsiString str;
    unsigned char wrval;
    _port_value = strtoul(edtParPortAddress->Text.c_str(), NULL, 0);
    if(i < 0) {cbParOffset->ItemIndex = 0; i = cbParOffset->ItemIndex;}

    wrval = strtoul(edtParWriteVal->Text.c_str(), NULL, 0);

    LogOut("port_write_byte(0x%04X + %d, 0x%02X (%d)) ...", _port_value, i, wrval, wrval);
    port_write_byte(_port_value + i, wrval);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnParReadClick(TObject *Sender)
{
    int i = cbParOffset->ItemIndex;
    AnsiString str;
    unsigned char rdval;
    _port_value = strtoul(edtParPortAddress->Text.c_str(), NULL, 0);
    if(i < 0) {cbParOffset->ItemIndex = 0; i = cbParOffset->ItemIndex;}

    rdval = port_read_byte(_port_value + i);

    LogOut("port_read_byte(0x%04X + %d) = 0x%02X (%d)", _port_value, i, rdval, rdval);
    str.printf("0x%02X (%d)", rdval, rdval); edtParReadVal->Text = str;
}
//---------------------------------------------------------------------------


void vbt_command_parse(char* data, int datalen, int* argc, char** argv)
{
    int i, j;

    /* If needed, append first line to argv. */
    if((data[0] > ' ') && (data[0] != '#'))
    {
        argv[(*argc)] = data; (*argc)++;
    }
    for(i=0; i<(datalen-2); i++)
    {
        /* If found, append command. */
        if((data[i  ] < ' ')
        && (data[i+1] > ' '))
        {
            /* Ignore comments */
            if(data[i+1] != '#')
            {
                argv[(*argc)] = data + i+1; (*argc)++;
            }
        }
        /* Remove non displayable characters. */
        if(data[i] < ' ') data[i] = '\0';
    }
    /* Remove non displayable characters. */
    j=i;
    for(i=j; i<datalen; i++)
    {
        if(data[i] < ' ') data[i] = '\0';
    }
}
void __fastcall TForm1::btnParMacroClick(TObject *Sender)
{
    AnsiString str;
    _port_value = strtoul(edtParPortAddress->Text.c_str(), NULL, 0);

    /* Parse command file. */
    FILE* fh = NULL;
    unsigned long len;
    int i;

    char cmd_file[32*1024];
    int argc;
    char* argv[2048];

    mLog->Lines->Clear();

    LogOut("Read command file STT", 0);
    memset((void*)cmd_file, 0, sizeof(cmd_file));
    fh = fopen("macro.txt", "rb");
    if(fh == NULL)
    {
        LogOut("Couldn't open macro.txt file !");
        return;
    }
    len = fread((void*)cmd_file/*buff*/, 1, sizeof(cmd_file)-1/*size*/, fh);
    fclose(fh); fh = NULL;
    cmd_file[sizeof(cmd_file)-1] = '\0';
    LogOut("Read command file END (%d bytes)", len);
    if(len < 3) return;

    /* Parse commands file. */
    argc = 1;
    argv[0] = "";
    vbt_command_parse(cmd_file, len, &argc, argv);
    for(i=1; i<argc; i++)
    {
        //LogOut("Command[%d] = *%s*", i, argv[i]);

        if(!strcmp(argv[i], "log"))
        {
            LogOut("");
            LogOut("%s", argv[i+1]);
            i+=1;
        }
        else if(!strcmp(argv[i], "IN"))
        {
            unsigned long ii;
            unsigned char r;
            unsigned char  offs = strtoul(argv[i+1], NULL, 0);
            unsigned long  cnt  = strtoul(argv[i+2], NULL, 0);
            unsigned char  disp = strtoul(argv[i+3], NULL, 0);
            for(ii=0; ii<cnt; ii++)
            {
                r = port_read_byte(_port_value + offs);
                LogOut("port_read_byte(0x%04X + %d) = 0x%02X(%c)", _port_value, offs, r, char2pchar(r));
            }
            if(disp)
            {
                str.printf("0x%02X (%c)", r, char2pchar(r)); edtParReadVal->Text = str;
            }
            i+=3;
        }
        else if(!strcmp(argv[i], "OUT"))
        {
            unsigned char r;
            unsigned char  offs = strtoul(argv[i+1], NULL, 0);
            unsigned long  data = strtoul(argv[i+2], NULL, 0);
            unsigned long  andv = strtoul(argv[i+3], NULL, 0);
            unsigned long  xorv = strtoul(argv[i+4], NULL, 0);
            unsigned char  disp = strtoul(argv[i+5], NULL, 0);

            unsigned char val = (data & andv) ^ xorv;
            port_write_byte(_port_value + offs, val);
            LogOut("port_write_byte(0x%04X + %d, (0x%02X & 0x%02X) ^ 0x%02X (=0x%02X))", _port_value, offs, data, andv, xorv, val);

            i+=5;
        }
        else
        {
            LogOut("Error: unknown command: %s", argv[i]);
        }
    }
}
//---------------------------------------------------------------------------


void __fastcall TForm1::cbbRegistersAddressChange(TObject *Sender)
{
    char reg_address[STR_LEN];
    char reg_len[STR_LEN];
    char reg_value[STR_LEN];
    reg_convert_t r;

    strcpy(reg_address , cbbRegistersAddress->Text.c_str());
    strcpy(reg_len     , edtRegisterLength->Text.c_str());
    strcpy(reg_value   , edtRegisterValue->Text.c_str());

    r.i_reg_address = reg_address;
    r.i_reg_size    = reg_len;
    r.i_reg_value   = reg_value;

    thProcessThread->register_convert(&r);

    if(r.o_reg_index != -1)
    {
        edtRegisterLength->Text = AnsiString(r.o_reg_size);
    }
}
//---------------------------------------------------------------------------

#define VPAR_ELEMENT_DISPLAY(_FMT_, _STR_) VparElementDisplay(row, #_STR_, _FMT_, vpar_sm->_STR_)
void /*__fastcall*/ TForm1::VparElementDisplay(int row, char* s, char* fmt, ...)
{
    va_list argptr;
    char strDisp[8192];

    va_start(argptr, fmt);
    vsnprintf(strDisp, sizeof(strDisp)-1, fmt, argptr);
    strDisp[sizeof(strDisp)-1] = '\0';
    va_end(argptr);

    sgYabLinkMonitor->Cells[0][row] = s;
    sgYabLinkMonitor->Cells[1][row] = strDisp;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::VparSeparatorDisplay(int row, char* s)
{
    AnsiString str;

    str.printf("======= %s", s);
    sgYabLinkMonitor->Cells[0][row] = str;
    sgYabLinkMonitor->Cells[1][row] = "---";
}
//---------------------------------------------------------------------------

void __fastcall TForm1::tmVparRefreshTimer(TObject *Sender)
{
    AnsiString str;
    char buff[VPAR_STRLEN+1];
    unsigned char c;
    int row;
    int i;
    bool bFirstDisplay = false;

    /* Be sure shared memory is still available for use. */
    if(!vpar_sm)
    {
        return;
    }

    if(_vpar_init == 0)
    { /* In the case VPar DLL is not available, hide yabause related tabs. */
        pcSettings->Pages[2]->TabVisible = false;
        pcLog->Pages[1]->TabVisible = false;
        return;
    }




    /* Breakpoints are managed in other functions, 
     * and updated only if modified, so force their
     * update to shared memory on shared memory
     * first display.
     */
    if(bFirstDisplay)
    {
        VparSetBreakpoints(&clsYabBpSet);
    }

    /* Retrieve Yabause<->SatLink shared memory whole contents. */
    VparDump(vpar_sm);


    /* Show yabause related tabs :
     *  - Settings : when VPar DLL could be loaded.
     *  - "Log" (Shared memory contents) : when yabause started running.
     */
    pcSettings->Pages[2]->TabVisible = (vpar_sm->yabause_set.ready == 1 ? true : false);
    pcLog->Pages[1]->TabVisible = true;

    /* If needed, initialize display settings of Vpar status grid. */
    if(sgYabLinkMonitor->RowCount < 10)
    {
        bFirstDisplay = true;
    }

    if(bFirstDisplay)
    {
        sgYabLinkMonitor->ColCount = 2;
        sgYabLinkMonitor->RowCount = 1000;
        int col1, col2;
        col2 = 120;
        col1 = sgYabLinkMonitor->ClientWidth - col2 - 2;
        sgYabLinkMonitor->ColWidths[0] = col1;
        sgYabLinkMonitor->ColWidths[1] = col2;
    }


    row = 0;
    unsigned char* ptr;

    sgYabLinkMonitor->Cells[0][row] = "Element";
    sgYabLinkMonitor->Cells[1][row] = "Value";


    row++; VparSeparatorDisplay(row, "VPar DLL status #0");
    row++; VPAR_ELEMENT_DISPLAY("%d", vpar_stats[0].error_cnt);
    row++; VPAR_ELEMENT_DISPLAY("%d", vpar_stats[0].read_cnt);
    row++; VPAR_ELEMENT_DISPLAY("%d", vpar_stats[0].write_cnt);
    row++; VPAR_ELEMENT_DISPLAY("%d", vpar_stats[0].read_size);
    row++; VPAR_ELEMENT_DISPLAY("%d", vpar_stats[0].write_size);
    row++; VparElementDisplay(row, "R/W sizes", "%4d / %4d MB",
        vpar_sm->vpar_stats[0].read_size >> 20,
        vpar_sm->vpar_stats[0].write_size >> 20);

    row++; VparSeparatorDisplay(row, "VPar DLL status #1");
    row++; VPAR_ELEMENT_DISPLAY("%d", vpar_stats[1].error_cnt);
    row++; VPAR_ELEMENT_DISPLAY("%d", vpar_stats[1].read_cnt);
    row++; VPAR_ELEMENT_DISPLAY("%d", vpar_stats[1].write_cnt);
    row++; VPAR_ELEMENT_DISPLAY("%d", vpar_stats[1].read_size);
    row++; VPAR_ELEMENT_DISPLAY("%d", vpar_stats[1].write_size);
    row++; VparElementDisplay(row, "R/W sizes", "%4d / %4d MB",
        vpar_sm->vpar_stats[1].read_size >> 20,
        vpar_sm->vpar_stats[1].write_size >> 20);



    row++; VparSeparatorDisplay(row, "Yabause I/O");
    row++; VPAR_ELEMENT_DISPLAY("%d", io[IO_YABAUSE_ID].update_counter);
    row++; VPAR_ELEMENT_DISPLAY("%d", io[IO_YABAUSE_ID].write_flag);
    row++; VPAR_ELEMENT_DISPLAY("%d", io[IO_YABAUSE_ID].exec_flag);
    row++; VPAR_ELEMENT_DISPLAY("0x%08X", io[IO_YABAUSE_ID].softreset_flags);
    row++; VPAR_ELEMENT_DISPLAY("0x%08X", io[IO_YABAUSE_ID].address);
    row++; VPAR_ELEMENT_DISPLAY("%d", io[IO_YABAUSE_ID].length);
    ptr = vpar_sm->io[IO_YABAUSE_ID].data;
    row++; VparElementDisplay(row, "DATA", "%02X%02X%02X%02X %02X%02X%02X%02X ...", 
                ptr[0], ptr[1], ptr[2], ptr[3], 
                ptr[4], ptr[5], ptr[6], ptr[7]);

    row++; VparSeparatorDisplay(row, "SatLink I/O");
    row++; VPAR_ELEMENT_DISPLAY("%d", io[IO_SATLINK_ID].update_counter);
    row++; VPAR_ELEMENT_DISPLAY("%d", io[IO_SATLINK_ID].write_flag);
    row++; VPAR_ELEMENT_DISPLAY("%d", io[IO_SATLINK_ID].exec_flag);
    row++; VPAR_ELEMENT_DISPLAY("0x%08X", io[IO_SATLINK_ID].softreset_flags);
    row++; VPAR_ELEMENT_DISPLAY("0x%08X", io[IO_SATLINK_ID].address);
    row++; VPAR_ELEMENT_DISPLAY("%d", io[IO_SATLINK_ID].length);
    ptr = vpar_sm->io[IO_SATLINK_ID].data;
    row++; VparElementDisplay(row, "DATA", "%02X%02X%02X%02X %02X%02X%02X%02X ...", 
                ptr[0], ptr[1], ptr[2], ptr[3], 
                ptr[4], ptr[5], ptr[6], ptr[7]);



    row++; VparSeparatorDisplay(row, "Yabause Set Area");
    row++; VPAR_ELEMENT_DISPLAY("%d", yabause_set.update_counter);
    row++; VPAR_ELEMENT_DISPLAY("%d", yabause_set.ready);
    row++; VPAR_ELEMENT_DISPLAY("\"%s\"", yabause_set.last_file);
    row++; VPAR_ELEMENT_DISPLAY("%08X", yabause_set.pc[0]);
    row++; VPAR_ELEMENT_DISPLAY("%08X", yabause_set.pc[1]);
    row++; VPAR_ELEMENT_DISPLAY("%08X", yabause_set.mem_read);
    row++; VPAR_ELEMENT_DISPLAY("%08X", yabause_set.mem_write);
    row++; VPAR_ELEMENT_DISPLAY("%d", yabause_set.mem_read_cntr);
    row++; VPAR_ELEMENT_DISPLAY("%d", yabause_set.mem_write_cntr);
    row++; VPAR_ELEMENT_DISPLAY("%d", yabause_set.keycount);
    row++; VPAR_ELEMENT_DISPLAY("%d", yabause_set.trace_keycount);
    row++; VPAR_ELEMENT_DISPLAY("%d", yabause_set.cart_testled);
    row++; VPAR_ELEMENT_DISPLAY("%d", yabause_set.sh2fct_log_level);


    row++; VparSeparatorDisplay(row, "SatLink Set Area");
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.update_counter);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.dbgview[0]);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.vpar_logout);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.vdp2log);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.alldisp);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.diffdisp);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.dump);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.saveref);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.vdp2_poll_interval);
    row++; VPAR_ELEMENT_DISPLAY("\"%s\"", satlink_set.logpath);
    row++; VPAR_ELEMENT_DISPLAY("\"%s\"", satlink_set.sdpath);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.sh2fct_log);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.pc_trace);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.pc_trace_trigger);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.logs_to_file);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.vdp1log);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.vdp1_reglog);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.vdp1_cmdlog);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.vdp1_regsdump);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.ylink_emulate);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.log_ylink_emulate);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.satcart_emulate);
    row++; VPAR_ELEMENT_DISPLAY("%02X", satlink_set.cart_sw);
    row++; VPAR_ELEMENT_DISPLAY("%02X", satlink_set.cart_id);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.monitor_interval);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.sh2_trace);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.trace_keycount_use);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.log_fileline);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.log_pcreg);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.logs_etc);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.logs_dbgr);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.logs_inter);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.logs_ubc);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.logs_vdp1);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.logs_vdp2);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.logs_sdc);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.logy_etc);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.logy_cd);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.logy_scsp);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.logy_vdp1);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.logy_vdp2);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.logy_smpc);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.logy_sh2);
    row++; VPAR_ELEMENT_DISPLAY("%d", satlink_set.logy_net);


    row++; VparSeparatorDisplay(row, "Breakpoint");
    row++; VPAR_ELEMENT_DISPLAY("%d", bps.bp_count);
    for(i=0; i<VPAR_BP_COUNT; i++)
    {
        row++; VparElementDisplay(row, "--- Array ID", "[%02d]", i);
        row++; VparElementDisplay(row, " - name", " %s", vpar_sm->bps.bp[i].name);
        row++; VparElementDisplay(row, " - type, addr_check", " %d, %d", vpar_sm->bps.bp[i].type, vpar_sm->bps.bp[i].address_check);
        row++; VparElementDisplay(row, " - Access R8,16,32 / W8,16,32", " %d,%d,%d / %d,%d,%d", 
                    vpar_sm->bps.bp[i].read_access[0] , vpar_sm->bps.bp[i].read_access[1] , vpar_sm->bps.bp[i].read_access[2], 
                    vpar_sm->bps.bp[i].write_access[0], vpar_sm->bps.bp[i].write_access[1], vpar_sm->bps.bp[i].write_access[2]);
    }




    /* If needed, setup VPar display grid's lines count. */
    if(bFirstDisplay)
    {
        sgYabLinkMonitor->RowCount = 1+row;
    }



#if 0
    /* Display I/O status. */
    sgYabLinkMonitor->Cells[0][0] = "C_OUT";
    sgYabLinkMonitor->Cells[1][0] = "C_STAT";
    sgYabLinkMonitor->Cells[2][0] = "C_IN";
    sgYabLinkMonitor->Cells[3][0] = "-";

    c = vpar_sm->io.arp_output;  str.printf("0x%02X (%c)", c, char2pchar(c)); sgYabLinkMonitor->Cells[0][1] = str;
    c = vpar_sm->io.arp_status;  str.printf("0x%02X (%c)", c, char2pchar(c)); sgYabLinkMonitor->Cells[1][1] = str;
    c = vpar_sm->io.arp_input;   str.printf("0x%02X (%c)", c, char2pchar(c)); sgYabLinkMonitor->Cells[2][1] = str;
    c = vpar_sm->io.arp_unused1; str.printf("0x%02X (%c)", c, char2pchar(c)); sgYabLinkMonitor->Cells[3][1] = str;

    sgYabLinkMonitor->Cells[0][3] = "P_IO";
    sgYabLinkMonitor->Cells[1][3] = "-";
    sgYabLinkMonitor->Cells[2][3] = "P_BUSY";
    sgYabLinkMonitor->Cells[3][3] = "Mtx_ERR";

    c = vpar_sm->io.lpt_inout;   str.printf("0x%02X (%c)", c, char2pchar(c)); sgYabLinkMonitor->Cells[0][4] = str;
    c = vpar_sm->io.lpt_unused1; str.printf("0x%02X (%c)", c, char2pchar(c)); sgYabLinkMonitor->Cells[1][4] = str;
    c = vpar_sm->io.lpt_busy;    str.printf("0x%02X (%c)", c, char2pchar(c)); sgYabLinkMonitor->Cells[2][4] = str;
    c = vpar_sm->io.io_debug1;   str.printf("0x%02X (%c)", c, char2pchar(c)); sgYabLinkMonitor->Cells[3][4] = str;

    /* Display SD card test LED status. */
    sgYabLinkMonitor->Cells[0][2] = "SD_LED";
    char tmp[10];
    tmp[0] = (vpar_sm->yabause_set.cart_testled & 0x01 ? 'G' : '.');
    tmp[1] = (vpar_sm->yabause_set.cart_testled & 0x02 ? 'R' : '.');
    tmp[2] = ' ';
    if(vpar_sm->yabause_set.cart_testled & 0x10)
    {
        tmp[3] = 'S';
        tmp[4] = 'W';
    }
    else
    {
        tmp[3] = ' ';
        tmp[4] = ' ';
    }
    tmp[5] = '\0';
    sgYabLinkMonitor->Cells[1][2] = tmp;

    sgYabLinkMonitor->Cells[2][2] = "MSH2_FCT";
    str.printf("%d", vpar_sm->yabause_set.sh2fct_log_level); sgYabLinkMonitor->Cells[3][2] = str;
#endif


    /* Display yabause settings. */
    str.printf("Cnt=%d Trace=%d", vpar_sm->yabause_set.keycount, vpar_sm->yabause_set.trace_keycount);
    edtYabKeyTrace->Text = str;

    str.printf("%02X / %02X", vpar_sm->yabause_set.update_counter, vpar_sm->satlink_set.update_counter);
    edtYabUpdtCntrs->Text = str;

    memcpy((void*)buff, (void*)&(vpar_sm->yabause_set.last_file), VPAR_STRLEN); buff[VPAR_STRLEN] = '\0';
    edtYabLastFile->Text = buff;

    str.printf("M[%08X] S[%08X]", vpar_sm->yabause_set.pc[0], vpar_sm->yabause_set.pc[1]);
    edtYabPC->Text = str;
    str.printf("R[%08X][%02X] W[%08X][%02X]", vpar_sm->yabause_set.mem_read, vpar_sm->yabause_set.mem_read_cntr, vpar_sm->yabause_set.mem_write, vpar_sm->yabause_set.mem_write_cntr);
    edtYabRWAddr->Text = str;


    /** Set setting data from GUI to internal data. **/
    vpar_satlink_set_t set;
    memcpy((void*)&set, (void*)&(vpar_sm->satlink_set), sizeof(vpar_satlink_set_t));

    set.vpar_logout = (cbVparLogOut->Checked ? 1 : 0);

    /* Use debugview or file to output logs. */
    set.logs_to_file = (cbYabRlog->Checked ? 1 : 0);


    set.log_fileline = cbYabLogFileLine->Checked;
    set.log_pcreg    = cbYabLogPcReg->Checked;
    /* SatCom logs output selectors. */
    set.logs_etc   = cbYabLogsEtc->Checked;
    set.logs_dbgr  = cbYabLogsDbgr->Checked;
    set.logs_inter = cbYabLogsInterrupt->Checked;
    set.logs_ubc   = cbYabLogsUbc->Checked;
    set.logs_vdp1  = cbYabLogsVdp1->Checked;
    set.logs_vdp2  = cbYabLogsVdp2->Checked;
    set.logs_sdc   = cbYabLogsSdc->Checked;
    /* Yabause logs output selectors. */
    set.logy_etc   = cbYabLogEtc->Checked;
    set.logy_cd    = cbYabLogCD->Checked;
    set.logy_scsp  = cbYabLogSCSP->Checked;
    set.logy_vdp1  = cbYabLogVDP1->Checked;
    set.logy_vdp2  = cbYabLogVDP2->Checked;
    set.logy_smpc  = cbYabLogSMPC->Checked;
    set.logy_sh2   = cbYabLogSh2->Checked;
    set.logy_net   = cbYabLogNetLink->Checked;

    /* VDP2 */
    set.vdp2log  = (cbYabVdp2Log->Checked ? 1 : 0);
    set.alldisp  = (cbYabAllDisp->Checked ? 1 : 0);
    set.diffdisp = (cbYabDiffDisp->Checked ? 1 : 0);
    set.saveref  = (cbYabSaveRef->Checked ? 1 : 0);
    set.dump     = (cbYabDump->Checked ? 1 : 0);
    /* VDP1 */
    set.vdp1log       = (cbYabVdp1Log->Checked ? 1 : 0);
    set.vdp1_reglog   = (cbYabVdp1Reg->Checked ? 1 : 0);
    set.vdp1_cmdlog   = (cbYabVdp1Cmd->Checked ? 1 : 0);
    set.vdp1_regsdump = (cbYabVdp1Dmp->Checked ? 1 : 0);

    /* Link emulator. */
    set.ylink_emulate     = (cbYabLinkEmu->Checked ? 1 : 0);
    set.log_ylink_emulate = (cbYabLinkEmuLog->Checked ? 1 : 0);

    /* Custom Cartridge settings. */
    set.satcart_emulate = (cbSatCartEmu->Checked ? 1 : 0);
    set.cart_sw         = (cbSatCartSw1->Checked ? 1 : 0);
    set.cart_id         = strtoul(edtSatCartId->Text.c_str(), NULL, 0);

    memset(set.logpath, 0, VPAR_STRLEN);
    strncpy(set.logpath, edtYabLogPath->Text.c_str(), VPAR_STRLEN-1);

    /* SD card data folder. */
    memset(set.sdpath, 0, VPAR_STRLEN);
    strncpy(set.sdpath, edtYabSdPath->Text.c_str(), VPAR_STRLEN-1);

    set.pc_trace = (cbYabausePcTrace->Checked ? 1 : 0);
    set.pc_trace_trigger = strtoul(edtYabauseTraceAddr->Text.c_str(), NULL, 0);

    set.vdp2_poll_interval = strtoul(edtYabPollInterval->Text.c_str(), NULL, 0);
    if(set.vdp2_poll_interval < 5) set.vdp2_poll_interval = 5;

    set.monitor_interval = strtoul(edtYabMoniInterval->Text.c_str(), NULL, 0);
    set.sh2_trace = (cbYabSH2Trace->Checked ? 1 : 0);
    set.trace_keycount_use = (cbYabSH2KeyTrace->Checked ? 1 : 0);

    /** If needed, update settings. **/
    if(memcmp((void*)&(vpar_sm->satlink_set), (void*)&set, sizeof(vpar_satlink_set_t)) != 0)
    {
        set.update_counter++;
        VparSetSatLinkParameters(&set);

        /* Don't forget to update local copy of shared memory contents. */
        VparDump(vpar_sm);
    }
}
//---------------------------------------------------------------------------


void __fastcall TForm1::edtMemViewAddressKeyPress(TObject *Sender,
      char &Key)
{
    if((Key == '\r') || (Key == '\n'))
    {
        btnClick((TObject *)btnMemView);

        /* Add string to combobox items. */
        AddComboBoxItem((TComboBox*)Sender);
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::edtMemFindValKeyPress(TObject *Sender, char &Key)
{
    if((Key == '\r') || (Key == '\n'))
    {
        btnClick((TObject *)btnMemFind);
    }
}
//---------------------------------------------------------------------------


int _iMemView_X = 0;
int _iMemView_Y = 0;
AnsiString _iMemView_Str = "";

void __fastcall TForm1::sgMemConvertSetEditText(TObject *Sender, int ACol,
      int ARow, const AnsiString Value)
{
    _iMemView_X = ACol;
    _iMemView_Y = ARow;
    _iMemView_Str = Value;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::sgMemConvertKeyPress(TObject *Sender, char &Key)
{
    /* Prevent from entering value when auto-read memory. */
    if(cbMemViewAuto->Checked) return;

    if((Key == '\r') || (Key == '\n'))
    {
        char buff[128];
        int index;
        memset(buff, 0, sizeof(buff)); snprintf(buff, sizeof(buff)-1, "%s", _iMemView_Str.c_str());

        unsigned long data = 0;
        int datasize = 0;
        int dataoffset = 0;
        index = cbbMemoryConvert->ItemIndex;
        switch(index)
        {
        default:
        case(0): /* Char */
            data = buff[0];
            break;

        case(1): /* Hex */
            data = strtoul(buff, NULL, 16);
            break;

        case(2): /* Dec */
            data = strtoul(buff, NULL, 10);
            break;
        }

        index = cbbMemSize->ItemIndex;
        switch(index)
        {
        default:
        case(0): /* 1 byte */
            datasize = 1;
            dataoffset = _iMemView_Y*16 + _iMemView_X*datasize;
            udGUI.mv_data[dataoffset] = data;
            break;

        case(3): /* RGB555 -> 2 bytes */
        case(1): /* 2 bytes */
            datasize = 2;
            dataoffset = _iMemView_Y*16 + _iMemView_X*datasize;
            udGUI.mv_data[dataoffset + 0] = (data>> 8) & 0x000000FF;
            udGUI.mv_data[dataoffset + 1] = (data>> 0) & 0x000000FF;
            break;

        case(2): /* 4 bytes */
            datasize = 4;
            dataoffset = _iMemView_Y*16 + _iMemView_X*datasize;
            udGUI.mv_data[dataoffset + 0] = (data>>24) & 0x000000FF;
            udGUI.mv_data[dataoffset + 1] = (data>>16) & 0x000000FF;
            udGUI.mv_data[dataoffset + 2] = (data>> 8) & 0x000000FF;
            udGUI.mv_data[dataoffset + 3] = (data>> 0) & 0x000000FF;
            break;
        }
        /* Send a write request. */
        udGUI.mv_woff = dataoffset;
        udGUI.mv_wlen = datasize;
        udGUI.btn[BTN_MVWRITE] = 1;

    }
}
//---------------------------------------------------------------------------







/* Inline assembler. */
#include "sh2/iasm.h"
void __fastcall TForm1::btnIasmExecClick(TObject *Sender)
{
    AnsiString str;
    unsigned short op = (unsigned short)iasm(edtIasmText->Text.c_str());
    str.printf("0x%04X (%d)", op, op);
    edtIasmOpCode->Text = str;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::edtIasmTextKeyPress(TObject *Sender, char &Key)
{
    if((Key == '\r') || (Key == '\n'))
    {
        btnIasmExecClick(Sender);
    }
}
//---------------------------------------------------------------------------

/* Disassembler. */
#include "sh2/sh2d.h"
void __fastcall TForm1::btnAsmExecClick(TObject *Sender)
{
    char tmp[256];
    unsigned short op = strtoul(edtIasmOpCode->Text.c_str(), NULL, 0);
    unsigned short addr = strtoul(edtIasmOpCode->Text.c_str(), NULL, 0);

    SH2Disasm(0, 0, 0, addr, op, 0/*mode:sh2*/, tmp);
    edtIasmText->Text = tmp;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::edtIasmOpCodeKeyPress(TObject *Sender, char &Key)
{
    if((Key == '\r') || (Key == '\n'))
    {
        btnAsmExecClick(Sender);
    }
}
//---------------------------------------------------------------------------


void __fastcall TForm1::edtKeyPress(TObject *Sender, char &Key)
{
    if((Key == '\r') || (Key == '\n'))
    {
        TEdit*     edtSrc = (TEdit    *)Sender;
        TComboBox* cbbSrc = (TComboBox*)Sender;

        /* [Download/Upload]Open when INI file is entered. */
        if(cbbSrc == cbbIniPath)
        {
            btnClick((TObject*)btnOpen);
        }
        /* [Download/Upload]Set when parameter/value is entered. */
        if((cbbSrc == cbbParamText) || (cbbSrc == cbbParamValue))
        {
            btnClick((TObject*)btnParamSet);
        }
        /* [Download/Upload]Download when address/length/filename is entered. */
        if((cbbSrc == cbbLength) || (cbbSrc == cbbTemplate))
        {
            btnClick((TObject*)btnDownload);
        }
        if((cbbSrc == cbbStartAddress) || (cbbSrc == cbbDownFile))
        {
            btnClick((TObject*)btnDownload);
        }
        /* [Download/Upload]Upload when filename is entered. */
        if(cbbSrc == cbbUpFile)
        {
            btnClick((TObject*)btnUpload);
        }


        /* [Misc]Save to disk when log file is entered. */
        if(edtSrc == edtMainLogPath)
        {
            btnClick((TObject*)btnMainLogSave);
        }

        /* [MemEdit->RGB]Display image when width or height is entered. */
        if((edtSrc == edtMemViewRGBw) || (edtSrc == edtMemViewRGBh))
        {
            btnClick((TObject*)btnMemViewRGB);
        }

        /* [Registers]Read register when its name is entered. */
        if(cbbSrc == cbbRegistersAddress)
        {
            btnClick((TObject*)btnRegisterRead);
        }
        /* [Registers]Read register when its length is entered. */
        if(edtSrc == edtRegisterLength)
        {
            btnClick((TObject*)btnRegisterRead);
        }
        /* [Registers]Write register when its value is entered. */
        if(edtSrc == edtRegisterValue)
        {
            btnClick((TObject*)btnRegisterWrite);
        }
        /* [Registers]Execute macro when its file name is entered. */
        if(edtSrc == edtRegistersMacro)
        {
            btnClick((TObject*)btnRegisterExec);
        }

    }
}
//---------------------------------------------------------------------------


void __fastcall TForm1::btnRegLogSaveClick(TObject *Sender)
{
    const char* log_file = "registers.log";
    scl_log(SCLT_HOSTPG, 7/*level*/, "[PT]Save register log.");
    SetCurrentDirectory(app_path);
    FILE* f=fopen(log_file, "ab");
    if(f)
    {
        fprintf(f, "%s\r\n", Form1->mRegisterLog->Lines->Text.c_str());
        fclose(f);// f=NULL;
        scl_log(SCLT_HOSTPG, 0/*level*/, "Saved %d lines from log to disk. (%s)", Form1->mRegisterLog->Lines->Count, log_file);
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::mniShowLogOutputClick(TObject *Sender)
{
    // Display sub-window
    Form2->Show();
}
//---------------------------------------------------------------------------

unsigned short __fastcall TForm1::SdSpiSend(unsigned char cs, unsigned char val, unsigned long wait_val)
{
    int i, j;
    unsigned short ret = 0;
    SatCom* pSc = thProcessThread->pSc;

    if(!pSc) return ret;


    for(i=0; i<8; i++)
    {
      for(j=0; j<2; j++)
      {
//#define SD_CSL_LSHFT  0
//#define SD_DIN_LSHFT  1
//#define SD_CLK_LSHFT  2
        unsigned short sndval = (cs & 0x01            ) << 0
                              | ((val >> (7-i)) & 0x01) << 1
                              | (j                    ) << 2;
        // Blink LEDs according to CS/DIN/CLK values.
        sndval |= sndval << 8;
        pSc->Send(0x02300010, (unsigned char*)&sndval, sizeof(sndval), SC_LOAD, SC_SOFTRES_ALL);
        if(wait_val) Sleep(wait_val);

        unsigned char rcvval = 0;
        pSc->Receive(0x02300015, &rcvval, sizeof(rcvval));
        ret = (ret<<1) | (rcvval & 0x01);
        if(wait_val) Sleep(wait_val);
      }
    }

    return ret;
}




void __fastcall TForm1::btnSdCmd0TestClick(TObject *Sender)
{
    int row = 0;
    int i, j;
    unsigned long retry_cnt = strtoul(edtSdRetry->Text.c_str(), NULL, 0);
    unsigned long wait_val  = strtoul(edtSdWait ->Text.c_str(), NULL, 0);

    unsigned long start_time = GetTickCount();
    unsigned long bytecnt    = 0;



    sgSdTest->ColCount = 3;
    sgSdTest->RowCount = 1024;

    for(j=0; j<sgSdTest->RowCount; j++)
    {
      for(i=0; i<sgSdTest->ColCount; i++)
      {
        sgSdTest->Cells[i][j] = "";
      }
    }

    sgSdTest->ColWidths[0] = 20;
    sgSdTest->ColWidths[1] = 90;
    sgSdTest->ColWidths[2] = 2*sgSdTest->ColWidths[1];

    sgSdTest->Cells[0][row] = "CS";
    sgSdTest->Cells[1][row] = "DIN";
    sgSdTest->Cells[2][row] = "DOUT (CLK0, CLK1)";
    row++;

    unsigned char cs;
    unsigned char  sndval;
    unsigned short retval;
    char str[32];
    AnsiString s;

    // Wake up card
    cs = 1;
    for(i=0; i<13; i++)
    {
        sndval = 0xFF;

        retval = SdSpiSend(cs, sndval, wait_val); bytecnt++;

        sprintf(str, "%d", cs);
        sgSdTest->Cells[0][row] = str;

        sprintf(str, "%02X ", sndval);
        s = sgSdTest->Cells[1][row] + AnsiString(str);
        sgSdTest->Cells[1][row] = s;

        sprintf(str, "%04X ", retval);
        s = sgSdTest->Cells[2][row] + AnsiString(str);
        sgSdTest->Cells[2][row] = s;

        if((i%4) == 3)
        {
            row++;
        }
    }

    // Wait for a while
    Sleep(20);

    // Send CMD0
    cs = 0;
    for(j=0; j<retry_cnt; j++)
    {
        // Send command
        for(i=0; i<6; i++)
        {
            const unsigned char cmd0_din[6] = {0x40, 0x00, 0x00, 0x00, 0x00, 0x95};

            sndval = cmd0_din[i];

            retval = SdSpiSend(cs, sndval, wait_val); bytecnt++;

            sprintf(str, "%d", cs);
            sgSdTest->Cells[0][row] = str;

            sprintf(str, "%02X ", sndval);
            s = sgSdTest->Cells[1][row] + AnsiString(str);
            sgSdTest->Cells[1][row] = s;

            sprintf(str, "%04X ", retval);
            s = sgSdTest->Cells[2][row] + AnsiString(str);
            sgSdTest->Cells[2][row] = s;

            if((i%4) == 3)
            {
                row++;
            }
        }
        row++;

        // Receive response
        for(i=0; i<24; i++)
        {
            sndval = 0xFF;

            retval = SdSpiSend(cs, sndval, wait_val); bytecnt++;

            sprintf(str, "%d", cs);
            sgSdTest->Cells[0][row] = str;

            sprintf(str, "%02X ", sndval);
            s = sgSdTest->Cells[1][row] + AnsiString(str);
            sgSdTest->Cells[1][row] = s;

            sprintf(str, "%04X ", retval);
            s = sgSdTest->Cells[2][row] + AnsiString(str);
            sgSdTest->Cells[2][row] = s;

            if((i%4) == 3)
            {
                row++;
            }
        }
    }

    unsigned long exec_time = GetTickCount() - start_time;
    LogOut("Exec Time = %d msec, Byte Cnt = %d", exec_time, bytecnt);

    if(exec_time)
    {
        unsigned long transfer_speed = (bytecnt * 8 * 1000) / exec_time;
        LogOut("Transfer Speed = %d bit/sec (%d kbps)", transfer_speed, transfer_speed>>10);
    }

    sgSdTest->RowCount = row;
}
//---------------------------------------------------------------------------


void __fastcall TForm1::YabauseBpParseValMask(char* str, unsigned long* val, unsigned long* mask)
{
    int i, n;

    /* Consider unspecified character as masked, and
     * non-hexa characters as mask characters.
     *
     * Examples :
     *  -  "6004000" will be parsed as 0x06004000/0x0FFFFFFF value/mask pair.
     *  - "06004000" will be parsed as 0x06004000/0xFFFFFFFF value/mask pair.
     *  - "060040XX" will be parsed as 0x06004000/0xFFFFFF00 value/mask pair.
     */
    *val  = 0;
    *mask = 0;

    n = strlen(str);
    for(i=0; i<8; i++)
    {
        char c = str[i];
        int shift = ((n-1) - i) * 4;

        if((c >= '0') && (c <= '9'))
        {
            *val  |= (c - '0') << shift;
            *mask |= 0xF << shift;
        }
        else if((c >= 'A') && (c <= 'F'))
        {
            *val  |= (c - 'A' + 10) << shift;
            *mask |= 0xF << shift;
        }
        else if((c >= 'a') && (c <= 'f'))
        {
            *val  |= (c - 'a' + 10) << shift;
            *mask |= 0xF << shift;
        }
        else
        {
            /* Parse unknown characters as mask character.
             * In the case of mask character, both value and
             * mask bits need to be set to zero, which is the
             * case by default.
             */
        }
    }
}
//---------------------------------------------------------------------------


void __fastcall TForm1::YabauseBpHideShowItems(void)
{
    int iType = cbBpType->ItemIndex % VPAR_BPT_COUNT;

    /* Hide unrelevant settings according to breakpoint type/ */
    const int pbArray[2][VPAR_BPT_COUNT] =
    {
        /* Read/write access stuff. */
        {false, false, true, true}, 
        /* Register value stuff. */
        {false, false, false, true}, 
    };
#define ITEM_HIDE_SHOW(_ITM_) (_ITM_)->Visible = pbArray[(_ITM_)->Tag][iType];
    /* Read/write access stuff. */
    ITEM_HIDE_SHOW(lblBpReadAccess);
    ITEM_HIDE_SHOW(cbBpReadByte);
    ITEM_HIDE_SHOW(cbBpReadWord);
    ITEM_HIDE_SHOW(cbBpReadLong);
    ITEM_HIDE_SHOW(lblBpWriteAccess);
    ITEM_HIDE_SHOW(cbBpWriteByte);
    ITEM_HIDE_SHOW(cbBpWriteWord);
    ITEM_HIDE_SHOW(cbBpWriteLong);
    /* Register value stuff. */
    ITEM_HIDE_SHOW(lblRegisterValue);
    ITEM_HIDE_SHOW(edtBpValue);
    ITEM_HIDE_SHOW(lblValueVal);
    ITEM_HIDE_SHOW(lblValueMask);
#undef ITEM_HIDE_SHOW

    /* Address stuff is a bit messy, hence managed by hand. */
    cbBpAddressCheck->Visible = (iType != VPAR_BPT_VALUE ? false : true);
    lblBpAddressText->Visible = (iType == VPAR_BPT_DISABLED ? false : !cbBpAddressCheck->Visible);
    bool bAddressShow = (iType == VPAR_BPT_VALUE ? false : true);
    switch(iType)
    {
    default:
    case(VPAR_BPT_DISABLED):
        bAddressShow = false;
        break;
    case(VPAR_BPT_CODE):
    case(VPAR_BPT_ADDRESS):
        bAddressShow = true;
        break;
    case(VPAR_BPT_VALUE):
        bAddressShow = cbBpAddressCheck->Checked;
        break;
    }
    edtBpAddress->Visible = bAddressShow;
    lblAddressVal->Visible = bAddressShow;
    lblAddressMask->Visible = bAddressShow;
}
//---------------------------------------------------------------------------


void __fastcall TForm1::YabauseBpLoadToGui(int id)
{
    char cStr[256];

    cbBpType->ItemIndex = clsYabBpSet.bp[id].type;

    sprintf(cStr, "%s", clsYabBpSet.bp[id].address_str);
    edtBpName->Text = clsYabBpSet.bp[id].name;

    cbBpReadByte->Checked = clsYabBpSet.bp[id].read_access[0] ? true : false;
    cbBpReadWord->Checked = clsYabBpSet.bp[id].read_access[1] ? true : false;
    cbBpReadLong->Checked = clsYabBpSet.bp[id].read_access[2] ? true : false;

    cbBpWriteByte->Checked = clsYabBpSet.bp[id].write_access[0] ? true : false;
    cbBpWriteLong->Checked = clsYabBpSet.bp[id].write_access[1] ? true : false;
    cbBpWriteWord->Checked = clsYabBpSet.bp[id].write_access[2] ? true : false;

    cbBpAddressCheck->Checked = clsYabBpSet.bp[id].address_check ? true : false;

    YabauseBpParseValMask(clsYabBpSet.bp[id].address_str, &clsYabBpSet.bp[id].address_val, &clsYabBpSet.bp[id].address_mask);
    sprintf(cStr, "%s", clsYabBpSet.bp[id].address_str);
    edtBpAddress->Text = cStr;
    sprintf(cStr, "Value:%08X", clsYabBpSet.bp[id].address_val);
    lblAddressVal->Caption = cStr;
    sprintf(cStr, "Mask :%08X", clsYabBpSet.bp[id].address_mask);
    lblAddressMask->Caption = cStr;

    YabauseBpParseValMask(clsYabBpSet.bp[id].value_str, &clsYabBpSet.bp[id].value_val, &clsYabBpSet.bp[id].value_mask);
    sprintf(cStr, "%s", clsYabBpSet.bp[id].value_str);
    edtBpValue->Text = cStr;
    sprintf(cStr, "Value:%08X", clsYabBpSet.bp[id].value_val);
    lblValueVal->Caption = cStr;
    sprintf(cStr, "Mask :%08X", clsYabBpSet.bp[id].value_mask);
    lblValueMask->Caption = cStr;

    /* Hide/show items according to breakpoint type. */
    YabauseBpHideShowItems();

    /* Display breakpoints preview in list. */
    int i = 0;
    for(i=0; i<VPAR_BP_COUNT; i++)
    {
        /* Set first characters as "[XY]" when break point is selected. */
        char c1 = id == i ? '[' : ' ';
        char c2 = id == i ? ']' : ' ';

        if(clsYabBpSet.bp[i].type == VPAR_BPT_CODE)
        {
            sprintf(cStr, "%c%02d%c C[%s] %s", 
                c1, i, c2, 
                clsYabBpSet.bp[i].address_str, 
                clsYabBpSet.bp[i].name);
            sgBpList->Cells[0][i] = cStr;
        }
        else if(clsYabBpSet.bp[i].type == VPAR_BPT_ADDRESS)
        {
            sprintf(cStr, "%c%02d%c A[%s] %s", 
                c1, i, c2, 
                clsYabBpSet.bp[i].address_str, 
                clsYabBpSet.bp[i].name);
            sgBpList->Cells[0][i] = cStr;
        }
        else if(clsYabBpSet.bp[i].type == VPAR_BPT_VALUE)
        {
            sprintf(cStr, "%c%02d%c V[%s] %s", 
                c1, i, c2, 
                clsYabBpSet.bp[i].value_str, 
                clsYabBpSet.bp[i].name);
        }
        else // if(clsYabBpSet.bp[i].type == VPAR_BPT_DISABLED)
        {
            sprintf(cStr, "%c%02d%c ---", c1, i, c2);
        }
        sgBpList->Cells[0][i] = cStr;
    }
}
//---------------------------------------------------------------------------


void __fastcall TForm1::YabauseBpLoadFromGuiAndSave(int id)
{
    char cStr[256];

    clsYabBpSet.bp[id].type = cbBpType->ItemIndex;

    strncpy(clsYabBpSet.bp[id].name, edtBpName->Text.c_str(), sizeof(clsYabBpSet.bp[id].name)-1);

    clsYabBpSet.bp[id].read_access[0] = cbBpReadByte->Checked;
    clsYabBpSet.bp[id].read_access[1] = cbBpReadWord->Checked;
    clsYabBpSet.bp[id].read_access[2] = cbBpReadLong->Checked;

    clsYabBpSet.bp[id].write_access[0] = cbBpWriteByte->Checked;
    clsYabBpSet.bp[id].write_access[1] = cbBpWriteLong->Checked;
    clsYabBpSet.bp[id].write_access[2] = cbBpWriteWord->Checked;

    clsYabBpSet.bp[id].address_check = cbBpAddressCheck->Checked;

    strncpy(clsYabBpSet.bp[id].address_str, edtBpAddress->Text.c_str(), sizeof(clsYabBpSet.bp[id].address_str)-1);
    YabauseBpParseValMask(clsYabBpSet.bp[id].address_str, &clsYabBpSet.bp[id].address_val, &clsYabBpSet.bp[id].address_mask);

    strncpy(clsYabBpSet.bp[id].value_str, edtBpValue->Text.c_str(), sizeof(clsYabBpSet.bp[id].value_str)-1);
    YabauseBpParseValMask(clsYabBpSet.bp[id].value_str, &clsYabBpSet.bp[id].value_val, &clsYabBpSet.bp[id].value_mask);

    /* TODO : update shared memory.
     * Should sort break points according to their types, 
     * in order to optimize break point routines on Yabause side.
     */
    if(_vpar_init)
    {
        VparSetBreakpoints(&clsYabBpSet);
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::sgBpListClick(TObject *Sender)
{
    /* Save settings from GUI to previous ID. */
    YabauseBpLoadFromGuiAndSave(iYabBpCurrentId);

    /* Load settings from current ID to GUI. */
    //AnsiString str;
    //str.printf("row=%d -> %d", iYabBpCurrentId, sgBpList->Row);
    //Form1->mLog->Lines->Add(str.c_str());

    iYabBpCurrentId = sgBpList->Row;
    YabauseBpLoadToGui(iYabBpCurrentId);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnBpSaveClick(TObject *Sender)
{
    /* Save GUI contents to internal data. */
    YabauseBpLoadFromGuiAndSave(iYabBpCurrentId);

    /* Load internal data to GUI.
     * This is needed in order to refresh display of value/mask couples.
     */
    YabauseBpLoadToGui(iYabBpCurrentId);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::cbBpTypeChange(TObject *Sender)
{
    YabauseBpHideShowItems();        
}
//---------------------------------------------------------------------------




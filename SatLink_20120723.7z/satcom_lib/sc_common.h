/* 
 * This software is licensed under terms of the GNU GENERAL PUBLIC LICENSE
 *
 * This software is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This software  is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this software.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Source code is available at http://ppcenter.free.fr
 */


#ifndef SATCOM_COMMON_H
#define SATCOM_COMMON_H

#ifndef MAX
#   define MAX( x, y ) ((x) > (y) ? (x) : (y))
#endif
#ifndef MIN
#   define MIN( x, y ) ((x) < (y) ? (x) : (y))
#endif


#ifdef _BCB
#ifdef  __cplusplus
extern "C" {
#endif
#endif // _BCB




//----------------------------------------------------------------------
// 8/16 bits CRC routines, used for packet validation.
// 
//----------------------------------------------------------------------
unsigned char crc8_start(void);
unsigned char crc8_update(unsigned char crc, unsigned char val);

//----------------------------------------------------------------------
// Another 8 bits CRC, used by USB dev cart
// http://www.iki.fi/Anders.Montonen/sega/usbcart/
// 
//----------------------------------------------------------------------
unsigned char crc_usbdc_init(void);
unsigned char crc_usbdc_update(unsigned char crc, const unsigned char *data, unsigned long data_len);
unsigned char crc_usbdc_finalize(unsigned char crc);

/* Functions codes for USB dev cart. */
enum
{
    USBDC_FUNC_DOWNLOAD      = 1,
    USBDC_FUNC_UPLOAD        = 2,
    USBDC_FUNC_EXEC          = 3,
    USBDC_FUNC_GET_BUFF_ADDR = 4,
    USBDC_FUNC_COPYEXEC      = 5,
};


//----------------------------------------------------------------------
// Compression routines.
// 
//----------------------------------------------------------------------
#include "sc_compress.h"


#ifdef _BCB
#ifdef  __cplusplus
}
#endif
#endif // _BCB






#endif //SATCOM_COMMON_H

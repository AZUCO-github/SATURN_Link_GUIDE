// definition of exported functions

#ifndef _INCLUDE_VPAR_H_
#define _INCLUDE_VPAR_H_

#ifdef  __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <string.h>
#include <stdarg.h>

/**
 * Virtual LPT port DLL for yabause.
 * Simulates PC'sparallel port <-> ARP's Comms port access between Yabause and SatLink.
 *
 * References used:
 *   http://msdn.microsoft.com/en-us/library/windows/desktop/ms686958%28v=vs.85%29.aspx
 *   http://stackoverflow.com/questions/4579640/dll-mutex-an-example
 *   http://msdn.microsoft.com/en-us/library/windows/desktop/ms682411%28v=vs.85%29.aspx
 *   http://msdn.microsoft.com/en-us/library/windows/desktop/aa382954%28v=vs.85%29.aspx
 *   http://tweakbits.com/articles/dll/index.html
**/
/** Whole shared memory data contents. **/

// GCC have alternative #pragma pack(N) syntax and old gcc version not
// support pack(push,N), also any gcc version not support it at some platform
#if defined( __GNUC__ )
#pragma pack(1)
#else
#pragma pack(push,1)
#endif
#define VPAR_STRLEN 128

typedef struct _vpar_io_t
{
	/* (Yabause)Action Replay I/O ports. */
	unsigned char arp_output;
	unsigned char arp_status;
	unsigned char arp_input;
	unsigned char arp_unused1;
	/* (SatLink)Parallel Port I/O ports. */
	unsigned char lpt_inout;
	unsigned char lpt_unused1;
	unsigned char lpt_busy;
	unsigned char io_debug1; /* Mutex errors count. */
} vpar_io_t;

typedef struct _vpar_yabause_set_t
{
	/* Incremented when Yabause updated some data. */
	unsigned char update_counter;

	/* Last debug data file wrote by Yabause. */
	char last_file[VPAR_STRLEN];

	/* PC & other register value. */
	unsigned long pc[2]; // For each CPU
	unsigned long mem_read;
	unsigned long mem_write;
	unsigned char mem_read_cntr;
	unsigned char mem_write_cntr;
	unsigned char unused_regs[64 - 4*2 - 4 - 4 - 1 - 1];

} vpar_yabause_set_t;

typedef struct _vpar_satlink_set_t
{
	/* Incremented when SatLink updated some data. */
	unsigned char update_counter;

	/* Link-related DebugView log output (Yabause side / SatLink side). */
	unsigned char dbgview[2];


	/* When 1, log VDP2 state. */
	unsigned char vdp2log;
	/* When 1, display the state of all registers. */
	unsigned char alldisp;
	/* When 1, display the state of the registers that changed in a "ready to compile" way. */
	unsigned char diffdisp;
	/* When 1, dump the VDP2 memory contents to disk. */
	unsigned char dump;
	/* When 1, save the current state as reference. */
	unsigned char saveref;

	/* Yabause VDP2 poll interval (frames). */
	unsigned short vdp2_poll_interval;


	/* Path where to log debugger data. */
	char logpath[VPAR_STRLEN];



	/* When 1, use yabause internal I/O routines and log output instead of SatLink's. */
	unsigned char crappy_dbg;


	/* Yabause log output enable / disable. */
	unsigned char dbgview_enable;


	/* When 1, log VDP1 state. */
	unsigned char vdp1log;
	/* When 1, log VDP1 registers access. */
	unsigned char vdp1_reglog;
	/* When 1, log VDP1 command table access. */
	unsigned char vdp1_cmdlog;
	/* When 1, periodically dump all VDP1 registers. */
	unsigned char vdp1_regsdump;

	/* When 1, emulate link from yabause. */
	unsigned char ylink_emulate;
	/* When 1, output log related to yabause link emulator. */
	unsigned char log_ylink_emulate;

	/* Monitor data (SH2 registers) refresh interval. */
	unsigned char monitor_interval;

} vpar_satlink_set_t;


/* Pad above structures to fixed size so that compatibility
** is not broken when adding some data. */
#define YABAUSE_SET_PAD (512 - sizeof(vpar_yabause_set_t))
#define SATLINK_SET_PAD (512 - sizeof(vpar_satlink_set_t))


typedef struct _vpar_shared_memory_t
{
	/** ---------------------------------- **/
	/** -- SatLink/Yabause I/O related. -- **/
	vpar_io_t io; // 8 bytes

	/** --------------------------------- **/
	/** -- Common data set by Yabause. -- **/
	vpar_yabause_set_t yabause_set;
	unsigned char yabause_set_pad[YABAUSE_SET_PAD]; // Pad above data to 512 bytes

	/** --------------------------------- **/
	/** -- Common data set by SatLink. -- **/
	vpar_satlink_set_t satlink_set;
	unsigned char satlink_set_pad[SATLINK_SET_PAD]; // Pad above data to 512 bytes
} vpar_shared_memory_t;


// GCC have alternative #pragma pack() syntax and old gcc version not
// support pack(pop), also any gcc version not support it at some platform
#if defined( __GNUC__ )
#pragma pack()
#else
#pragma pack(pop)
#endif



/* Data offsets in shared memory. */
#define VPAR_ARP_OUTPUT 0
#define VPAR_ARP_STATUS 1
#define VPAR_ARP_INPUT  2
// Mem[3] is not used

#define VPAR_LPT_INOUT  4
// Mem[5] is not used ?
#define VPAR_LPT_BUSY   6
#define VPAR_DEBUG1     7

/* Port addresses when accessing ARP port data (for use in yabause). */
#define ARP_OUTPUT_PORT VPAR_ARP_OUTPUT
#define ARP_STATUS_PORT VPAR_ARP_STATUS
#define ARP_INPUT_PORT  VPAR_ARP_INPUT


/* Shared memory available per process. */
#define SHMEM_PROCSIZE 4
#define SHMEM_PROC_TOTAL_SIZE (SHMEM_PROCSIZE * 2)
/* Shared memory total size. */
#define SHMEMSIZE (sizeof(vpar_shared_memory_t))



/*-------------------------------------------------*/
/* Define whether we are using Yabause or SatLink. */
#define PROCESS_ID_YABAUSE 0
#define PROCESS_ID_SATLINK 1
typedef void (*Fct_Vpar_SetProcID)(unsigned char);
__declspec(dllexport) void SetProcID(unsigned char ucProcessId);


/*-------------------------------------------------------------------*/
/* (Debug use) Dump shared memory contents. Return dumped data size. */
typedef unsigned long (*Fct_Vpar_DumpSharedMemory)(unsigned char*, unsigned long);
__declspec(dllexport) unsigned long DumpSharedMemory(unsigned char* pcBuff, unsigned long ulBuffSize);


/*------------------*/
/* Read/Write port. */
typedef unsigned char (*Fct_Vpar_VPortReadByte)(unsigned long ulAddr);
__declspec(dllexport) unsigned char VPortReadByte(unsigned long ulAddr);
typedef void (*Fct_Vpar_VPortWriteByte)(unsigned long, unsigned char);
__declspec(dllexport) void VPortWriteByte(unsigned long ulAddr, unsigned char ucData);


/*----------------------------------*/
/* Yabause/SatLink Parameters Set. */
typedef void (*Fct_Vpar_SetYabauseParameters)(void* ptrParams);
__declspec(dllexport) void SetYabauseParameters(void* ptrParams);

typedef void (*Fct_Vpar_SetSatLinkParameters)(void* ptrParams);
__declspec(dllexport) void SetSatLinkParameters(void* ptrParams);



#ifdef  __cplusplus
}
#endif





#ifdef USE_VPAR_WRAPPER_CLASS

/**
 * VparDll class is an attempt to make easier use of vpar DLL under SatLink.
 * (Yabause doesn't seems to like class, so it can't be used under yabause.)
 *
 * Note : DLL wrapper is adaped from http://tweakbits.com/articles/dll/index.html
**/
class VparDll
{
public:
	//------------------------------------------------------
	// DLL-related stuff.
	VparDll(void)
		: vpar_ucProcessId(PROCESS_ID_YABAUSE)
	{
		/* Open DLL and reset pointers to each functions. */
		vpar_h = LoadLibrary("Vpar.dll");
		if(vpar_h == 0)
		{ /* Second chance. */
			vpar_h = LoadLibrary("satlink\\Vpar\\lib\\Vpar.dll");
		}

		WrapperLogOut("VparDll LoadLibrary = 0x%08X", vpar_h);
		WrapperLogOut("Wrapper Shared memory total size : %d bytes (%d + Y[%d+%d] + S[%d+%d]).", SHMEMSIZE, sizeof(vpar_io_t), sizeof(vpar_yabause_set_t), YABAUSE_SET_PAD, sizeof(vpar_satlink_set_t), SATLINK_SET_PAD);

		/* Init pointers to each functions. */
		vpar_SetProcID            = (Fct_Vpar_SetProcID           )(vpar_h ? GetProcAddress(vpar_h, "SetProcID"           ) : 0);
		vpar_VPortReadByte        = (Fct_Vpar_VPortReadByte       )(vpar_h ? GetProcAddress(vpar_h, "VPortReadByte"       ) : 0);
		vpar_VPortWriteByte       = (Fct_Vpar_VPortWriteByte      )(vpar_h ? GetProcAddress(vpar_h, "VPortWriteByte"      ) : 0);
		vpar_DumpSharedMemory     = (Fct_Vpar_DumpSharedMemory    )(vpar_h ? GetProcAddress(vpar_h, "DumpSharedMemory"    ) : 0);
		vpar_SetSatLinkParameters = (Fct_Vpar_SetSatLinkParameters)(vpar_h ? GetProcAddress(vpar_h, "SetSatLinkParameters") : 0);

		WrapperLogOut(" | vpar_SetProcID            = 0x%08X", vpar_SetProcID);
		WrapperLogOut(" | vpar_VPortReadByte        = 0x%08X", vpar_VPortReadByte);
		WrapperLogOut(" | vpar_VPortWriteByte       = 0x%08X", vpar_VPortWriteByte);
		WrapperLogOut(" | vpar_DumpSharedMemory     = 0x%08X", vpar_DumpSharedMemory);
		WrapperLogOut(" | vpar_SetSatLinkParameters = 0x%08X", vpar_SetSatLinkParameters);
	}
	~VparDll()
	{
		WrapperLogOut("VparDll FreeLibrary = 0x%08X", vpar_h);

		/* Release DLL instance. */
		if(vpar_h != 0)
		{
			FreeLibrary(vpar_h);
		}
	}

	//------------------------------------------------------
	// End-user functions. (I/O related)
	void SetProcID(unsigned char ucProcessId)
	{
		vpar_ucProcessId = ucProcessId;
		if(vpar_SetProcID == 0) return;
		vpar_SetProcID(ucProcessId);
	}
	unsigned char VPortReadByte(unsigned long ulAddr)
	{
		if(vpar_VPortReadByte == 0) return 0x42;
		return vpar_VPortReadByte(ulAddr);
	}
	void VPortWriteByte(unsigned long ulAddr, unsigned char ucData)
	{
		if(vpar_VPortWriteByte == 0) return;
		vpar_VPortWriteByte(ulAddr, ucData);
	}
	unsigned long DumpSharedMemory(unsigned char* pcBuff, unsigned long ulBuffSize)
	{
		if(vpar_DumpSharedMemory == 0) return 0;
		return vpar_DumpSharedMemory(pcBuff, ulBuffSize);
	}
	//------------------------------------------------------
	// End-user functions. (For use in SatLink)
	void GetSharedMemory(vpar_shared_memory_t* ptrParams)
	{
		DumpSharedMemory((unsigned char*)ptrParams, sizeof(vpar_shared_memory_t));
	}
	void SetSatLinkParameters(vpar_satlink_set_t* ptrParams)
	{
		if(vpar_SetSatLinkParameters == 0) return;
		vpar_SetSatLinkParameters((void*)ptrParams);
	}

private:
	//------------------------------------------------------
	// DLL wrapper internal stuff.
	HINSTANCE vpar_h;
	Fct_Vpar_SetProcID        vpar_SetProcID;
	Fct_Vpar_VPortReadByte        vpar_VPortReadByte;
	Fct_Vpar_VPortWriteByte       vpar_VPortWriteByte;
	Fct_Vpar_DumpSharedMemory     vpar_DumpSharedMemory;
	Fct_Vpar_SetSatLinkParameters vpar_SetSatLinkParameters;
	unsigned char vpar_ucProcessId;

	void WrapperLogOut(const char *string, ...)
	{
		char str[256];
		va_list argptr;
		va_start(argptr, string);
		vsnprintf(str, sizeof(str), string, argptr);
		va_end(argptr);

		OutputDebugString(str);
	}
};

#endif // USE_VPAR_WRAPPER_CLASS

#ifdef USE_VPAR_WRAPPER_FUNCTIONS

/**
 * Class-free (prototypes only) wrapper for use in Yabause.
**/
/* I/O read/write functions. */
unsigned char vport_read_byte(unsigned long ulAddr);
void vport_write_byte(unsigned long ulAddr, unsigned char ucData);

/* Get shared memory contents. */
extern vpar_shared_memory_t vpar_sm;
void dbg_get_sharedmem(void);

/* Set Yabause parameters. */
void dbg_set_yabause_parameters(vpar_yabause_set_t* ptrParams);

#endif // USE_VPAR_WRAPPER_FUNCTIONS



#endif // _INCLUDE_VPAR_H_

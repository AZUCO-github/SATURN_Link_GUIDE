/* 
 * This software is licensed under terms of the GNU GENERAL PUBLIC LICENSE
 *
 * This software is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This software  is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this software.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Source code is available at http://ppcenter.free.fr
 */

#ifndef _INCLUDE_SC_USBDC_H_
#define _INCLUDE_SC_USBDC_H_


/* The virtual SatCom class. */
#include "../common/satcom.h"


/* Our USB USB dev cart class. */
class SC_usbdc: public SatCom
{
public:
    virtual char sc_start(void);
    virtual char sc_set(char* parameter, char* value);
    virtual char sc_end(void);
    virtual char sc_send(unsigned long adr, unsigned char* buffer, unsigned long len, char execflag);
    virtual char sc_receive(unsigned long adr, unsigned char* buffer, unsigned long len);
    virtual char* sc_version(void);
};



#endif // _INCLUDE_SC_USBDC_H_


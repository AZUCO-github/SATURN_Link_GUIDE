// FTDI DLL functions wrapper

#ifndef _INCLUDE_FTDI_DLL_H_
#define _INCLUDE_FTDI_DLL_H_

#ifdef  __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <string.h>
#include <stdarg.h>

/**
 * FTDI DLL wrapper.
 * For use with Saturn USB dev cart.
 *
 * References used:
 *   USB dev cart project : http://www.iki.fi/Anders.Montonen/sega/usbcart/
 *   FTDI library used    : https://code.google.com/p/picusb/downloads/list -> libftdi_0.20_devkit_mingw32_08April2012.zip
 *   DLL wrapper          : http://tweakbits.com/articles/dll/index.html
**/

#include "include/ftdi.h"


/* Only the functions below are included in the wrapper. */
// char *ftdi_get_error_string(struct ftdi_context *ftdi);

// int ftdi_init(struct ftdi_context *ftdi);
// int ftdi_usb_open(struct ftdi_context *ftdi, int vendor, int product);
// int ftdi_usb_purge_buffers(struct ftdi_context *ftdi);
// int ftdi_read_data_set_chunksize(struct ftdi_context *ftdi, unsigned int chunksize);
// int ftdi_write_data_set_chunksize(struct ftdi_context *ftdi, unsigned int chunksize);
// int ftdi_set_bitmode(struct ftdi_context *ftdi, unsigned char bitmask, unsigned char mode);
// int ftdi_usb_close(struct ftdi_context *ftdi);

// int ftdi_read_data(struct ftdi_context *ftdi, unsigned char *buf, int size);
// int ftdi_write_data(struct ftdi_context *ftdi, unsigned char *buf, int size);



/*-------------------*/
/* Get error string. */
typedef char* (*Fct_ftdi_get_error_string)(struct ftdi_context *);
__declspec(dllexport) char *Wrapper_ftdi_get_error_string(struct ftdi_context *ftdi);


/*-------------*/
/* Open/Close. */
typedef int (*Fct_ftdi_init)(struct ftdi_context *);
__declspec(dllexport) int Wrapper_ftdi_init(struct ftdi_context *ftdi);

typedef int (*Fct_ftdi_usb_open)(struct ftdi_context *, int, int);
__declspec(dllexport) int Wrapper_ftdi_usb_open(struct ftdi_context *ftdi, int vendor, int product);

typedef int (*Fct_ftdi_usb_purge_buffers)(struct ftdi_context *);
__declspec(dllexport) int Wrapper_ftdi_usb_purge_buffers(struct ftdi_context *ftdi);

typedef int (*Fct_ftdi_read_data_set_chunksize)(struct ftdi_context *, unsigned int);
__declspec(dllexport) int Wrapper_ftdi_read_data_set_chunksize(struct ftdi_context *ftdi, unsigned int chunksize);

typedef int (*Fct_ftdi_write_data_set_chunksize)(struct ftdi_context *, unsigned int);
__declspec(dllexport) int Wrapper_ftdi_write_data_set_chunksize(struct ftdi_context *ftdi, unsigned int chunksize);

typedef int (*Fct_ftdi_set_bitmode)(struct ftdi_context *, unsigned char , unsigned char);
__declspec(dllexport) int Wrapper_ftdi_set_bitmode(struct ftdi_context *ftdi, unsigned char bitmask, unsigned char mode);

typedef int (*Fct_ftdi_usb_close)(struct ftdi_context *);
__declspec(dllexport) int Wrapper_ftdi_usb_close(struct ftdi_context *ftdi);


/*------------------*/
/* Read/Write data. */
typedef int (*Fct_ftdi_read_data)(struct ftdi_context *, unsigned char *, int);
__declspec(dllexport) int Wrapper_ftdi_read_data(struct ftdi_context *ftdi, unsigned char *buf, int size);

typedef int (*Fct_ftdi_write_data)(struct ftdi_context *, unsigned char *, int);
__declspec(dllexport) int Wrapper_ftdi_write_data(struct ftdi_context *ftdi, unsigned char *buf, int size);



#ifdef  __cplusplus
}
#endif




class FtdiDll
{
public:
    //------------------------------------------------------
    // DLL-related stuff.
    FtdiDll(void)
    {
        /* Open DLL and reset pointers to each functions. */
        ftdidll_h = LoadLibrary("libftdi.dll");

        WrapperLogOut("FtdiDll LoadLibrary = 0x%08X", ftdidll_h);

        /* Init pointers to each functions. */
        ftdidll_get_error_string         = (Fct_ftdi_get_error_string        )(ftdidll_h ? GetProcAddress(ftdidll_h, "ftdi_get_error_string"        ) : 0);

        ftdidll_init                     = (Fct_ftdi_init                    )(ftdidll_h ? GetProcAddress(ftdidll_h, "ftdi_init"                    ) : 0);
        ftdidll_usb_open                 = (Fct_ftdi_usb_open                )(ftdidll_h ? GetProcAddress(ftdidll_h, "ftdi_usb_open"                ) : 0);
        ftdidll_usb_purge_buffers        = (Fct_ftdi_usb_purge_buffers       )(ftdidll_h ? GetProcAddress(ftdidll_h, "ftdi_usb_purge_buffers"       ) : 0);
        ftdidll_read_data_set_chunksize  = (Fct_ftdi_read_data_set_chunksize )(ftdidll_h ? GetProcAddress(ftdidll_h, "ftdi_read_data_set_chunksize" ) : 0);
        ftdidll_write_data_set_chunksize = (Fct_ftdi_write_data_set_chunksize)(ftdidll_h ? GetProcAddress(ftdidll_h, "ftdi_write_data_set_chunksize") : 0);
        ftdidll_set_bitmode              = (Fct_ftdi_set_bitmode             )(ftdidll_h ? GetProcAddress(ftdidll_h, "ftdi_set_bitmode"             ) : 0);
        ftdidll_usb_close                = (Fct_ftdi_usb_close               )(ftdidll_h ? GetProcAddress(ftdidll_h, "ftdi_usb_close"               ) : 0);

        ftdidll_read_data                = (Fct_ftdi_read_data               )(ftdidll_h ? GetProcAddress(ftdidll_h, "ftdi_read_data"               ) : 0);
        ftdidll_write_data               = (Fct_ftdi_write_data              )(ftdidll_h ? GetProcAddress(ftdidll_h, "ftdi_write_data"              ) : 0);

        WrapperLogOut(" | ftdidll_get_error_string         = 0x%08X", ftdidll_get_error_string);

        WrapperLogOut(" | ftdidll_init                     = 0x%08X", ftdidll_init);
        WrapperLogOut(" | ftdidll_usb_open                 = 0x%08X", ftdidll_usb_open);
        WrapperLogOut(" | ftdidll_usb_purge_buffers        = 0x%08X", ftdidll_usb_purge_buffers);
        WrapperLogOut(" | ftdidll_read_data_set_chunksize  = 0x%08X", ftdidll_read_data_set_chunksize);
        WrapperLogOut(" | ftdidll_write_data_set_chunksize = 0x%08X", ftdidll_write_data_set_chunksize);
        WrapperLogOut(" | ftdidll_set_bitmode              = 0x%08X", ftdidll_set_bitmode);
        WrapperLogOut(" | ftdidll_usb_close                = 0x%08X", ftdidll_usb_close);

        WrapperLogOut(" | ftdidll_read_data                = 0x%08X", ftdidll_read_data);
        WrapperLogOut(" | ftdidll_write_data               = 0x%08X", ftdidll_write_data);
    }
    ~FtdiDll()
    {
        WrapperLogOut("FtdiDll FreeLibrary = 0x%08X", ftdidll_h);

        /* Release DLL instance. */
        if(ftdidll_h != 0)
        {
            FreeLibrary(ftdidll_h);
        }
    }

    //------------------------------------------------------
    // End-user function. (DLL wrap status)
    int is_dll_opened(void)
    {
        if(ftdidll_get_error_string         == 0) return 0;

        if(ftdidll_init                     == 0) return 0;
        if(ftdidll_usb_open                 == 0) return 0;
        if(ftdidll_usb_purge_buffers        == 0) return 0;
        if(ftdidll_read_data_set_chunksize  == 0) return 0;
        if(ftdidll_write_data_set_chunksize == 0) return 0;
        if(ftdidll_set_bitmode              == 0) return 0;
        if(ftdidll_usb_close                == 0) return 0;

        if(ftdidll_read_data                == 0) return 0;
        if(ftdidll_write_data               == 0) return 0;

        return 1;
    }

    //------------------------------------------------------
    // End-user function. (Get error string)
    char* get_error_string(struct ftdi_context *ftdi)
    {
        char* ret = NULL;
        if(ftdidll_get_error_string == 0) return ret;
        ret = ftdidll_get_error_string(ftdi);
        return ret;
    }

    //------------------------------------------------------
    // End-user functions. (Open/Close related)
    int init(struct ftdi_context *ftdi)
    {
        int ret = 0;
        WrapperLogOut("FtdiDll::init()", 0);
        if(ftdidll_init == 0) return ret;
        ret = ftdidll_init(ftdi);
        WrapperLogOut("FtdiDll::init ret = %d", ret);
        return ret;
    }
    int usb_open(struct ftdi_context *ftdi, int vendor, int product)
    {
        int ret = 0;
        WrapperLogOut("FtdiDll::usb_open(vendor = 0x%04X, product = 0x%04X)", vendor, product);
        if(ftdidll_usb_open == 0) return ret;
        ret = ftdidll_usb_open(ftdi, vendor, product);
        WrapperLogOut("FtdiDll::usb_open ret = %d", ret);
        return ret;
    }
    int usb_purge_buffers(struct ftdi_context *ftdi)
    {
        int ret = 0;
        WrapperLogOut("FtdiDll::usb_purge_buffers()", 0);
        if(ftdidll_usb_purge_buffers == 0) return ret;
        ret = ftdidll_usb_purge_buffers(ftdi);
        WrapperLogOut("FtdiDll::usb_purge_buffers ret = %d", ret);
        return ret;
    }
    int read_data_set_chunksize(struct ftdi_context *ftdi, unsigned int chunksize)
    {
        int ret = 0;
        WrapperLogOut("FtdiDll::read_data_set_chunksize(chunksize = %d)", chunksize);
        if(ftdidll_read_data_set_chunksize == 0) return ret;
        ret = ftdidll_read_data_set_chunksize(ftdi, chunksize);
        WrapperLogOut("FtdiDll::read_data_set_chunksize ret = %d", ret);
        return ret;
    }
    int write_data_set_chunksize(struct ftdi_context *ftdi, unsigned int chunksize)
    {
        int ret = 0;
        WrapperLogOut("FtdiDll::write_data_set_chunksize(chunksize = %d)", chunksize);
        if(ftdidll_write_data_set_chunksize == 0) return ret;
        ret = ftdidll_write_data_set_chunksize(ftdi, chunksize);
        WrapperLogOut("FtdiDll::write_data_set_chunksize ret = %d", ret);
        return ret;
    }
    int set_bitmode(struct ftdi_context *ftdi, unsigned char bitmask, unsigned char mode)
    {
        int ret = 0;
        WrapperLogOut("FtdiDll::set_bitmode(bitmask = %d, mode = %d)", bitmask, mode);
        if(ftdidll_set_bitmode == 0) return ret;
        ret = ftdidll_set_bitmode(ftdi, bitmask, mode);
        WrapperLogOut("FtdiDll::set_bitmode ret = %d", ret);
        return ret;
    }
    int usb_close(struct ftdi_context *ftdi)
    {
        int ret = 0;
        WrapperLogOut("FtdiDll::usb_close()", 0);
        if(ftdidll_usb_close == 0) return ret;
        ret = ftdidll_usb_close(ftdi);
        WrapperLogOut("FtdiDll::usb_close ret = %d", ret);
        return ret;
    }

    //------------------------------------------------------
    // End-user functions. (I/O related)
    int read_data(struct ftdi_context *ftdi, unsigned char *buf, int size)
    {
        int ret = 0;
        WrapperLogOut("FtdiDll::read_data(size = %d)", size);
        if(ftdidll_read_data == 0) return ret;
        ret = ftdidll_read_data(ftdi, buf, size);
        WrapperLogOut("FtdiDll::read_data ret = %d", ret);
        return ret;
    }
    int write_data(struct ftdi_context *ftdi, unsigned char *buf, int size)
    {
        int ret = 0;
        WrapperLogOut("FtdiDll::write_data(size = %d)", size);
        if(ftdidll_write_data == 0) return ret;
        ret = ftdidll_write_data(ftdi, buf, size);
        WrapperLogOut("FtdiDll::write_data ret = %d", ret);
        return ret;
    }

private:
    //------------------------------------------------------
    // DLL wrapper internal stuff.
    HINSTANCE ftdidll_h;
    Fct_ftdi_get_error_string         ftdidll_get_error_string;

    Fct_ftdi_init                     ftdidll_init;
    Fct_ftdi_usb_open                 ftdidll_usb_open;
    Fct_ftdi_usb_purge_buffers        ftdidll_usb_purge_buffers;
    Fct_ftdi_read_data_set_chunksize  ftdidll_read_data_set_chunksize;
    Fct_ftdi_write_data_set_chunksize ftdidll_write_data_set_chunksize;
    Fct_ftdi_set_bitmode              ftdidll_set_bitmode;
    Fct_ftdi_usb_close                ftdidll_usb_close;

    Fct_ftdi_read_data                ftdidll_read_data;
    Fct_ftdi_write_data               ftdidll_write_data;


    void WrapperLogOut(const char *string, ...)
    {
        char str[256];
        va_list argptr;
        va_start(argptr, string);
        vsnprintf(str, sizeof(str), string, argptr);
        va_end(argptr);

        OutputDebugString(str);
    }
};



#endif // _INCLUDE_FTDI_DLL_H_

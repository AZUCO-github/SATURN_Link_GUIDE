/* 
 * This software is licensed under terms of the GNU GENERAL PUBLIC LICENSE
 *
 * This software is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This software  is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this software.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Source code is available at http://ppcenter.free.fr
 */

#include "../common/satcom.h"
#include "sc_usbdc.h"

/* Includes CRC used by USB dev cart and USBDC_FUNC_* definitions. */
#include "../../satcom_lib/sc_common.h"

/* Class to our FTDI chip. */
#include "ftdi_dll.h"
FtdiDll _ftdi;


////////////////////////////////////////////////////////////////////////
// Init/end/send\receive related functions.
// Note: grabbed source code from http://www.iki.fi/Anders.Montonen/sega/usbcart/
////////////////////////////////////////////////////////////////////////


/* Optimal payload/usb transfer size, see FTDI appnote */
#define USB_READPACKET_SIZE (64*1024)
#define USB_WRITEPACKET_SIZE (4*1024)
#define USB_PAYLOAD(x) ((x)-(((x)/64)*2))
#define READ_PAYLOAD_SIZE (USB_PAYLOAD(USB_READPACKET_SIZE))
#define WRITE_PAYLOAD_SIZE (USB_PAYLOAD(USB_WRITEPACKET_SIZE))

static unsigned char SendBuf[2*WRITE_PAYLOAD_SIZE];
static unsigned char RecvBuf[2*READ_PAYLOAD_SIZE];
static struct ftdi_context Device = {0};



static int DoDownload(unsigned int address, unsigned char* pFileBuffer, unsigned int size)
{
    unsigned int  received = 0;
    int           status = -1;
    unsigned char readChecksum, calcChecksum;

    STATUS_CALLBACK(CLBK_START, 0, pFileBuffer, 0, size);

    SendBuf[0] = USBDC_FUNC_DOWNLOAD; /* Client function */
    SendBuf[1] = (unsigned char)(address >> 24);
    SendBuf[2] = (unsigned char)(address >> 16);
    SendBuf[3] = (unsigned char)(address >> 8);
    SendBuf[4] = (unsigned char)(address);
    SendBuf[5] = (unsigned char)(size >> 24);
    SendBuf[6] = (unsigned char)(size >> 16);
    SendBuf[7] = (unsigned char)(size >> 8);
    SendBuf[8] = (unsigned char)(size);

    status = _ftdi.write_data(&Device, SendBuf, 9);
    if (status < 0)
    {
        scl_log(SCLT_DLLPG, 0, "Send download command error: %s", _ftdi.get_error_string(&Device));
        goto DownloadError;
    }

    while (size - received > 0)
    {
        STATUS_CALLBACK(CLBK_RECEIVE, address, pFileBuffer, received, size);

        status = _ftdi.read_data(&Device, &pFileBuffer[received], size);
        if (status < 0)
        {
            scl_log(SCLT_DLLPG, 0, "Read data error: %s", _ftdi.get_error_string(&Device));
            goto DownloadError;
        }

        received += status;
    }

    // The transfer may timeout, so loop until a byte
    // is received or an error occurs.
    do
    {
        status = _ftdi.read_data(&Device, (unsigned char*)&readChecksum, 1);
        if (status < 0)
        {
            scl_log(SCLT_DLLPG, 0, "Read data error: %s", _ftdi.get_error_string(&Device));
            goto DownloadError;
        }
    } while (status == 0);


    calcChecksum = crc_usbdc_init();
    calcChecksum = crc_usbdc_update(calcChecksum, pFileBuffer, size);
    calcChecksum = crc_usbdc_finalize(calcChecksum);

    if (readChecksum != calcChecksum)
    {
        scl_log(SCLT_DLLPG, 0, "Checksum error (%0x, should be %0x)", calcChecksum, readChecksum);
        status = -1;
        goto DownloadError;
    }


DownloadError:

    STATUS_CALLBACK(CLBK_END, 0, pFileBuffer, size, size);
    return status < 0 ? 0 : 1;
}

/* Sending the write command and data separately is inefficient,
   but simplifies the code. The alternative is to copy also the data
   into the sendbuffer. */
static int DoUpload(unsigned int Address, unsigned char* pFileBuffer, unsigned int size)
{
    unsigned int  sent = 0;
    int           status = 0;
    unsigned char checksum = crc_usbdc_init();

    STATUS_CALLBACK(CLBK_START, 0, pFileBuffer, 0, size);

    checksum = crc_usbdc_update(checksum, pFileBuffer, size);
    checksum = crc_usbdc_finalize(checksum);

    SendBuf[0] = USBDC_FUNC_UPLOAD; /* Client function */
    SendBuf[1] = (unsigned char)(Address >> 24);
    SendBuf[2] = (unsigned char)(Address >> 16);
    SendBuf[3] = (unsigned char)(Address >> 8);
    SendBuf[4] = (unsigned char)Address;
    SendBuf[5] = (unsigned char)(size >> 24);
    SendBuf[6] = (unsigned char)(size >> 16);
    SendBuf[7] = (unsigned char)(size >> 8);
    SendBuf[8] = (unsigned char)size;
    status = _ftdi.write_data(&Device, SendBuf, 9);

    if (status < 0)
    {
        scl_log(SCLT_DLLPG, 0, "Send upload command error: %s", _ftdi.get_error_string(&Device));
        goto UploadError;
    }

    while (size - sent > 0)
    {
        STATUS_CALLBACK(CLBK_SEND, Address, pFileBuffer, sent, size);

        status = _ftdi.write_data(&Device, &pFileBuffer[sent], size-sent);
        if (status < 0)
        {
            scl_log(SCLT_DLLPG, 0, "Send data error: %s", _ftdi.get_error_string(&Device));
            goto UploadError;
        }

        sent += status;
    }

    SendBuf[0] = (unsigned char)checksum;
    status = _ftdi.write_data(&Device, SendBuf, 1);

    if (status < 0)
    {
        scl_log(SCLT_DLLPG, 0, "Send checksum error: %s", _ftdi.get_error_string(&Device));
        goto UploadError;
    }

    do
    {
        status = _ftdi.read_data(&Device, RecvBuf, 1);
        if (status < 0)
        {
            scl_log(SCLT_DLLPG, 0, "Read upload result failed: %s", _ftdi.get_error_string(&Device));
            goto UploadError;
        }
    } while (status == 0);

    if (RecvBuf[0] != 0)
    {
        status = -1;
    }


UploadError:

    STATUS_CALLBACK(CLBK_END, 0, pFileBuffer, size, size);
    return status < 0 ? 0 : 1;
}

static int DoExecute(unsigned int Address)
{
    int status = 0;

    SendBuf[0] = USBDC_FUNC_EXEC; /* Client function */
    SendBuf[1] = (unsigned char)(Address >> 24);
    SendBuf[2] = (unsigned char)(Address >> 16);
    SendBuf[3] = (unsigned char)(Address >> 8);
    SendBuf[4] = (unsigned char)Address;
    status = _ftdi.write_data(&Device, SendBuf, 5);
    if (status < 0)
    {
        scl_log(SCLT_DLLPG, 0, "Send execute error: %s", _ftdi.get_error_string(&Device));
    }

    return status < 0 ? 0 : 1;
}

static int DoGetBufferAddress(unsigned long* upload_address)
{
    unsigned char data[4];
    unsigned char* pFileBuffer = data;
    unsigned long size = 4;
    unsigned int  received = 0;
    int           status = -1;
    unsigned char readChecksum, calcChecksum;

    *upload_address = 0;
    SendBuf[0] = USBDC_FUNC_GET_BUFF_ADDR; /* Client function */

    status = _ftdi.write_data(&Device, SendBuf, 1);
    if (status < 0)
    {
        scl_log(SCLT_DLLPG, 0, "Send download command error: %s", _ftdi.get_error_string(&Device));
        goto GetBufferAddressError;
    }

    while (size - received > 0)
    {
        status = _ftdi.read_data(&Device, &pFileBuffer[received], size);
        if (status < 0)
        {
            scl_log(SCLT_DLLPG, 0, "Read data error: %s", _ftdi.get_error_string(&Device));
            goto GetBufferAddressError;
        }

        received += status;
    }

    *upload_address  = data[0] << 24;
    *upload_address |= data[1] << 16;
    *upload_address |= data[2] <<  8;
    *upload_address |= data[3] <<  0;
    scl_log(SCLT_DLLPG, 1, "upload_address = 0x%08X", upload_address);

GetBufferAddressError:

    return status < 0 ? 0 : 1;
}


static int DoCopyExecute(unsigned long upload_address, unsigned long length, unsigned long address)
{
    int status = 0;

    SendBuf[ 0] = USBDC_FUNC_COPYEXEC; /* Client function */

    SendBuf[ 1] = (unsigned char)(upload_address >> 24);
    SendBuf[ 2] = (unsigned char)(upload_address >> 16);
    SendBuf[ 3] = (unsigned char)(upload_address >> 8);
    SendBuf[ 4] = (unsigned char)upload_address;

    SendBuf[ 5] = (unsigned char)(length >> 24);
    SendBuf[ 6] = (unsigned char)(length >> 16);
    SendBuf[ 7] = (unsigned char)(length >> 8);
    SendBuf[ 8] = (unsigned char)length;

    SendBuf[ 9] = (unsigned char)(address >> 24);
    SendBuf[10] = (unsigned char)(address >> 16);
    SendBuf[11] = (unsigned char)(address >> 8);
    SendBuf[12] = (unsigned char)address;

    status = _ftdi.write_data(&Device, SendBuf, 13);
    if (status < 0)
    {
        scl_log(SCLT_DLLPG, 0, "Send copy&execute error: %s", _ftdi.get_error_string(&Device));
    }

    return status < 0 ? 0 : 1;
}




static int InitComms(int VID, int PID)
{
    int status = _ftdi.init(&Device);
    int error = 0;

    if (status < 0)
    {
        scl_log(SCLT_DLLPG, 0, "Init error: %s", _ftdi.get_error_string(&Device));
        error = 1;
    }
    else
    {
        status = _ftdi.usb_open(&Device, VID, PID);
        if (status < 0 && status != -5)
        {
            scl_log(SCLT_DLLPG, 0, "Device open error: %s", _ftdi.get_error_string(&Device));
            error = 1;
        }
        else
        {
            status = _ftdi.usb_purge_buffers(&Device);
            if (status < 0)
            {
                scl_log(SCLT_DLLPG, 0, "Purge buffers error: %s", _ftdi.get_error_string(&Device));
                error = 1;
            }

            status = _ftdi.read_data_set_chunksize(&Device, USB_READPACKET_SIZE);
            if (status < 0)
            {
                scl_log(SCLT_DLLPG, 0, "Set read chunksize error: %s", _ftdi.get_error_string(&Device));
                error = 1;
            }

            status = _ftdi.write_data_set_chunksize(&Device, USB_WRITEPACKET_SIZE);
            if (status < 0)
            {
                scl_log(SCLT_DLLPG, 0, "Set write chunksize error: %s", _ftdi.get_error_string(&Device));
                error = 1;
            }

            status = _ftdi.set_bitmode(&Device, 0x0, BITMODE_RESET);
            if (status < 0)
            {
                scl_log(SCLT_DLLPG, 0, "Bitmode configuration error: %s", _ftdi.get_error_string(&Device));
                error = 1;
            }

            if (error)
            {
                _ftdi.usb_close(&Device);
            }
        }
    }

    return !error;
}

static void CloseComms(void)
{
    int status = _ftdi.usb_purge_buffers(&Device);
    if (status < 0)
    {
        scl_log(SCLT_DLLPG, 0, "Purge buffers error: %s", _ftdi.get_error_string(&Device));
    }

    _ftdi.usb_close(&Device);
}






////////////////////////////////////////////////////////////////////////
// Derived class functions
////////////////////////////////////////////////////////////////////////

int _vid = 0x0403;
int _pid = 0x6001;
int _smart_exec = 1;



/**
 *  DLL startup : Display help screen.
**/
char SC_usbdc::sc_start(void)
{
    /* Set default settings. */
    _vid = 0x0403;
    _pid = 0x6001;
    _smart_exec = 1;


    /* Display help screen. */
    scl_log(SCLT_DLLPG, 4, "USB dev cart interface.");
    scl_log(SCLT_DLLPG, 4, " From http://www.iki.fi/Anders.Montonen/sega/usbcart/");
    scl_log(SCLT_DLLPG, 4, "Available parameters :");
    scl_log(SCLT_DLLPG, 4, " v          <VID> : Set device VID (Default 0x%04X).", _vid);
    scl_log(SCLT_DLLPG, 4, " p          <PID> : Set device PID (Default 0x%04X).", _pid);
    scl_log(SCLT_DLLPG, 4, " smart_exec <0/1> : Turn off/on smart exec.");
    scl_log(SCLT_DLLPG, 4, " display    <1>   : Display configuration settings.");
    scl_log(SCLT_DLLPG, 4, " init       <1>   : Init USB device.");
    

    if(_ftdi.is_dll_opened() != 1)
    {
        scl_log(SCLT_DLLPG, 0, "Error: couldn't open libftdi.dll");
        return SC_ERROR_PORT;
    }

    return SC_NOERROR;
}

/**
 *  Set internal parameter.
**/
char SC_usbdc::sc_set(char* parameter, char* value)
{
    int err = SC_NOERROR;
    int ret = 0;

    if(_ftdi.is_dll_opened() != 1)
    {
        scl_log(SCLT_DLLPG, 0, "Error: couldn't open libftdi.dll");
        return SC_ERROR_PORT;
    }

    /* Parse parameters. */
    //scl_log(SCLT_DLLPG, 9, "param = %s", parameter);
    if(!stricmp(parameter, "v"))
    {
        _vid = strtoul(value, NULL, 0);
        scl_log(SCLT_DLLPG, 4, "Set VID 0x%04X", _vid);
    }
    else if(!stricmp(parameter, "p"))
    {
        _pid = strtoul(value, NULL, 0);
        scl_log(SCLT_DLLPG, 4, "Set PID 0x%04X", _pid);
    }
    else if(!stricmp(parameter, "smart_exec"))
    {
        _smart_exec = strtoul(value, NULL, 0);
        scl_log(SCLT_DLLPG, 4, "Set smart_exec %d", _pid);
    }
    else if(!stricmp(parameter, "display"))
    {
        /* Display parameters contents to log. */
        scl_log(SCLT_DLLPG, 1, "USB dev cart internal settings");
        scl_log(SCLT_DLLPG, 1, "|VID        : 0x%04X", _vid);
        scl_log(SCLT_DLLPG, 1, "|PID        : 0x%04X", _pid);
        scl_log(SCLT_DLLPG, 1, "|smart_exec : %d", _smart_exec);
    }
    else if(!stricmp(parameter, "init"))
    {
        /* Initialize device. */
        scl_log(SCLT_DLLPG, 1, "USB dev cart init ...");
        ret = InitComms(_vid, _pid);
        scl_log(SCLT_DLLPG, 1, "USB dev cart init = %d", ret);
    }
    else
    {
        scl_log(SCLT_DLLPG, 0, "ERROR: Unknown parameter : \"%s\"", parameter);
        return SC_ERROR_PARAMETER;
    }

    return SC_NOERROR;
}

/**
 *  Close USB dev cart.
**/
char SC_usbdc::sc_end(void)
{
    if(_ftdi.is_dll_opened() != 1)
    {
        scl_log(SCLT_DLLPG, 0, "Error: couldn't open libftdi.dll");
        return SC_ERROR_PORT;
    }

    scl_log(SCLT_DLLPG, 4, "Close USB dev cart connection ...");
    CloseComms();

    return SC_NOERROR;
}





/**
 *  Receive data from Saturn.
**/
char SC_usbdc::sc_receive(unsigned long address, unsigned char* buffer, unsigned long length)
{
    int ret = 0;

    if(_ftdi.is_dll_opened() != 1)
    {
        scl_log(SCLT_DLLPG, 0, "Error: couldn't open libftdi.dll");
        return SC_ERROR_PORT;
    }

    ret = DoDownload(address, buffer, length);
    scl_log(SCLT_DLLPG, 1, "DoUpload = %d", ret);

    return SC_NOERROR;
}




/**
 *  Send data to Saturn.
**/
char SC_usbdc::sc_send(unsigned long address, unsigned char* buffer, unsigned long length, char exec_flag)
{
    int ret = 0;
    unsigned long upload_address = address;

    if(_ftdi.is_dll_opened() != 1)
    {
        scl_log(SCLT_DLLPG, 0, "Error: couldn't open libftdi.dll");
        return SC_ERROR_PORT;
    }

    if(exec_flag)
    {
        if(_smart_exec)
        {
            ret = DoGetBufferAddress(&upload_address);
            scl_log(SCLT_DLLPG, 1, "DoGetBufferAddress() = %d, upload_address = 0x%08X", ret, upload_address);

            /**
             * upload_address is null means that FW is running from ROM
             * -> In this case, it is OK to directly upload data to exec address.
            **/
            if(upload_address == 0)
            {
                upload_address = address;
            }
        }
    }

    ret = DoUpload(upload_address, buffer, length);
    scl_log(SCLT_DLLPG, 1, "DoUpload(upload_address=0x%08X, buffer, length=%d) = %d", upload_address, length, ret);

    if(exec_flag)
    {
        if((_smart_exec) && (upload_address != address))
        {
            scl_log(SCLT_DLLPG, 1, "DoCopyExecute(upload_address=0x%08X, length=%d, address=%08X)", upload_address, length, address);
            DoCopyExecute(upload_address, length, address);
        }
        else
        {
            scl_log(SCLT_DLLPG, 1, "DoCopyExecute(upload_address=0x%08X)", upload_address);
            DoExecute(upload_address);
        }
    }

    return SC_NOERROR;
}



/**
 *  Return DLL version informations.
**/
char* SC_usbdc::sc_version(void)
{
    if(_ftdi.is_dll_opened() != 1)
    {
        sprintf(_version, (char*)("Saturn USB dev cart (FTDI) interface. <NO DLL>"));
    }
    else
    {
        sprintf(_version, (char*)("Saturn USB dev cart (FTDI) interface Ver. 0.2"));
    }

    return _version;
}


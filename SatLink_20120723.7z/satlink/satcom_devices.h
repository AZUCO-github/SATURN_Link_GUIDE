/* 
 * This software is licensed under terms of the GNU GENERAL PUBLIC LICENSE
 *
 * This software is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This software  is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this software.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Source code is available at http://ppcenter.free.fr
 */


#ifndef _INCLUDE_SATCOM_DEVICES_H_
#define _INCLUDE_SATCOM_DEVICES_H_


#include "common/satcom.h"


/*-----------------------------------------------------------------------------------*/
/* All the available PC<->Saturn communication devices. */

/* Dummy device, for testing SatLink without using Saturn. */
#include "dummy/sc_dummy.h"

/* USB Data Link. */
#include "usbdl/sc_usbdl.h"

/* Parallel Port based device. */
#include "parlink/sc_parlink.h"

/* USB dev cart. */
#include "usb_dev_cart/sc_usbdc.h"



#endif // _INCLUDE_SATCOM_DEVICES_H_

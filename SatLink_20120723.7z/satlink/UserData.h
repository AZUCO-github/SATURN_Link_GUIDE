#ifndef _USER_DATA_H_
#define _USER_DATA_H_

#pragma pack(push,1)

enum ButtonIndex {
    MNI_SETUDLPARAMS,
    MNI_OPENUDL,
    MNI_SENDBRAM,
    MNI_EXECPROG,
    MNI_RCVBRAM,
    MNI_RCVBIOS,
    MNI_RCVARPFW,


    BTN_OPEN,
    BTN_CLOSE,
    BTN_PARAMSET,
    BTN_SEND,
    BTN_FASTEXEC,
    BTN_RECEIVE,

    BTN_MAINLOGCLEAR,
    BTN_MAINLOGSAVE,
    BTN_LOGLEVELSET,

    BTN_LOGCLEAR,
    BTN_LOGLDSETTINGS,
    BTN_LOGSAVE,

    BTN_ADDRDOWN,
    BTN_ADDRUP,

    BTN_ADDRPREV2,
    BTN_ADDRNEXT2,

    BTN_MVREAD,
    BTN_MVWRITE,

    BTN_MFIND,

    BTN_MVRGB,

    BTN_PROMPTSEND,
    BTN_DBGFOLDER,

    BTN_TARGETINFO,
    BTN_VDP1VIEW,

    BTN_SILENTON,
    BTN_SILENTOFF,

    BTN_REGREAD, 
    BTN_REGWRITE, 
    BTN_REGEXEC, 
    BTN_REGLOGCLEAR, 

    BTN_TEST1,
    BTN_COUNT
};


#define STR_LEN 1024
#define MEMVIEW_DATASIZE (16*8)
#define DISASM_MEMSIZE 2048
struct UserData
{
    /* [Updated by Form1]Buttons push state */
    unsigned char btn[BTN_COUNT];

    /* [Updated by ProcessThread]CheckBox/RadioButtons states */
    unsigned long address;
    unsigned long dbg_address;
    unsigned long length;
    unsigned char length_is_KB;
    unsigned char exec_flag;
    unsigned char dbg_enable;
    unsigned char dbg_use;
    unsigned long dbg_sleep;
    unsigned long silent_dbg;
    unsigned char dbglog_date;
    unsigned char disasm_mem;

    long log_type;
    long log_output;
    long log_level;
    unsigned char log_silent;

    unsigned long mv_address;
    unsigned char mv_autoread;
    unsigned char mv_data[MEMVIEW_DATASIZE];
    unsigned long disasm_mem_use;
    unsigned long disasm_mem_address;
    unsigned char disasm_mem_data[DISASM_MEMSIZE];

    unsigned char fdis_use;
    char fdis_path[STR_LEN];
    unsigned long fdis_offset;
    unsigned long fdis_address;

    unsigned char mv_cntr, mv_cver;
    unsigned char mv_woff, mv_wlen; /* Used when writing data. */
    unsigned long mf_data, mf_range; /* Memory find-related. */
    unsigned long mv_rgbw, mv_rgbh; /* Memory RGB555 display related. */


    /* [Updated by ProcessThread]Text fields */
    char main_log_file[STR_LEN];
    char log_file[STR_LEN];
    char log_settings[STR_LEN];

    char ini_file[STR_LEN];
    char param_text[STR_LEN];
    char param_value[STR_LEN];

    char up_file[STR_LEN];
    char down_file[STR_LEN];
    char dbg_file[STR_LEN];
    char dbg_folder[STR_LEN];
    char prompt_answer[STR_LEN];

    char reg_address[STR_LEN];
    char reg_len[STR_LEN];
    char reg_value[STR_LEN];
    char reg_macro[STR_LEN];


    /* [Updated by ProcessThread]Text fields */

    /* [Updated by ProcessThread]Status bar */
    unsigned char transfer_on;
    unsigned char debugger_on;
    unsigned char prompt_on;

    /* [Updated by ProcessThread]DBG pool count */
    unsigned char debugger_count;
};
#pragma pack(pop)


#endif // _USER_DATA_H_



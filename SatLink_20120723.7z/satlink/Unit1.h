//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <Dialogs.hpp>

#include <stdio.h>
#include <stdarg.h>


#include "ProcessThread.h"
#include "inifile.h"
#include "parlink/parlink.h" /* for _vpar. */
#include <ExtCtrls.hpp>
#include <Grids.hpp>
#include <Menus.hpp>
#include <ToolWin.hpp>

/* Status bar fields index. */
#define SB_TRANSFER_INDEX 0
#define SB_DEBUGGER_INDEX 1
#define SB_LOG_INDEX      2
#define SB_SPEED_INDEX    3
#define SB_VERSION_INDEX  4
/*
 * Status bar activity field.
 *  0~SB_ACTIVITY_MAXCOUNT-1 : transfering ...
 */
#define SB_ACTIVITY_MAXCOUNT 4
/*
 * Prompt display rate
 */
#define SB_PROMPT_DISP_RATE 6

//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TGroupBox *GroupBox1;
        TMemo *mLog;
        TOpenDialog *odFile;
        TSaveDialog *sdFile;
        TStatusBar *StatusBar;
        TPageControl *psSettings;
        TTabSheet *tsReadWrite;
        TGroupBox *GroupBox6;
        TLabel *Label9;
        TEdit *edtDownFile;
        TButton *btnDownSelect;
        TButton *btnDownload;
        TGroupBox *GroupBox7;
        TLabel *Label10;
        TEdit *edtUpFile;
        TButton *btnUpSelect;
        TButton *btnUpload;
        TGroupBox *GroupBox8;
        TLabel *Label6;
        TLabel *Label7;
        TLabel *Label8;
        TEdit *edtStartAddress;
        TEdit *edtLength;
        TCheckBox *cbLengthKB;
        TButton *btnTemplateSet;
        TCheckBox *cbExecFlag;
        TComboBox *cbTemplate;
        TLabel *Label3;
        TTabSheet *tsDebugger;
        TMemo *mDbgText;
        TGroupBox *GroupBox3;
        TButton *btnOpen;
        TLabel *Label5;
        TTabSheet *tsMemView;
        TLabel *Label1;
        TButton *btnParamSet;
        TLabel *Label2;
        TButton *btnIniOpen;
        TProgressBar *pbTransfer;
        TCheckBox *cbDbgUse;
        TTimer *tmStatusBarRefresh;
        TLabel *Label4;
        TLabel *Label11;
        TEdit *edtMemViewAddress;
        TButton *btnMemView;
        TCheckBox *cbMemViewAuto;
        TButton *btnAdrDown;
        TButton *btnAdrUp;
        TComboBox *cbParamText;
        TComboBox *cbParamValue;
        TButton *btnLogClear;
        TButton *btnFastExec2;
        TButton *btnClose;
        TStringGrid *sgDbgText;
        TEdit *edtDbgPrompt;
        TLabel *Label18;
        TButton *btnPromptSend;
        TGroupBox *GroupBox2;
        TLabel *Label14;
        TEdit *edtDbgFile;
        TEdit *edtDbgStartAddress;
        TButton *btnFastExec;
        TButton *btnSetDbgFolder;
        TEdit *edtDbgFolder;
        TLabel *Label16;
        TLabel *Label12;
        TLabel *Label15;
        TGroupBox *GroupBox4;
        TTimer *tmMemviewRefresh;
        TButton *btnTest2;
        TButton *btnTest3;
        TGroupBox *GroupBox10;
        TLabel *Label22;
        TComboBox *cbLogType;
        TLabel *Label23;
        TComboBox *cbLogOutput;
        TButton *btnLogLevelSet;
        TComboBox *cbLogLevel;
        TLabel *Label24;
        TEdit *edtLogPath;
        TLabel *Label19;
        TEdit *edtLogSettings;
        TButton *btnLogLdSettings;
        TLabel *Label17;
        TEdit *edtDebugSleep;
        TButton *btnLogSave;
        TTabSheet *tsDataLinkDBG;
        TButton *btnTest1;
        TTabSheet *tsExtra1;
        TGroupBox *GroupBox5;
        TButton *btnTargetInfo;
        TGroupBox *GroupBox11;
        TButton *btnVDP1View;
        TPanel *pnVDP1;
        TImage *imgVDP1;
        TCheckBox *cbSilentDbg;
        TButton *btnLogSilent;
        TButton *btnLogOn;
        TGroupBox *gbLogLevels;
        TButton *btnLogLevelsGet;
        TMemo *mLogLevels;
        TMainMenu *MainMenu1;
        TMenuItem *mniDevice;
        TMenuItem *mniSend;
        TMenuItem *mniReceive;
        TMenuItem *mniReceiveBackupMemory;
        TMenuItem *mniReceiveBIOS;
        TMenuItem *mniReceiveARPFirmWare;
        TMenuItem *mniSendBackupMemory;
        TLabel *lblDbgInfos1;
        TLabel *lblDbgInfos2;
        TLabel *lblDbgInfos3;
        TMenuItem *mniSetUSBDataLinkParameters;
        TMenuItem *mniOpenUSBDataLink;
        TMenuItem *mniExecProgram;
        TCheckBox *cbDbgEnable;
        TGroupBox *GroupBox12;
        TButton *btnUDLGo;
        TLabel *Label20;
        TEdit *edtUDLPort;
        TEdit *edtUDLColor;
        TLabel *Label25;
        TLabel *Label26;
        TEdit *edtUDLAddress;
        TEdit *edtUDLLen;
        TLabel *Label27;
        TLabel *Label28;
        TEdit *edtUDLCount;
        TGroupBox *GroupBox13;
        TEdit *edtParWriteVal;
        TLabel *Label29;
        TLabel *Label30;
        TEdit *edtParReadVal;
        TLabel *Label31;
        TLabel *Label32;
        TButton *btnParExchange;
        TButton *btnParOpen;
        TButton *btnParClose;
        TComboBox *cbParOffset;
        TButton *btnParRead;
        TButton *btnParWrite;
        TCheckBox *cbParExcInc;
        TButton *btnParMacro;
        TEdit *edtParExchangeLoop;
        TButton *btnParExchangeLoop;
        TLabel *Label34;
        TLabel *lblDebugFolder;
        TTabSheet *tsRegisters;
        TLabel *Label35;
        TEdit *edtRegisterLength;
        TLabel *Label37;
        TButton *btnRegisterWrite;
        TMemo *mRegisterLog;
        TEdit *edtRegistersMacro;
        TLabel *Label38;
        TButton *btnRegisterExec;
        TComboBox *cbRegistersAddress;
        TButton *btnRegisterRead;
        TLabel *Label36;
        TEdit *edtRegisterValue;
        TButton *btnRegLogClear;
        TCheckBox *cbDbgLogDate;
        TTabSheet *tsDebuggerSub2;
        TTabSheet *tsDebuggerSub1;
        TGroupBox *GroupBox16;
        TStringGrid *sgYabLinkMonitor;
        TGroupBox *GroupBox17;
        TLabel *Label21;
        TEdit *edtYabUpdtCntrs;
        TLabel *Label39;
        TEdit *edtYabLastFile;
        TGroupBox *GroupBox18;
        TButton *btnMemViewVDP2CRAM;
        TButton *btnMemViewDbgData;
        TTimer *tmVparRefresh;
        TButton *btnMemViewGlobalData;
        TGroupBox *GroupBox19;
        TButton *btnMainLogSave;
        TButton *btnMainLogClear;
        TEdit *edtMainLogPath;
        TLabel *Label13;
        TPageControl *PageControl1;
        TTabSheet *tsMemViewBinary;
        TTabSheet *tsMemViewDisasm;
        TGroupBox *GroupBox14;
        TStringGrid *sgMemConvert;
        TGroupBox *GroupBox9;
        TComboBox *cbMemoryConvert;
        TComboBox *cbMemSize;
        TGroupBox *GroupBox20;
        TStringGrid *sgSh2Dis;
        TButton *btnAdrPrev2;
        TButton *btnAdrNext2;
        TGroupBox *GroupBox21;
        TLabel *Label41;
        TEdit *edtMemFindVal;
        TLabel *Label43;
        TEdit *edtMemFindRange;
        TButton *btnMemFind;
        TTabSheet *tsMemViewIAsm;
        TMenuItem *mniOpenCurrentDevice;
        TGroupBox *GroupBox22;
        TCheckBox *cbDisasmMem;
        TGroupBox *GroupBox23;
        TLabel *Label44;
        TEdit *edtIasmText;
        TButton *btnIasmExec;
        TButton *btnAsmExec;
        TEdit *edtIasmOpCode;
        TLabel *Label45;
        TTabSheet *tsMemViewRGB;
        TPanel *pnMemViewRGB;
        TImage *imgMemViewRGB;
        TButton *btnMemViewRGB;
        TLabel *Label46;
        TLabel *Label47;
        TEdit *edtMemViewRGBw;
        TEdit *edtMemViewRGBh;
        TLabel *Label48;
        TPageControl *pcYabause;
        TTabSheet *tsYabVdp;
        TCheckBox *cbYabVdp2Log;
        TCheckBox *cbYabAllDisp;
        TCheckBox *cbYabDiffDisp;
        TCheckBox *cbYabSaveRef;
        TCheckBox *cbYabDump;
        TCheckBox *cbYabVdp1Log;
        TCheckBox *cbYabVdp1Reg;
        TCheckBox *cbYabVdp1Cmd;
        TCheckBox *cbYabVdp1Dmp;
        TTabSheet *tsYabCommon;
        TLabel *Label42;
        TLabel *Label40;
        TEdit *edtYabPollInterval;
        TEdit *edtYabLogPath;
        TTabSheet *tsYabExtra;
        TCheckBox *cbYabLinkEmu;
        TCheckBox *cbCrappyDbg;
        TTabSheet *tsYabDbg;
        TCheckBox *cbYabDbgView;
        TCheckBox *cbYabDbg0;
        TCheckBox *cbYabDbg1;
        TCheckBox *cbYabLinkEmuLog;
        TEdit *edtParPortAddress;
        TLabel *Label33;
        TGroupBox *GroupBox15;
        TLabel *Label49;
        TEdit *edtYabPC;
        TLabel *Label50;
        TEdit *edtYabRWAddr;
        TLabel *Label51;
        TEdit *edtYabMoniInterval;
        TLabel *Label52;
        TComboBox *cbIniPath;
        TCheckBox *cdFDisasm;
        TEdit *edtFDisasmPath;
        TEdit *edtFDisasmOffset;
        TLabel *Label53;
        TLabel *Label54;
        TLabel *Label55;
        TEdit *edtFDisasmAddress;
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall btnClick(TObject *Sender);
        void __fastcall btnDownSelectClick(TObject *Sender);
        void __fastcall btnUpSelectClick(TObject *Sender);
        void __fastcall btnIniOpenClick(TObject *Sender);
        void __fastcall btnTemplateSetClick(TObject *Sender);
        void __fastcall tmStatusBarRefreshTimer(TObject *Sender);
        void __fastcall edtDbgPromptKeyPress(TObject *Sender, char &Key);
        void __fastcall sgMemorySelectCell(TObject *Sender, int ACol,
          int ARow, bool &CanSelect);
        void __fastcall cbMemoryConvertChange(TObject *Sender);
        void __fastcall tmMemviewRefreshTimer(TObject *Sender);
        void __fastcall btnTest2Click(TObject *Sender);
        void __fastcall btnTest3Click(TObject *Sender);
        void __fastcall btnUDLGoClick(TObject *Sender);
        void __fastcall sgMemConvertDrawCell(TObject *Sender, int ACol,
          int ARow, TRect &Rect, TGridDrawState State);
        void __fastcall btnMemViewVDP2CRAMClick(TObject *Sender);
        void __fastcall btnLogLevelsGetClick(TObject *Sender);
        void __fastcall mniClick(TObject *Sender);
        void __fastcall mniSetUSBDataLinkParametersClick(TObject *Sender);
        void __fastcall btnParExchangeClick(TObject *Sender);
        void __fastcall btnParOpenClick(TObject *Sender);
        void __fastcall btnParCloseClick(TObject *Sender);
        void __fastcall btnParWriteClick(TObject *Sender);
        void __fastcall btnParReadClick(TObject *Sender);
        void __fastcall btnParMacroClick(TObject *Sender);
        void __fastcall btnParExchangeLoopClick(TObject *Sender);
        void __fastcall cbRegistersAddressChange(TObject *Sender);
        void __fastcall btnMemViewDbgDataClick(TObject *Sender);
        void __fastcall tmVparRefreshTimer(TObject *Sender);
        void __fastcall btnMemViewGlobalDataClick(TObject *Sender);
        void __fastcall sgMemConvertSetEditText(TObject *Sender, int ACol,
          int ARow, const AnsiString Value);
        void __fastcall sgMemConvertKeyPress(TObject *Sender, char &Key);
        void __fastcall edtMemViewAddressKeyPress(TObject *Sender,
          char &Key);
        void __fastcall sgSh2DisDrawCell(TObject *Sender, int ACol,
          int ARow, TRect &Rect, TGridDrawState State);
        void __fastcall edtMemFindValKeyPress(TObject *Sender, char &Key);
        void __fastcall mniOpenCurrentDeviceClick(TObject *Sender);
        void __fastcall btnIasmExecClick(TObject *Sender);
        void __fastcall edtIasmTextKeyPress(TObject *Sender, char &Key);
        void __fastcall btnAsmExecClick(TObject *Sender);
        void __fastcall edtIasmOpCodeKeyPress(TObject *Sender, char &Key);
private:	// User declarations
        unsigned long ulCloseCount;
        void __fastcall ProcessThreadEnd(TObject *Sender);
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);

        /*--- Command line related ---*/
        char cl_buffer[8192];
        char inifilebuffer[INIFILE_MAXSIZE];
        int argc;
        char* argv[MAXARGS];

        ProcessThread *thProcessThread;

        /*--- VPar DLL related ---*/
        int iVparFirstSet;
        vpar_shared_memory_t vpar_sm;



        /*--- Logging related. ---*/
        void /*__fastcall*/ LogOut(const char *string, ...);
        /*--- Settings related. ---*/
        AnsiString __fastcall MakeSettingsFilePath(void);
        void __fastcall LoadSettingsFile(void);
        void __fastcall SaveSettingsFile(void);
        /*--- GUI related. ---*/
        char app_path[MAX_PATH];
        char app_name[MAX_PATH];
        UserData udGUI;
        int iDebugUse;
        int iVDP1ScreenID;
        void __fastcall InitFormItems(void);
        void __fastcall SaveFormItems(void);
        void __fastcall SaveToUserData(void);
        void __fastcall LoadFromUserData(void);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif

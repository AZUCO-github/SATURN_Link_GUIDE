/* 
 * This software is licensed under terms of the GNU GENERAL PUBLIC LICENSE
 *
 * This software is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This software  is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this software.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Source code is available at http://ppcenter.free.fr
 */


#ifndef _INCLUDE_MISC_H_
#define _INCLUDE_MISC_H_

#ifdef  __cplusplus
extern "C" {
#endif

#include <stdio.h>


/**
 * This module contains various common functions for usbdl/parlink devices.
**/




/**
 * Convert an unsigned char to a displayable char.
**/
unsigned char char2pchar(unsigned char c);


/**
 * Used for measuring execution timings.
**/
void exec_time_reset(void);
unsigned long exec_time_get(void);



/* send/receive flag used in the callback. */
// Will start to send/receive data soon.
#define CLBK_START   0
// Sending/receiving data
#define CLBK_SEND    1
#define CLBK_RECEIVE 2
// Data transfer has ended.
#define CLBK_END     3

/* Callback used when sending/receiving data.      */
/* char sc_callback(char status, unsigned long adr, unsigned char* buffer, unsigned long buffpos, unsigned long bufflen, unsigned long exec_time); */
typedef char (*Fct_sc_callback)(char, unsigned long, unsigned char*, unsigned long, unsigned long, unsigned long);
#define STATUS_CALLBACK(status, adr, buffer, buffpos, bufflen) {if(status==CLBK_START){exec_time_reset();} if(_callback) { if(_callback(status, adr, buffer, buffpos, bufflen, exec_time_get()) != SC_NOERROR) return SC_ERROR_ABORTED;};}


/* Stuff used in order to indicate download/upload status. */
extern Fct_sc_callback _callback;
char sc_set_callback(Fct_sc_callback callback);



/**
 * Bitmap-related functions.
**/
#define RGB555_TO_R(rgb) ((((rgb)>> 0) & 0x1F) << 3)
#define RGB555_TO_G(rgb) ((((rgb)>> 5) & 0x1F) << 3)
#define RGB555_TO_B(rgb) ((((rgb)>>10) & 0x1F) << 3)

//#define RGB24(r,g,b) ( ((r)<<16)|((g)<<8)|(b) ) //RGB24
#define RGB24(r,g,b) ( ((r)<<16)|((g)<<8)|(b) ) //RGB24

void save_raw_to_png(unsigned long* outbuffer, unsigned long w, unsigned long h, char* outfile, char* comment);



#ifdef  __cplusplus
}
#endif


#endif // _INCLUDE_MISC_H_

//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "UserData.h"


//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
        , thProcessThread(NULL)
        , ulCloseCount(0)
        , iDebugUse(0)
        , iVparFirstSet(1)
{
    /* Get path where the program is. */
    char szPath[MAX_PATH];
    GetModuleFileName(GetModuleHandle(NULL), szPath, MAX_PATH);
    AnsiString sAppPath;
    sAppPath.printf("%s", szPath);
    int iLast = sAppPath.LastDelimiter("\\");
    sAppPath = sAppPath.SubString(1, iLast);
    strcpy(app_path, sAppPath.c_str());
    AnsiString sAppName;
    sAppName.printf("%s", szPath);
    sAppName = sAppName.SubString(iLast+1, MAX_PATH-iLast);
    strcpy(app_name, sAppName.c_str());


    /* Reset buttons state. */
    memset((void*)(&udGUI), 0, sizeof(UserData));
    /* Request debug folder init. */
    udGUI.btn[BTN_DBGFOLDER] = 1;
}
//---------------------------------------------------------------------------
//http://gnuwin32.sourceforge.net/version.c.txt
BOOL GetAppVersion( char *LibName, WORD *MajorVersion, WORD *MinorVersion, WORD *BuildNumber, WORD *RevisionNumber )
{
 DWORD dwHandle, dwLen;
 UINT BufLen;
 LPTSTR lpData;
 VS_FIXEDFILEINFO *pFileInfo;
 dwLen = GetFileVersionInfoSize( LibName, &dwHandle );
 if (!dwLen)
  return FALSE;

 lpData = (LPTSTR) malloc (dwLen);
 if (!lpData)
  return FALSE;

 if( !GetFileVersionInfo( LibName, dwHandle, dwLen, lpData ) )
 {
  free (lpData);
  return FALSE;
 }
 if( VerQueryValue( lpData, "\\", (LPVOID *) &pFileInfo, (PUINT)&BufLen ) )
 {
  *MajorVersion = HIWORD(pFileInfo->dwFileVersionMS);
  *MinorVersion = LOWORD(pFileInfo->dwFileVersionMS);
  *BuildNumber = HIWORD(pFileInfo->dwFileVersionLS);
  *RevisionNumber = LOWORD(pFileInfo->dwFileVersionLS);
  free (lpData);
  return TRUE;
 }
 free (lpData);
 return FALSE;
}
//---------------------------------------------------------------------------
scl_settings_t _log_global_settings;
void __fastcall TForm1::FormCreate(TObject *Sender)
{
    WORD ver[4];
    GetAppVersion(Application->ExeName.c_str(), ver+0, ver+1, ver+2, ver+3);
    AnsiString str;
    str.printf("SatCom debugger Ver.%d.%d.%d%d [Build %s, %s]", ver[0], ver[1], ver[2], ver[3], __DATE__, __TIME__);
    Form1->Caption = str;

    /* Init log engine. */
    scl_init(&_log_global_settings, 1/*satlink_init*/);

    /* Init form items. */
    InitFormItems();

    /* Parse command line. */
    memset((void*)cl_buffer, 0, sizeof(cl_buffer));
    argc=0;
    for(int i=0; i<MAXARGS; i++) argv[i] = NULL;

    int cl_buffer_pos = 0;
    for(int i=0; i<=ParamCount(); i++)
    {
        if(i==1)
        {
            /* Append parameters from ini file. */
            parse_satlink_inifile(inifilebuffer, ParamStr(i).c_str()/*filename*/, &argc, argv);
        }
        else
        {
            /* Append parameters from command line. */
            AnsiString str = ParamStr(i);
            int strl = str.Length();
            argv[argc] = cl_buffer + cl_buffer_pos; argc++;
            for(int i=0; i<strl; i++)
            {
                cl_buffer[cl_buffer_pos] = str[i+1]; cl_buffer_pos++;
            }
            cl_buffer[cl_buffer_pos] = '\0'; cl_buffer_pos++;
        }
    }

    /* Log grid init. */
    sgDbgText->RowCount = 256;
    sgDbgText->ColCount = 2;
    sgDbgText->Cells[0][0] = "ID";
    for(int i=1; i<sgDbgText->RowCount; i++) sgDbgText->Cells[0][i] = IntToStr(i);
    sgDbgText->ColWidths[0] = 30;
    sgDbgText->Cells[1][0] = "Message";
    sgDbgText->ColWidths[1] = 245;

    /* Register Write stuff. */
    int i=0;
    cbRegistersAddress->Items->Clear();
    while(regs_list[i].siz != 0)
    {
        cbRegistersAddress->Items->Add(regs_list[i].nam);
        i++;
    }


    /* Start Send/Receive/Debuger thread. */
    thProcessThread = new ProcessThread(false);
    thProcessThread->OnTerminate = ProcessThreadEnd;
    strcpy(thProcessThread->app_path, app_path);

    /* Start status bar refresh timer. */
    tmStatusBarRefresh->Enabled = true;
    /* Start memview convert refresh timer. */
    tmMemviewRefresh->Enabled = true;
    /* Start VPar set/refresh timer. */
    tmVparRefresh->Enabled = true;

    //EnableWindow(Handle, false);
}
//---------------------------------------------------------------------------
void __fastcall  TForm1::ProcessThreadEnd(TObject *Sender)
{
    //EnableWindow(Handle, true);

    delete thProcessThread;
    thProcessThread = NULL;

    //this->DoDestroy();
    DoClose(caFree);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormClose(TObject *Sender, TCloseAction &Action)
{
    SaveFormItems();

    if(thProcessThread)
    {
        /* End logging engine. */
        scl_end();

        Form1->mLog->Lines->Add("Waiting for thread to close ...");
        ulCloseCount++;
        /* If it is the first time exit button is clicked,
         * give some time for the thread to exit.
         */
        if(ulCloseCount < 2) Action = caNone;
        thProcessThread->Terminate();
        thProcessThread->iTerminateRequest = 1;

        /* Stop timers. */
        tmStatusBarRefresh->Enabled = false;
        tmMemviewRefresh->Enabled = false;
    }
    else
    {
        /* End logging engine. */
        scl_end();

        Form1->mLog->Lines->Add("Thread ended. You can exit the application.");
        Action = caFree;
        exit(0);
    }
}


//---------------------------------------------------------------------------
void /*__fastcall*/ TForm1::LogOut(const char *string, ...)
{
    /* Format to memory */
    char str[8192];
    va_list argptr;
    va_start(argptr, string);
    vsnprintf(str, sizeof(str), string, argptr);
    va_end(argptr);

    /* Add date */
    char strout[8192];
    if(strlen(str) != 0)
    {
        SYSTEMTIME sTime;
        GetLocalTime(&sTime);
        snprintf(strout, sizeof(strout), "[%02d:%02d:%02d:%03d]%s",
                    sTime.wHour, sTime.wMinute, sTime.wSecond, sTime.wMilliseconds,
                    str);
    }
    else
    {
        snprintf(strout, sizeof(strout), "");
    }

    mLog->Lines->Add(strout);
}
//---------------------------------------------------------------------------


/* Settings file related stuff. */
#define SET_FILE "satlink.ini"
#define SET_SECTION "satlink"
#define SET_STRSZ 8192
#define SET_MAXITEMS 256
//---------------------------------------------------------------------------
typedef struct
{
    TEdit* obj;
    char*  ent;
    char*  def;
} setting_edit_t;
setting_edit_t _setting_edit[SET_MAXITEMS];
typedef struct
{
    TCheckBox* obj;
    char*      ent;
    int        def;
} setting_checkbox_t;
setting_checkbox_t _setting_checkbox[SET_MAXITEMS];
typedef struct
{
    TComboBox* obj;
    char*      ent;
    int        typ; //0: save index, 1:save string
    int        def0;
    char*      def1;
} setting_combobox_t;
setting_combobox_t _setting_combobox[SET_MAXITEMS];

AnsiString __fastcall TForm1::MakeSettingsFilePath(void)
{
    /* Must init items list after the form constructor has been called. */
    int i;
    /* Set edit stuff. */
    i = 0;
    _setting_edit[i].obj = edtStartAddress    ; _setting_edit[i].ent = "param_start_address"; _setting_edit[i].def = "06004000"            ; i++;
    _setting_edit[i].obj = edtLength          ; _setting_edit[i].ent = "param_len"          ; _setting_edit[i].def = "442364"              ; i++;
    _setting_edit[i].obj = edtDownFile        ; _setting_edit[i].ent = "dst_file"           ; _setting_edit[i].def = "receivefile.bin"     ; i++;
    _setting_edit[i].obj = edtUpFile          ; _setting_edit[i].ent = "src_file"           ; _setting_edit[i].def = "sendfile.bin"        ; i++;
    _setting_edit[i].obj = edtDbgFile         ; _setting_edit[i].ent = "dbg_binary"         ; _setting_edit[i].def = "myproject\\cd\\0.bin"; i++;
    _setting_edit[i].obj = edtDbgStartAddress ; _setting_edit[i].ent = "dbg_address"        ; _setting_edit[i].def = "06004000"            ; i++;
    _setting_edit[i].obj = edtDbgFolder       ; _setting_edit[i].ent = "dbg_folder"         ; _setting_edit[i].def = ""                    ; i++;
    _setting_edit[i].obj = edtMainLogPath     ; _setting_edit[i].ent = "main_dbg_log"       ; _setting_edit[i].def = "satlink_main.log"    ; i++;
    _setting_edit[i].obj = edtLogPath         ; _setting_edit[i].ent = "dbg_log"            ; _setting_edit[i].def = "satlink_dbg.log"     ; i++;
    _setting_edit[i].obj = edtLogSettings     ; _setting_edit[i].ent = "dbg_settings"       ; _setting_edit[i].def = "log_settings.ini"    ; i++;
    _setting_edit[i].obj = edtDebugSleep      ; _setting_edit[i].ent = "dbg_interval"       ; _setting_edit[i].def = "100"                 ; i++;
    _setting_edit[i].obj = edtMemViewAddress  ; _setting_edit[i].ent = "memview_adr"        ; _setting_edit[i].def = "06004000"            ; i++;
    _setting_edit[i].obj = edtMemFindVal      ; _setting_edit[i].ent = "memfind_val"        ; _setting_edit[i].def = "0x4253"              ; i++;
    _setting_edit[i].obj = edtMemFindRange    ; _setting_edit[i].ent = "memfind_range"      ; _setting_edit[i].def = "1"                   ; i++;
    _setting_edit[i].obj = edtDbgPrompt       ; _setting_edit[i].ent = "dbg_prompt"         ; _setting_edit[i].def = "hello!"              ; i++;
    _setting_edit[i].obj = edtRegisterLength  ; _setting_edit[i].ent = "reg_length"         ; _setting_edit[i].def = "4"                   ; i++;
    _setting_edit[i].obj = edtRegisterValue   ; _setting_edit[i].ent = "reg_value"          ; _setting_edit[i].def = "0x8000"              ; i++;
    _setting_edit[i].obj = edtRegistersMacro  ; _setting_edit[i].ent = "reg_macro"          ; _setting_edit[i].def = "regs_macro.txt"      ; i++;
    _setting_edit[i].obj = edtYabLogPath      ; _setting_edit[i].ent = "yab_logpath"        ; _setting_edit[i].def = "D:\\log"             ; i++;
    _setting_edit[i].obj = edtYabPollInterval ; _setting_edit[i].ent = "yab_poll_interval"  ; _setting_edit[i].def = "100"                 ; i++;
    _setting_edit[i].obj = edtYabMoniInterval ; _setting_edit[i].ent = "yab_moni_interval"  ; _setting_edit[i].def = "0"                   ; i++;
    _setting_edit[i].obj = edtIasmText        ; _setting_edit[i].ent = "iasm_text"          ; _setting_edit[i].def = "nop"                 ; i++;
    _setting_edit[i].obj = edtIasmOpCode      ; _setting_edit[i].ent = "iasm_opcode"        ; _setting_edit[i].def = "0x0009 (9)"          ; i++;
    _setting_edit[i].obj = edtMemViewRGBw     ; _setting_edit[i].ent = "memrgb_width"       ; _setting_edit[i].def = "80"                  ; i++;
    _setting_edit[i].obj = edtMemViewRGBh     ; _setting_edit[i].ent = "memrgb_height"      ; _setting_edit[i].def = "80"                  ; i++;
    _setting_edit[i].obj = edtFDisasmPath     ; _setting_edit[i].ent = "fdis_path"          ; _setting_edit[i].def = "file.bin"            ; i++;
    _setting_edit[i].obj = edtFDisasmOffset   ; _setting_edit[i].ent = "fdis_offset"        ; _setting_edit[i].def = "0"                   ; i++;
    _setting_edit[i].obj = edtFDisasmAddress  ; _setting_edit[i].ent = "fdis_address"       ; _setting_edit[i].def = "0x06004000"          ; i++;
    _setting_edit[i].obj = NULL               ; _setting_edit[i].ent = NULL                 ; _setting_edit[i].def = NULL                  ; //i++;
    /* Set checkbox stuff. */
    i = 0;
    _setting_checkbox[i].obj = cbSilentDbg     ; _setting_checkbox[i].ent = "silent_dbg"        ; _setting_checkbox[i].def = 1; i++;
    _setting_checkbox[i].obj = cbDbgLogDate    ; _setting_checkbox[i].ent = "dbglog_date"       ; _setting_checkbox[i].def = 1; i++;
    _setting_checkbox[i].obj = cbLengthKB      ; _setting_checkbox[i].ent = "kb_len"            ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbExecFlag      ; _setting_checkbox[i].ent = "exec_flag"         ; _setting_checkbox[i].def = 1; i++;
    _setting_checkbox[i].obj = cbDbgEnable     ; _setting_checkbox[i].ent = "dbg_enable"        ; _setting_checkbox[i].def = 1; i++;
    _setting_checkbox[i].obj = cbYabVdp2Log    ; _setting_checkbox[i].ent = "yab_vdp2log"       ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabAllDisp    ; _setting_checkbox[i].ent = "yab_alldisp"       ; _setting_checkbox[i].def = 1; i++;
    _setting_checkbox[i].obj = cbYabDiffDisp   ; _setting_checkbox[i].ent = "yab_diffdisp"      ; _setting_checkbox[i].def = 1; i++;
    _setting_checkbox[i].obj = cbYabSaveRef    ; _setting_checkbox[i].ent = "yab_saveref"       ; _setting_checkbox[i].def = 1; i++;
    _setting_checkbox[i].obj = cbYabVdp1Log    ; _setting_checkbox[i].ent = "yab_vdp1log"       ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabVdp1Reg    ; _setting_checkbox[i].ent = "yab_vdp1_reglog"   ; _setting_checkbox[i].def = 1; i++;
    _setting_checkbox[i].obj = cbYabVdp1Cmd    ; _setting_checkbox[i].ent = "yab_vdp1_cmdlog"   ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabVdp1Dmp    ; _setting_checkbox[i].ent = "yab_vdp1_regsdump" ; _setting_checkbox[i].def = 1; i++;
    _setting_checkbox[i].obj = cbYabDbgView    ; _setting_checkbox[i].ent = "yab_dbgview"       ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabDbg0       ; _setting_checkbox[i].ent = "yab_dbg0"          ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabDbg1       ; _setting_checkbox[i].ent = "yab_dbg1"          ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbCrappyDbg     ; _setting_checkbox[i].ent = "yab_crappydbg"     ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabLinkEmu    ; _setting_checkbox[i].ent = "yab_linkemu"       ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbYabLinkEmuLog ; _setting_checkbox[i].ent = "yab_linkemu_log"   ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = cbDisasmMem     ; _setting_checkbox[i].ent = "disasm_mem"        ; _setting_checkbox[i].def = 1; i++;
    _setting_checkbox[i].obj = cdFDisasm       ; _setting_checkbox[i].ent = "fdis_use"          ; _setting_checkbox[i].def = 0; i++;
    _setting_checkbox[i].obj = NULL            ; _setting_checkbox[i].ent = NULL                ; _setting_checkbox[i].def = 0; //i++;

    /* Set combo box stuff. */
    i = 0;
    _setting_combobox[i].obj = cbIniPath          ; _setting_combobox[i].ent = "ini_file"     ; _setting_combobox[i].typ = 1; _setting_combobox[i].def0 =-1;  _setting_combobox[i].def1 = "usb_dev_cart.ini" ; i++;
    _setting_combobox[i].obj = cbLogType          ; _setting_combobox[i].ent = "log_type"     ; _setting_combobox[i].typ = 0; _setting_combobox[i].def0 = 0;  _setting_combobox[i].def1 = NULL               ; i++;
    _setting_combobox[i].obj = cbLogOutput        ; _setting_combobox[i].ent = "log_output"   ; _setting_combobox[i].typ = 0; _setting_combobox[i].def0 = 1;  _setting_combobox[i].def1 = NULL               ; i++;
    _setting_combobox[i].obj = cbLogLevel         ; _setting_combobox[i].ent = "log_level"    ; _setting_combobox[i].typ = 0; _setting_combobox[i].def0 =10;  _setting_combobox[i].def1 = NULL               ; i++;
    _setting_combobox[i].obj = cbParamText        ; _setting_combobox[i].ent = "param_text"   ; _setting_combobox[i].typ = 1; _setting_combobox[i].def0 =-1;  _setting_combobox[i].def1 = "port"             ; i++;
    _setting_combobox[i].obj = cbParamValue       ; _setting_combobox[i].ent = "param_value"  ; _setting_combobox[i].typ = 1; _setting_combobox[i].def0 =-1;  _setting_combobox[i].def1 = "COM3"             ; i++;
    _setting_combobox[i].obj = cbTemplate         ; _setting_combobox[i].ent = "adr_tmplt"    ; _setting_combobox[i].typ = 0; _setting_combobox[i].def0 = 0;  _setting_combobox[i].def1 = NULL               ; i++;
    _setting_combobox[i].obj = cbMemSize          ; _setting_combobox[i].ent = "memview_size" ; _setting_combobox[i].typ = 0; _setting_combobox[i].def0 = 0;  _setting_combobox[i].def1 = NULL               ; i++;
    _setting_combobox[i].obj = cbMemoryConvert    ; _setting_combobox[i].ent = "memview_disp" ; _setting_combobox[i].typ = 0; _setting_combobox[i].def0 = 0;  _setting_combobox[i].def1 = NULL               ; i++;
    _setting_combobox[i].obj = cbRegistersAddress ; _setting_combobox[i].ent = "reg_adress"   ; _setting_combobox[i].typ = 1; _setting_combobox[i].def0 =-1;  _setting_combobox[i].def1 = "TVMD"             ; i++;
    _setting_combobox[i].obj = NULL               ; _setting_combobox[i].ent = NULL           ; _setting_combobox[i].typ = 0; _setting_combobox[i].def0 = 0;  _setting_combobox[i].def1 = NULL               ; //i++;



    /* Set settings file path. */
    AnsiString sIniPath = app_path;
    sIniPath += SET_FILE;

    return sIniPath;
}


//---------------------------------------------------------------------------
void __fastcall TForm1::LoadSettingsFile(void)
{
    AnsiString sIniPath = MakeSettingsFilePath();
    char sData[SET_STRSZ];

    int i;
    int iValue;
    /* Edit. */
    i=0; while(_setting_edit[i].obj != NULL)
    {
        GetPrivateProfileString(SET_SECTION, _setting_edit[i].ent, _setting_edit[i].def, sData, SET_STRSZ, sIniPath.c_str());
        _setting_edit[i].obj->Text = sData;
        i++;
    }
    /* Check box. */
    i=0; while(_setting_checkbox[i].obj != NULL)
    {
        iValue = (int)GetPrivateProfileInt(SET_SECTION, _setting_checkbox[i].ent, _setting_checkbox[i].def, sIniPath.c_str());
        _setting_checkbox[i].obj->Checked = (iValue ? true : false);
        i++;
    }
    /* Combo box. */
    i=0; while(_setting_combobox[i].obj != NULL)
    {
        if(_setting_combobox[i].typ == 0)
        { /* Use combo box index. */
            iValue = (int)GetPrivateProfileInt(SET_SECTION, _setting_combobox[i].ent, _setting_combobox[i].def0, sIniPath.c_str());
            _setting_combobox[i].obj->ItemIndex = (iValue == -1 ? 0 : iValue);
        }
        else
        { /* Use combo box text. */
            GetPrivateProfileString(SET_SECTION, _setting_combobox[i].ent, _setting_combobox[i].def1, sData, SET_STRSZ, sIniPath.c_str());
            _setting_combobox[i].obj->Text = sData;
        }
        i++;
    }

    /* Window position. */
    Form1->Top  = (int)GetPrivateProfileInt(SET_SECTION, "window_top" , 0, sIniPath.c_str());
    Form1->Left = (int)GetPrivateProfileInt(SET_SECTION, "window_left", 0, sIniPath.c_str());

    /* VDP1 View Screen save ID. */
    iVDP1ScreenID = (int)GetPrivateProfileInt(SET_SECTION, "vdp1screen_id", 0, sIniPath.c_str());

    /* Extra : debug mode check. */
    iValue = (int)GetPrivateProfileInt(SET_SECTION, "debug", 0, sIniPath.c_str());
    iDebugUse = iValue;
    btnTest1->Visible = (iValue ? true : false);
    btnTest2->Visible = (iValue ? true : false);
    btnTest3->Visible = (iValue ? true : false);
    if(iValue == 0)
    { /* In not debug mode, hide the "Data Link test" page and "Log levels" group. */
        psSettings->Pages[5]->TabVisible = false;
        gbLogLevels->Visible = false;
    }
}

//---------------------------------------------------------------------------
void __fastcall TForm1::SaveSettingsFile(void)
{
    AnsiString sIniPath = MakeSettingsFilePath();

    int i;
    char str[128];
    /* Edit. */
    i=0; while(_setting_edit[i].obj != NULL)
    {
        WritePrivateProfileString(SET_SECTION, _setting_edit[i].ent, _setting_edit[i].obj->Text.c_str(), sIniPath.c_str());
        i++;
    }
    /* Check box. */
    unsigned long ulValue;
    i=0; while(_setting_checkbox[i].obj != NULL)
    {
        WritePrivateProfileString(SET_SECTION, _setting_checkbox[i].ent, (_setting_checkbox[i].obj->Checked ? "1" : "0"), sIniPath.c_str());
        i++;
    }
    /* Combo box. */
    i=0; while(_setting_combobox[i].obj != NULL)
    {
        if(_setting_combobox[i].typ == 0)
        { /* Use combo box index. */
            sprintf(str, "%d", _setting_combobox[i].obj->ItemIndex);
            WritePrivateProfileString(SET_SECTION, _setting_combobox[i].ent, str, sIniPath.c_str());
        }
        else
        { /* Use combo box text. */
            WritePrivateProfileString(SET_SECTION, _setting_combobox[i].ent, _setting_combobox[i].obj->Text.c_str(), sIniPath.c_str());
        }
        i++;
    }

    /* VDP1 View Screen save ID. */
    sprintf(str, "%d", iVDP1ScreenID); WritePrivateProfileString(SET_SECTION, "vdp1screen_id" , str, sIniPath.c_str());

    /* Window position. */
    sprintf(str, "%d", Form1->Top ); WritePrivateProfileString(SET_SECTION, "window_top" , str, sIniPath.c_str());
    sprintf(str, "%d", Form1->Left); WritePrivateProfileString(SET_SECTION, "window_left", str, sIniPath.c_str());
}


//---------------------------------------------------------------------------
/* Init, and load form contents from file. */
void __fastcall TForm1::InitFormItems(void)
{
    cbTemplate->ItemIndex = 0; btnTemplateSetClick(NULL);

    /* Menu bar stuff start. */
    mniSetUSBDataLinkParameters->Tag  = MNI_SETUDLPARAMS;
    mniOpenUSBDataLink->Tag           = MNI_OPENUDL;
    mniSendBackupMemory->Tag          = MNI_SENDBRAM;
    mniExecProgram->Tag               = MNI_EXECPROG;
    mniReceiveBackupMemory->Tag       = MNI_RCVBRAM;
    mniReceiveBIOS->Tag               = MNI_RCVBIOS;
    mniReceiveARPFirmWare->Tag        = MNI_RCVARPFW;
    /* Menu bar stuff end. */


    btnOpen->Tag          = BTN_OPEN;
    btnClose->Tag         = BTN_CLOSE;
    btnParamSet->Tag      = BTN_PARAMSET;
    btnUpload->Tag        = BTN_SEND;
    btnDownload->Tag      = BTN_RECEIVE;

    btnMainLogSave->Tag   = BTN_MAINLOGSAVE;
    btnMainLogClear->Tag  = BTN_MAINLOGCLEAR;
    btnLogLevelSet->Tag   = BTN_LOGLEVELSET;

    btnLogClear->Tag      = BTN_LOGCLEAR;
    btnLogLdSettings->Tag = BTN_LOGLDSETTINGS;
    btnLogSave->Tag       = BTN_LOGSAVE;

    btnFastExec->Tag      = BTN_FASTEXEC;
    btnFastExec2->Tag     = btnFastExec->Tag;

    btnPromptSend->Tag    = BTN_PROMPTSEND;
    btnSetDbgFolder->Tag  = BTN_DBGFOLDER; edtDbgFolder->Tag = BTN_DBGFOLDER;

    btnAdrDown->Tag       = BTN_ADDRDOWN;
    btnAdrUp->Tag         = BTN_ADDRUP;

    btnAdrPrev2->Tag      = BTN_ADDRPREV2;
    btnAdrNext2->Tag      = BTN_ADDRNEXT2;

    btnMemView->Tag       = BTN_MVREAD;
    //btnMemViewWrite->Tag  = BTN_MVWRITE;

    btnMemViewRGB->Tag    = BTN_MVRGB;
    btnMemFind->Tag       = BTN_MFIND;

    btnTargetInfo->Tag    = BTN_TARGETINFO;
    btnVDP1View->Tag      = BTN_VDP1VIEW;

    btnLogOn->Tag         = BTN_SILENTOFF;
    btnLogSilent->Tag     = BTN_SILENTON;

    btnRegisterRead->Tag  = BTN_REGREAD;
    btnRegisterWrite->Tag = BTN_REGWRITE;
    btnRegisterExec->Tag  = BTN_REGEXEC;
    btnRegLogClear->Tag   = BTN_REGLOGCLEAR;


    btnTest1->Tag         = BTN_TEST1;

    /* Load GUI settings. */
    LoadSettingsFile();

    /*cbMemSize->ItemIndex = 0; cbMemoryConvert->ItemIndex = 0; */cbMemoryConvertChange(NULL);
}
/* Save form contents to file. */
void __fastcall TForm1::SaveFormItems(void)
{
    /* save GUI settings. */
    SaveSettingsFile();
}

#define GUI_STRCPY(_DST_, _SRC_, _LEN_) strncpy((_DST_), (_SRC_), (_LEN_)-1); (_DST_)[(_LEN_) - 1] = '\0';

/* Save GUI contents to UserData (called by ProcessThread) */
void __fastcall TForm1::SaveToUserData(void)
{
    /* [READ-ONLY]CheckBox/RadioButtons states */
    udGUI.address      = strtoul(edtStartAddress->Text.c_str(), NULL, 16);
    udGUI.dbg_address  = strtoul(edtDbgStartAddress->Text.c_str(), NULL, 16);
    udGUI.length       = strtoul(edtLength->Text.c_str(), NULL, 10);
    udGUI.dbg_sleep    = strtoul(edtDebugSleep->Text.c_str(), NULL, 10);
    udGUI.length_is_KB = (cbLengthKB->Checked ? 1 : 0);
    udGUI.exec_flag    = (cbExecFlag->Checked ? 1 : 0);
    udGUI.dbg_use      = (cbDbgUse->Checked ? 1 : 0);
    udGUI.dbg_enable   = (cbDbgEnable->Checked ? 1 : 0);
    udGUI.silent_dbg   = (cbSilentDbg->Checked ? 1 : 0);
    udGUI.dbglog_date  = (cbDbgLogDate->Checked ? 1 : 0);
    udGUI.disasm_mem   = (cbDisasmMem->Checked ? 1 : 0);

    /* MemView stuff */
    udGUI.mv_address   = strtoul(edtMemViewAddress->Text.c_str(), NULL, 16);
    udGUI.mv_autoread  = (cbMemViewAuto->Checked ? 1 : 0);
    /* MemView stuff */
    udGUI.mf_data      = strtoul(edtMemFindVal->Text.c_str(), NULL, 0);
    udGUI.mf_range     = strtoul(edtMemFindRange->Text.c_str(), NULL, 0);

    /* File disassembler. */
    udGUI.fdis_use = (cdFDisasm->Checked ? 1 : 0);
    GUI_STRCPY(udGUI.fdis_path, edtFDisasmPath->Text.c_str(), STR_LEN);
    udGUI.fdis_offset = strtoul(edtFDisasmOffset->Text.c_str(), NULL, 0);
    udGUI.fdis_address = strtoul(edtFDisasmAddress->Text.c_str(), NULL, 0);

    /* MemView (RGB555) stuff */
    udGUI.mv_rgbw      = strtoul(edtMemViewRGBw->Text.c_str(), NULL, 10);
    udGUI.mv_rgbh      = strtoul(edtMemViewRGBh->Text.c_str(), NULL, 10);
    /* [READ-ONLY]Text fields */
    GUI_STRCPY(udGUI.main_log_file , edtMainLogPath->Text.c_str()     , STR_LEN);

    GUI_STRCPY(udGUI.log_file      , edtLogPath->Text.c_str()         , STR_LEN);
    GUI_STRCPY(udGUI.log_settings  , edtLogSettings->Text.c_str()     , STR_LEN);
    GUI_STRCPY(udGUI.log_settings  , edtLogSettings->Text.c_str()     , STR_LEN);

    GUI_STRCPY(udGUI.ini_file      , cbIniPath->Text.c_str()          , STR_LEN);

    GUI_STRCPY(udGUI.param_text    , cbParamText->Text.c_str()        , STR_LEN);
    GUI_STRCPY(udGUI.param_value   , cbParamValue->Text.c_str()       , STR_LEN);

    udGUI.log_type   = cbLogType->ItemIndex;
    udGUI.log_output = cbLogOutput->ItemIndex;
    udGUI.log_level  = cbLogLevel->ItemIndex;

    GUI_STRCPY(udGUI.up_file       , edtUpFile->Text.c_str()          , STR_LEN);
    GUI_STRCPY(udGUI.down_file     , edtDownFile->Text.c_str()        , STR_LEN);
    GUI_STRCPY(udGUI.dbg_file      , edtDbgFile->Text.c_str()         , STR_LEN);
    GUI_STRCPY(udGUI.dbg_folder    , edtDbgFolder->Text.c_str()       , STR_LEN);

    GUI_STRCPY(udGUI.prompt_answer , edtDbgPrompt->Text.c_str()       , STR_LEN);

    GUI_STRCPY(udGUI.reg_address   , cbRegistersAddress->Text.c_str() , STR_LEN);
    GUI_STRCPY(udGUI.reg_len       , edtRegisterLength->Text.c_str()  , STR_LEN);
    GUI_STRCPY(udGUI.reg_value     , edtRegisterValue->Text.c_str()   , STR_LEN);
    GUI_STRCPY(udGUI.reg_macro     , edtRegistersMacro->Text.c_str()  , STR_LEN);
}
/* Set UserData contents to GUI */
void __fastcall TForm1::LoadFromUserData(void)
{
}


//---------------------------------------------------------------------------
void __fastcall TForm1::btnClick(TObject *Sender)
{
    TButton* pButton = (TButton*)Sender;
    udGUI.btn[pButton->Tag] = 1;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::mniClick(TObject *Sender)
{
    TMenuItem* pMenuItem = (TMenuItem*)Sender;
    udGUI.btn[pMenuItem->Tag] = 1;
}

//---------------------------------------------------------------------------
void __fastcall TForm1::mniOpenCurrentDeviceClick(TObject *Sender)
{
    btnClick(btnOpen);
}

//---------------------------------------------------------------------------
void __fastcall TForm1::btnDownSelectClick(TObject *Sender)
{
    SetCurrentDirectory(app_path);
    sdFile->Filter = "Binary File (*.bin)|*.bin|Any File (*.*)|*.*";
    if(sdFile->Execute() == true)
    {
        AnsiString str = "Set download file to: ";
        str += sdFile->FileName;
        mLog->Lines->Add(str);
        edtDownFile->Text = sdFile->FileName;
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnUpSelectClick(TObject *Sender)
{
    SetCurrentDirectory(app_path);
    odFile->Filter = "Binary File (*.bin)|*.bin|Any File (*.*)|*.*";
    if(odFile->Execute() == true)
    {
        AnsiString str = "Set upload file to: ";
        str += odFile->FileName;
        mLog->Lines->Add(str);
        edtUpFile->Text = odFile->FileName;
    }
}
//---------------------------------------------------------------------------


void __fastcall TForm1::btnIniOpenClick(TObject *Sender)
{
    odFile->Filter = "Ini File (*.ini)|*.ini|Any File (*.*)|*.*";
    if(odFile->Execute() == true)
    {
        cbIniPath->Text = odFile->FileName;
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnTemplateSetClick(TObject *Sender)
{
    int index = cbTemplate->ItemIndex;
    switch(index)
    {
    case(0): /* Exec area (0x06004000) */
        edtStartAddress->Text = "06004000";
        edtLength->Text       = "442364";
        cbLengthKB->Checked   = false;
        break;

    case(1): /* BIOS */
        edtStartAddress->Text = "00000000";
        edtLength->Text       = "512";
        cbLengthKB->Checked   = true;
        break;

    case(2): /* SMPC Registers */
        edtStartAddress->Text = "00100000";
        edtLength->Text       = "";
        cbLengthKB->Checked   = true;
        break;

    case(3): /* Backup RAM */
        edtStartAddress->Text = "00180000";
        edtLength->Text       = "64";
        cbLengthKB->Checked   = true;
        break;

    case(4): /* Work RAM (Low) */
        edtStartAddress->Text = "00200000";
        edtLength->Text       = "1024";
        cbLengthKB->Checked   = true;
        break;

    case(5): /* Action Replay ROM */
        edtStartAddress->Text = "02000000";
        edtLength->Text       = "256";
        cbLengthKB->Checked   = true;
        break;

    case(6): /* Action Replay RAM (1st 512K) */
        edtStartAddress->Text = "02400000";
        edtLength->Text       = "512";
        cbLengthKB->Checked   = true;
        break;

    case(7): /* Action Replay RAM (2nd 512K) */
        edtStartAddress->Text = "02600000";
        edtLength->Text       = "512";
        cbLengthKB->Checked   = true;
        break;

    case(8): /* CD-ROM Registers */
        edtStartAddress->Text = "05800000";
        edtLength->Text       = "";
        cbLengthKB->Checked   = true;
        break;

    case(9): /* VDP1 VRAM */
        edtStartAddress->Text = "05C00000";
        edtLength->Text       = "";
        cbLengthKB->Checked   = true;
        break;

    case(10): /* VDP1 Framebuffer */
        edtStartAddress->Text = "05C80000";
        edtLength->Text       = "";
        cbLengthKB->Checked   = true;
        break;

    case(11): /* VDP1 Registers */
        edtStartAddress->Text = "05D00000";
        edtLength->Text       = "";
        cbLengthKB->Checked   = true;
        break;

    case(12): /* VDP2 VRAM */
        edtStartAddress->Text = "05E00000";
        edtLength->Text       = "";
        cbLengthKB->Checked   = true;
        break;

    case(13): /* VDP2 CRAM */
        edtStartAddress->Text = "05F00000";
        edtLength->Text       = "";
        cbLengthKB->Checked   = true;
        break;

    case(14): /* VDP2 Registers */
        edtStartAddress->Text = "05F80000";
        edtLength->Text       = "";
        cbLengthKB->Checked   = true;
        break;

    case(15): /* SCU Registers */
        edtStartAddress->Text = "05FE0000";
        edtLength->Text       = "";
        cbLengthKB->Checked   = true;
        break;

    case(16): /* Work RAM (High) */
        edtStartAddress->Text = "06000000";
        edtLength->Text       = "1024";
        cbLengthKB->Checked   = true;
        break;

    case(17): /* SatCom global vars */
        edtStartAddress->Text = "002FFFC0";
        edtLength->Text       = "64";
        cbLengthKB->Checked   = false;
        break;

    }
}
//---------------------------------------------------------------------------
unsigned char _ucTransfer = 0;
unsigned char _ucDebugger = 0;
void __fastcall TForm1::tmStatusBarRefreshTimer(TObject *Sender)
{
    /* Debug stuff. (Q&D !) */
    if(iDebugUse)
    {
        btnLogLevelsGetClick(NULL);
    }


    /* Update transfer status. */
    if(udGUI.transfer_on)
    {
        _ucTransfer = (_ucTransfer+1)%SB_ACTIVITY_MAXCOUNT;
        switch(_ucTransfer%SB_ACTIVITY_MAXCOUNT)
        {
        case(0):
            Form1->StatusBar->Panels->Items[SB_TRANSFER_INDEX]->Text = "LINK: |*    |";
            break;
        case(1):
            Form1->StatusBar->Panels->Items[SB_TRANSFER_INDEX]->Text = "LINK: |  *  |";
            break;
        case(2):
            Form1->StatusBar->Panels->Items[SB_TRANSFER_INDEX]->Text = "LINK: |    *|";
            break;
        default:
        case(3):
            Form1->StatusBar->Panels->Items[SB_TRANSFER_INDEX]->Text = "LINK: |  *  |";
            break;
        }
    }
    else
    {
        Form1->StatusBar->Panels->Items[SB_TRANSFER_INDEX]->Text = "LINK: OFF";
    }

    /* Update debugger status. */
    if((udGUI.transfer_on == 0) && (udGUI.debugger_on))
    {
        char active;
        char status[20];

        if(udGUI.prompt_on == 1)
        { /* Waiting for prompt data. */
            _ucDebugger = (_ucDebugger+1)%SB_PROMPT_DISP_RATE;
            if(_ucDebugger > (SB_PROMPT_DISP_RATE/2))
            {
                sprintf(status, "PROMPT");
            }
            else
            {
                sprintf(status, "");
            }
        }
        else
        { /* Normal debugger. */
            _ucDebugger = (_ucDebugger+1)%SB_ACTIVITY_MAXCOUNT;
            switch(_ucDebugger%SB_ACTIVITY_MAXCOUNT)
            {
            case(0):
                active = '+';
                break;
            case(1):
                active = 'o';
                break;
            case(2):
                active = '*';
                break;
            default:
            case(3):
                active = 'O';
                break;
            }
            sprintf(status, "DBG: %c [%02X]", active, udGUI.debugger_count);
        }
        Form1->StatusBar->Panels->Items[SB_DEBUGGER_INDEX]->Text = status;
    }
    else
    {
        Form1->StatusBar->Panels->Items[SB_DEBUGGER_INDEX]->Text = "DBG: OFF";
    }
}
//---------------------------------------------------------------------------


/* Send prompt answer when enter key is pressed. */
void __fastcall TForm1::edtDbgPromptKeyPress(TObject *Sender, char &Key)
{
    //if(udGUI.prompt_on)
    //{
    if((Key == '\r') || (Key == '\n'))
    {
        btnClick((TObject *)btnPromptSend);
    }
    //}
}
//---------------------------------------------------------------------------

int _mv_row = 0;
int _mv_col = 0;

void __fastcall TForm1::sgMemorySelectCell(TObject *Sender, int ACol,
      int ARow, bool &CanSelect)
{
    _mv_row = ARow;
    _mv_col = ACol;

//     mMemoryValues->Clear();
//     //LogOut("SelectCell AClo = %d, ARow = %d", ACol, ARow);
//     unsigned long index = ARow * /*sgMemory->ColCount*/16 + ACol;
//     unsigned long adr = udGUI.mv_address + index;
// #if 0
//     unsigned char data[4];
//     data[0] = (index+0 < MEMVIEW_DATASIZE ? udGUI.mv_data[index+0] : 0);
//     data[1] = (index+1 < MEMVIEW_DATASIZE ? udGUI.mv_data[index+1] : 0);
//     data[2] = (index+2 < MEMVIEW_DATASIZE ? udGUI.mv_data[index+2] : 0);
//     data[3] = (index+3 < MEMVIEW_DATASIZE ? udGUI.mv_data[index+3] : 0);
// 
//     char buff[1024];
//     sprintf(buff, "*(volatile unsigned char  *)(0x%08X) = 0x%02X"            , adr, data[0]);
//     mMemoryValues->Lines->Add(buff);
//     sprintf(buff, "*(volatile unsigned short *)(0x%08X) = 0x%02X%02X"        , adr, data[0], data[1]);
//     mMemoryValues->Lines->Add(buff);
//     sprintf(buff, "*(volatile unsigned long  *)(0x%08X) = 0x%02X%02X%02X%02X", adr, data[0], data[1], data[2], data[3]);
//     mMemoryValues->Lines->Add(buff);
// #else
//     unsigned char data = udGUI.mv_data[index];
// 
//     char buff[1024];
//     sprintf(buff, "*(volatile unsigned char  *)(0x%08X) = 0x%02X;", adr, data);
//     mMemoryValues->Lines->Add(buff);
// #endif
}
//---------------------------------------------------------------------------


#include "sh2/sh2d.h"
void __fastcall TForm1::cbMemoryConvertChange(TObject *Sender)
{
    int w = /*sgMemConvert->ColCount*/16;
    int h = sgMemConvert->RowCount;
    int i, j, k;
    char tmp[256];

    int datasize = 1;
    int index;

    index = cbMemSize->ItemIndex;
    switch(index)
    {
    default:
    case(0): /* 1 byte */
        sgMemConvert->ColCount = 16;
        sgMemConvert->DefaultColWidth = 24;
        datasize = 1;
        break;

    case(3): /* RGB555 -> 2 bytes */
        cbMemoryConvert->ItemIndex = 1; // HEX
    case(1): /* 2 bytes */
        sgMemConvert->ColCount = 8;
        sgMemConvert->DefaultColWidth = 49;
        datasize = 2;
        break;

    case(2): /* 4 bytes */
        sgMemConvert->ColCount = 4;
        sgMemConvert->DefaultColWidth = 99;
        datasize = 4;
        break;
    }


    unsigned long data = 0;
    index = cbMemoryConvert->ItemIndex;
    for(j=0; j<h; j++)
    {
        for(i=0; i<w; i+=datasize)
        {
            data = 0;
            for(k=0; k<datasize; k++)
            {
                data |= udGUI.mv_data[j*w + i + k] << (24 - 8*k);
            }
            data = data >> (32-8*datasize);


            switch(index)
            {
            default:
            case(0): /* Char */
                sprintf(tmp, "%c", char2pchar(data & 0x000000FF));
                break;

            case(1): /* Hex */
                if(datasize == 1)
                {
                    sprintf(tmp, "%02X", data);
                }
                else if(datasize == 2)
                {
                    sprintf(tmp, "%04X", data);
                }
                else
                {
                    sprintf(tmp, "%08X", data);
                }
                break;

            case(2): /* Dec */
                sprintf(tmp, "%u", data);
                break;
            }

            sgMemConvert->Cells[i/datasize][j] = tmp;
        }
    }


    sgSh2Dis->ColWidths[0] = 60;
    sgSh2Dis->ColWidths[1] = 40;
    sgSh2Dis->ColWidths[2] = sgSh2Dis->Width - sgSh2Dis->ColWidths[0]-1 - sgSh2Dis->ColWidths[1]-1 - 25/*scrollbar width*/;
    /* SH2 Disassembler by Bart Trzynadlowski. */
    datasize = 2; // 2bytes code
    h = sgSh2Dis->RowCount * datasize;
    j=0;
    unsigned long stt_addr = udGUI.mv_address;
    for(i=0; i<h; i+=datasize)
    {
        unsigned long v_addr = stt_addr + i;

        // Get op
        data = 0;
        for(k=0; k<datasize; k++)
        {
            data |= udGUI.mv_data[i + k] << (24 - 8*k);
        }
        data = data >> (32-8*datasize);

        // Print address
        sprintf(tmp, "%08X", v_addr);
        sgSh2Dis->Cells[0][j] = tmp;

        // Print op binary value
        sprintf(tmp, "%04X", data);
        sgSh2Dis->Cells[1][j] = tmp;

        // Print corresponding asm code.
        SH2Disasm(udGUI.disasm_mem_address, (udGUI.disasm_mem_use ? DISASM_MEMSIZE : 0), udGUI.disasm_mem_data,
                  v_addr, (unsigned short)data, 0/*mode:sh2*/, tmp);
        sgSh2Dis->Cells[2][j] = tmp;

        j++;
    }

    /* Output disassembler result to log file. */
    FILE* fp = fopen("disasm_log.s", "at");
    if(fp)
    { /* Size check. */
        fseek(fp, 0, SEEK_END);
        unsigned long length = ftell(fp);
        fseek(fp, 0, SEEK_SET);
        if(length > (500*1024))
        {
            fclose(fp);
            fp = fopen("disasm_log.s", "wt");
        }
    }
    if(fp)
    {
        char str[2048];
        for(int i=0; i<sgSh2Dis->RowCount; i++)
        {
            memset((void*)str, ' ', sizeof(str));
            sprintf(str+ 0, "    %s;", sgSh2Dis->Cells[2][i].c_str()); str[strlen(str)] = ' ';
            sprintf(str+80, " 0x%s %s\n", sgSh2Dis->Cells[0][i].c_str(), sgSh2Dis->Cells[1][i].c_str());
            fwrite(str, strlen(str), 1, fp);
        }
        sprintf(str, "\n"); fwrite(str, strlen(str), 1, fp);
        fclose(fp);
    }

    

}
//---------------------------------------------------------------------------


#include <cassert>
void __fastcall TForm1::sgSh2DisDrawCell(TObject *Sender, int ACol,
      int ARow, TRect &Rect, TGridDrawState State)
{
    /* Get cell to draw. */
    TStringGrid* StringGrid = static_cast<TStringGrid*>(Sender);
    assert(StringGrid != NULL);
    AnsiString text(StringGrid->Cells[ACol][ARow]);

    /* Normal mode : display in standard color. */
    StringGrid->Canvas->Brush->Color = clWindow;
    /* Set text color. */
    StringGrid->Canvas->Font->Color = clBlack;

    StringGrid->Canvas->FillRect(Rect);

    /* Display cell's text. */
    RECT RText = static_cast<RECT>(Rect);
    InflateRect(&RText, -3, -3);
    DrawText(StringGrid->Canvas->Handle,
            text.c_str(), text.Length(), &RText,
            (ACol == 2 ? DT_LEFT : DT_CENTER) | DT_SINGLELINE | DT_VCENTER);        
}
//---------------------------------------------------------------------------


int _mv_prevrow = _mv_row;
int _mv_prevcol = _mv_col;
void __fastcall TForm1::tmMemviewRefreshTimer(TObject *Sender)
{
    /* Refresh only when needed. */
    if((udGUI.mv_cntr != Form1->udGUI.mv_cver)
    || (_mv_prevrow != _mv_row)
    || (_mv_prevcol != _mv_col))
    {
        cbMemoryConvertChange(Sender);

        /* Acknowledge refresh. */
        udGUI.mv_cntr = Form1->udGUI.mv_cver;
        _mv_prevrow = _mv_row;
        _mv_prevcol = _mv_col;
    }
}
//---------------------------------------------------------------------------


#include <cassert>
void __fastcall TForm1::sgMemConvertDrawCell(TObject *Sender, int ACol,
      int ARow, TRect &Rect, TGridDrawState State)
{
    //AnsiString str;
    //str.printf("ARow = %d, ACol = %d", ARow, ACol); Form1->mLog->Lines->Add(str.c_str());

    /* Get cell to draw. */
    TStringGrid* StringGrid = static_cast<TStringGrid*>(Sender);
    assert(StringGrid != NULL);
    AnsiString text(StringGrid->Cells[ACol][ARow]);

    /* Need to draw in colors ? */
    int index = cbMemSize->ItemIndex;
    bool bColor = (cbMemSize->ItemIndex == 3 ? true : false);

    if(bColor)
    {
        /* Colors mode : extract value from cell's text (HEX value). */
        unsigned short val = strtoul(text.c_str(), NULL, 16);
        int r = (val >>  0 & 0x1F) << 3;
        int g = (val >>  5 & 0x1F) << 3;
        int b = (val >> 10 & 0x1F) << 3;
        StringGrid->Canvas->Brush->Color = (TColor)((b<<16) | (g << 8) | (r));

        /* Set text color (yeah, Q&D !). */
        StringGrid->Canvas->Font->Color = ((r+g+b) <= 384 ? clWhite : clBlack);
    }
    else
    {
        /* Normal mode : display in standard color. */
        StringGrid->Canvas->Brush->Color = clWindow;
        /* Set text color. */
        StringGrid->Canvas->Font->Color = clBlack;
    }
    StringGrid->Canvas->FillRect(Rect);

    /* Display cell's text. */
    RECT RText = static_cast<RECT>(Rect);
    InflateRect(&RText, -3, -3);
    DrawText(StringGrid->Canvas->Handle,
            text.c_str(), text.Length(), &RText,
            DT_CENTER | DT_SINGLELINE | DT_VCENTER);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnMemViewVDP2CRAMClick(TObject *Sender)
{
    edtMemViewAddress->Text = "05F00000";
    cbMemSize->ItemIndex = 3/* RGB555. */;
    cbMemoryConvert->ItemIndex = 1/* Hex. */;
    btnClick((TObject*)btnMemView);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnMemViewGlobalDataClick(TObject *Sender)
{
    edtMemViewAddress->Text = "002FFFC0";
    cbMemSize->ItemIndex = 0/* UCHAR*/;
    cbMemoryConvert->ItemIndex = 2/* Decimal. */;
    btnClick((TObject*)btnMemView);
}
//---------------------------------------------------------------------------


void __fastcall TForm1::btnMemViewDbgDataClick(TObject *Sender)
{
    AnsiString str;

    if(thProcessThread == NULL)
    {
        Application->MessageBox("Internal error !", "SatLink", MB_OK | MB_ICONWARNING);
        return;
    }
    scd_info_t* ptr = thProcessThread->ptrDebuggerActivity;
    if(ptr == NULL)
    {
        Application->MessageBox("You need to run debugger at least once\nbefore using this functionality !", "SatLink", MB_OK | MB_ICONWARNING);
        return;
    }

    str.printf("%08X", ptr->struct_start_addr);
    edtMemViewAddress->Text = str;
    cbMemSize->ItemIndex = 0/* UCHAR*/;
    cbMemoryConvert->ItemIndex = 2/* Decimal. */;
    btnClick((TObject*)btnMemView);
}
//---------------------------------------------------------------------------




/* Query USB Data Link parameters, and if needed, create a usbdl.ini file. */
void __fastcall TForm1::mniSetUSBDataLinkParametersClick(TObject *Sender)
{
    char udl_comport[256];
    char udl_ledcolor[256];
    AnsiString str;

    str = "COM3";
    if ( InputQuery("USB Data Link - COM port", "Enter COM port (COMx)", str) && Trim(str) != "" )
    {
        sprintf(udl_comport, "%s", str.c_str());

        str = "red";
        if ( InputQuery("USB Data Link - LED color", "Enter LED color (red/green)", str) && Trim(str) != "" )
        {
            sprintf(udl_ledcolor, "%s", str.LowerCase().c_str());

            /* Input OK, so that output a usbdl.ini file. */
            scl_log(SCLT_HOSTPG, 0/*level*/, "Create usbdl.ini (%s %s)", udl_comport, udl_ledcolor);
            cbIniPath->Text = "usbdl.ini";
            FILE* f=fopen("usbdl.ini", "wb");
            if(f)
            {
                fprintf(f, "-logsettings\r\n");
                fprintf(f, "log_settings.ini\r\n");
                fprintf(f, "-loginfos\r\n");
                fprintf(f, "\r\n");

                fprintf(f, "-dev\r\n");
                fprintf(f, "usbdl\r\n");
                fprintf(f, "\r\n");

                fprintf(f, "-s\r\n");
                fprintf(f, "port\r\n");
                fprintf(f, "%s\r\n", udl_comport);
                fprintf(f, "\r\n");

                fprintf(f, "-s\r\n");
                fprintf(f, "device_led\r\n");
                fprintf(f, "%s\r\n", udl_ledcolor);
                fprintf(f, "\r\n");

                fprintf(f, "display\r\n");
                fprintf(f, "1\r\n");

                fclose(f); f=NULL;
            }
        }
    }
}
//---------------------------------------------------------------------------




#include "common/portlib.h"
void __fastcall TForm1::btnTest2Click(TObject *Sender)
{
AnsiString strA = "12345A";
bool bRet = InputQuery("TEST", "Enter Value: ", strA);
return;
//btnClick(btnOpen);
    AnsiString str;
    unsigned char val;

    port_init();
    val = port_read_byte(0x0378);
    str.printf("Port[0x0378] = 0x%02X", val); Form1->mLog->Lines->Add(str.c_str());
    port_close();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnTest3Click(TObject *Sender)
{
    reg_convert_t r;
    r.i_reg_address = udGUI.reg_address;
    r.i_reg_size    = udGUI.reg_len;
    r.i_reg_value   = udGUI.reg_value;
    thProcessThread->register_convert(&r);
}
//---------------------------------------------------------------------------



#include "common/SerialComm.h"
/* DataLink packet, any protocol. */
#pragma pack(1)	
typedef struct _dlPacket
{
    unsigned char directn;   /* PC->AR : 0x5A, AR->PC : 0xA5.                 */
    unsigned char pktsize;   /* packet size (counted from next byte).         */
    unsigned char pktflag;   /* packet type.                                  */
    unsigned long address;   /* read (write) address.                         */
    unsigned char datalen;   /* data length.                                  */
    unsigned char data[300]; /* data (max 191 bytes), then checksum (1 byte). */
}dlPacket;
/**
 *Note : data[300]
 * data[192] (191 data bytes + checksum) may be enough, but 
 * 300 bytes allows to avoid bug when reading bad-formed 
 * packets (example : datalen == 0xFF).
**/
#pragma pack()

void pck_reset(dlPacket* p);
unsigned char pck_get_checksum(dlPacket* p);
unsigned long ulong_swap(unsigned long data);
void pck_print(dlPacket* p);

void __fastcall TForm1::btnUDLGoClick(TObject *Sender)
{
    AnsiString str;
    unsigned long i;
    unsigned long adr = strtoul(edtUDLAddress->Text.c_str(), NULL, 16);
    unsigned long len = strtoul(edtUDLLen->Text.c_str(), NULL, 0);
    unsigned long count = strtoul(edtUDLCount->Text.c_str(), NULL, 0);
    char port[256];

    mLog->Lines->Clear();

    str.printf("Start address = 0x%08X", adr); Form1->mLog->Lines->Add(str.c_str());
    str.printf("Download length = %d bytes", len); Form1->mLog->Lines->Add(str.c_str());
    str.printf("Download count = %d times", count); Form1->mLog->Lines->Add(str.c_str());

    strcpy(port, edtUDLPort->Text.c_str());
    str.printf("COM port = %s", port); Form1->mLog->Lines->Add(str.c_str());

    /* Open COM port. */
    SerialComm* _com = NULL;
    if(edtUDLColor->Text != "green")
    { // original HW
        _com = new SerialComm(port, "baud=288000 parity=N data=8 stop=2", 1000, 1000);
    }
    else
    { // final HW
        _com = new SerialComm(port, "baud=375000 parity=N data=8 stop=2", 1000, 1000);
    }
    _com->Start();

    /* Download packets. */
    for(i=0; i<count; i++)
    {
        dlPacket pkt;
        unsigned char pktflag;
        if(i == 0)
            pktflag = 0x01; /* Start packet. */
        else if(i == (count-1))
            pktflag = 0x21; /* End packet. */
        else
            pktflag = 0x11; /* Middle packet. */


        /* Set a "receive data" request. */
        pck_reset(&pkt);
        pkt.directn = 0x5A;
        pkt.pktflag = pktflag;
        pkt.address = ulong_swap(adr);
        pkt.pktsize = 7;
        pkt.datalen = len;
        pkt.data[pkt.pktsize-7] = pck_get_checksum(&pkt);

        Form1->mLog->Lines->Add("Send a \"receive data\" request ..."); pck_print(&pkt);
        _com->Send((void*)(&pkt), 9, NULL);

        /* Receive header from USB DataLink. */
        pck_reset(&pkt);
        Form1->mLog->Lines->Add("Waiting for answer header ...");
        _com->Receive((void*)(&pkt), 9+pkt.datalen, NULL);

        pck_print(&pkt);
    }

    /* Close connection. */
    delete _com; _com = NULL;
}
//---------------------------------------------------------------------------


/* Display current log levels (DEBUG use). */
void __fastcall TForm1::btnLogLevelsGetClick(TObject *Sender)
{
    scl_settings_t* ptr =  &_log_global_settings;
    AnsiString str;
    int i, j;

    mLogLevels->Lines->Clear();

    str.printf("silent_on=%d", ptr->silent_on); mLogLevels->Lines->Add(str.c_str());
    char tmp1[50];
    char tmp2[50];
    for(i = 0; i < SCLT_COUNT; i++)
    {
        tmp1[0] = '\0';
        for(j = 0; j < SCLO_COUNT; j++)
        {
            sprintf(tmp2, "%X ", ptr->levels[i][j]);
            strcat(tmp1, tmp2);
        }
        str.printf("l[%d]=%s", i, tmp1); mLogLevels->Lines->Add(str.c_str());
    }
}
//---------------------------------------------------------------------------







#include "parlink/parlink.h"


unsigned char _ucParEXC = 0x49;
void __fastcall TForm1::btnParExchangeClick(TObject *Sender)
{
    AnsiString str;
    unsigned char wrval = strtoul(edtParWriteVal->Text.c_str(), NULL, 0);
    if(cbParExcInc->Checked)
    {
        wrval = _ucParEXC;
        _ucParEXC++;
    }

    unsigned char rdval = par_exchange_byte(wrval);
    LogOut("par_exchange_byte(0x%02X (%d)) = 0x%02X (%d)", wrval, wrval, rdval, rdval);

    str.printf("0x%02X (%d)", rdval, rdval); edtParReadVal->Text = str;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::btnParExchangeLoopClick(TObject *Sender)
{
    int loopcnt = strtoul(edtParExchangeLoop->Text.c_str(), NULL, 0);
    int i;

    for(i=0; i<loopcnt; i++)
    {
        unsigned char wrval = strtoul(edtParWriteVal->Text.c_str(), NULL, 0);
        if(cbParExcInc->Checked)
        {
            //wrval = _ucParEXC;
            wrval += i;
            _ucParEXC++;
        }

        unsigned char rdval = par_exchange_byte(wrval);

        if((i<=2) || (i>=(loopcnt-3)))
        {
            AnsiString str;
            LogOut("[%3d]par_exchange_byte(0x%02X (%d)) = 0x%02X (%d)", i, wrval, wrval, rdval, rdval);
            str.printf("0x%02X (%d)", rdval, rdval); edtParReadVal->Text = str;
        }
        else if(i==3)
        {
            LogOut("...");
        }
    }
        
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnParOpenClick(TObject *Sender)
{
    btnOpen->OnClick((TObject *)btnOpen);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnParCloseClick(TObject *Sender)
{
    btnClose->OnClick((TObject *)btnClose);
}
//---------------------------------------------------------------------------


void __fastcall TForm1::btnParWriteClick(TObject *Sender)
{
    int i = cbParOffset->ItemIndex;
    AnsiString str;
    unsigned char wrval;
    _port_value = strtoul(edtParPortAddress->Text.c_str(), NULL, 0);
    if(i < 0) {cbParOffset->ItemIndex = 0; i = cbParOffset->ItemIndex;}

    wrval = strtoul(edtParWriteVal->Text.c_str(), NULL, 0);

    LogOut("port_write_byte(0x%04X + %d, 0x%02X (%d)) ...", _port_value, i, wrval, wrval);
    port_write_byte(_port_value + i, wrval);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnParReadClick(TObject *Sender)
{
    int i = cbParOffset->ItemIndex;
    AnsiString str;
    unsigned char rdval;
    _port_value = strtoul(edtParPortAddress->Text.c_str(), NULL, 0);
    if(i < 0) {cbParOffset->ItemIndex = 0; i = cbParOffset->ItemIndex;}

    rdval = port_read_byte(_port_value + i);

    LogOut("port_read_byte(0x%04X + %d) = 0x%02X (%d)", _port_value, i, rdval, rdval);
    str.printf("0x%02X (%d)", rdval, rdval); edtParReadVal->Text = str;
}
//---------------------------------------------------------------------------


void vbt_command_parse(char* data, int datalen, int* argc, char** argv)
{
    int i, j;

    /* If needed, append first line to argv. */
    if((data[0] > ' ') && (data[0] != '#'))
    {
        argv[(*argc)] = data; (*argc)++;
    }
    for(i=0; i<(datalen-2); i++)
    {
        /* If found, append command. */
        if((data[i  ] < ' ')
        && (data[i+1] > ' '))
        {
            /* Ignore comments */
            if(data[i+1] != '#')
            {
                argv[(*argc)] = data + i+1; (*argc)++;
            }
        }
        /* Remove non displayable characters. */
        if(data[i] < ' ') data[i] = '\0';
    }
    /* Remove non displayable characters. */
    j=i;
    for(i=j; i<datalen; i++)
    {
        if(data[i] < ' ') data[i] = '\0';
    }
}
void __fastcall TForm1::btnParMacroClick(TObject *Sender)
{
    AnsiString str;
    _port_value = strtoul(edtParPortAddress->Text.c_str(), NULL, 0);

    /* Parse command file. */
    FILE* fh = NULL;
    unsigned long len;
    int i;

    char cmd_file[32*1024];
    int argc;
    char* argv[2048];

    mLog->Lines->Clear();

    LogOut("Read command file STT", 0);
    memset((void*)cmd_file, 0, sizeof(cmd_file));
    fh = fopen("macro.txt", "rb");
    if(fh == NULL)
    {
        LogOut("Couldn't open macro.txt file !");
        return;
    }
    len = fread((void*)cmd_file/*buff*/, 1, sizeof(cmd_file)-1/*size*/, fh);
    fclose(fh); fh = NULL;
    cmd_file[sizeof(cmd_file)-1] = '\0';
    LogOut("Read command file END (%d bytes)", len);
    if(len < 3) return;

    /* Parse commands file. */
    argc = 1;
    argv[0] = "";
    vbt_command_parse(cmd_file, len, &argc, argv);
    for(i=1; i<argc; i++)
    {
        //LogOut("Command[%d] = *%s*", i, argv[i]);

        if(!strcmp(argv[i], "log"))
        {
            LogOut("");
            LogOut("%s", argv[i+1]);
            i+=1;
        }
        else if(!strcmp(argv[i], "IN"))
        {
            unsigned long ii;
            unsigned char r;
            unsigned char  offs = strtoul(argv[i+1], NULL, 0);
            unsigned long  cnt  = strtoul(argv[i+2], NULL, 0);
            unsigned char  disp = strtoul(argv[i+3], NULL, 0);
            for(ii=0; ii<cnt; ii++)
            {
                r = port_read_byte(_port_value + offs);
                LogOut("port_read_byte(0x%04X + %d) = 0x%02X(%c)", _port_value, offs, r, char2pchar(r));
            }
            if(disp)
            {
                str.printf("0x%02X (%c)", r, char2pchar(r)); edtParReadVal->Text = str;
            }
            i+=3;
        }
        else if(!strcmp(argv[i], "OUT"))
        {
            unsigned char r;
            unsigned char  offs = strtoul(argv[i+1], NULL, 0);
            unsigned long  data = strtoul(argv[i+2], NULL, 0);
            unsigned long  andv = strtoul(argv[i+3], NULL, 0);
            unsigned long  xorv = strtoul(argv[i+4], NULL, 0);
            unsigned char  disp = strtoul(argv[i+5], NULL, 0);

            unsigned char val = (data & andv) ^ xorv;
            port_write_byte(_port_value + offs, val);
            LogOut("port_write_byte(0x%04X + %d, (0x%02X & 0x%02X) ^ 0x%02X (=0x%02X))", _port_value, offs, data, andv, xorv, val);

            i+=5;
        }
        else
        {
            LogOut("Error: unknown command: %s", argv[i]);
        }
    }
}
//---------------------------------------------------------------------------


void __fastcall TForm1::cbRegistersAddressChange(TObject *Sender)
{
    char reg_address[STR_LEN];
    char reg_len[STR_LEN];
    char reg_value[STR_LEN];
    reg_convert_t r;

    strcpy(reg_address , cbRegistersAddress->Text.c_str());
    strcpy(reg_len     , edtRegisterLength->Text.c_str());
    strcpy(reg_value   , edtRegisterValue->Text.c_str());

    r.i_reg_address = reg_address;
    r.i_reg_size    = reg_len;
    r.i_reg_value   = reg_value;

    thProcessThread->register_convert(&r);

    if(r.o_reg_index != -1)
    {
        edtRegisterLength->Text = AnsiString(r.o_reg_size);
    }
}
//---------------------------------------------------------------------------



void __fastcall TForm1::tmVparRefreshTimer(TObject *Sender)
{
    AnsiString str;
    char buff[VPAR_STRLEN+1];
    unsigned char c;

    if(_yabause_use == 0)
    { /** In the case vpar DLL is not used, don't go further. **/
        edtYabUpdtCntrs->Text = "---";
        return;
    }

    /** If first use, clear shared memory contents buffer. **/
    if(iVparFirstSet) memset((void*)&vpar_sm, 0, sizeof(vpar_shared_memory_t));


    /** Get shared memory data and display their contents. **/
    vpar_shared_memory_t sm;
    memset((void*)&sm, 0, sizeof(vpar_shared_memory_t));
    _vpar.GetSharedMemory(&sm);

    /* Display I/O status. */
    sgYabLinkMonitor->Cells[0][0] = "C_OUT";
    sgYabLinkMonitor->Cells[1][0] = "C_STAT";
    sgYabLinkMonitor->Cells[2][0] = "C_IN";
    sgYabLinkMonitor->Cells[3][0] = "-";

    c = sm.io.arp_output;  str.printf("0x%02X (%c)", c, char2pchar(c)); sgYabLinkMonitor->Cells[0][1] = str;
    c = sm.io.arp_status;  str.printf("0x%02X (%c)", c, char2pchar(c)); sgYabLinkMonitor->Cells[1][1] = str;
    c = sm.io.arp_input;   str.printf("0x%02X (%c)", c, char2pchar(c)); sgYabLinkMonitor->Cells[2][1] = str;
    c = sm.io.arp_unused1; str.printf("0x%02X (%c)", c, char2pchar(c)); sgYabLinkMonitor->Cells[3][1] = str;

    sgYabLinkMonitor->Cells[0][3] = "P_IO";
    sgYabLinkMonitor->Cells[1][3] = "-";
    sgYabLinkMonitor->Cells[2][3] = "P_BUSY";
    sgYabLinkMonitor->Cells[3][3] = "Mtx_ERR";

    c = sm.io.lpt_inout;   str.printf("0x%02X (%c)", c, char2pchar(c)); sgYabLinkMonitor->Cells[0][4] = str;
    c = sm.io.lpt_unused1; str.printf("0x%02X (%c)", c, char2pchar(c)); sgYabLinkMonitor->Cells[1][4] = str;
    c = sm.io.lpt_busy;    str.printf("0x%02X (%c)", c, char2pchar(c)); sgYabLinkMonitor->Cells[2][4] = str;
    c = sm.io.io_debug1;   str.printf("0x%02X (%c)", c, char2pchar(c)); sgYabLinkMonitor->Cells[3][4] = str;


    /* Display yabause settings. */
    str.printf("%02X / %02X", sm.yabause_set.update_counter, sm.satlink_set.update_counter);
    edtYabUpdtCntrs->Text = str;

    memcpy((void*)buff, (void*)&(sm.yabause_set.last_file), VPAR_STRLEN); buff[VPAR_STRLEN] = '\0';
    edtYabLastFile->Text = buff;

    str.printf("M[%08X] S[%08X]", sm.yabause_set.pc[0], sm.yabause_set.pc[1]);
    edtYabPC->Text = str;
    str.printf("R[%08X][%02X] W[%08X][%02X]", sm.yabause_set.mem_read, sm.yabause_set.mem_read_cntr, sm.yabause_set.mem_write, sm.yabause_set.mem_write_cntr);
    edtYabRWAddr->Text = str;


    /** Set setting data from GUI to internal data. **/
    vpar_satlink_set_t set;
    memcpy((void*)&set, (void*)&(vpar_sm.satlink_set), sizeof(vpar_satlink_set_t));

    set.dbgview_enable = (cbYabDbgView->Checked ? 1 : 0);

    set.dbgview[0] = (cbYabDbg0->Checked ? 1 : 0);
    set.dbgview[1] = (cbYabDbg1->Checked ? 1 : 0);

    /* VDP2 */
    set.vdp2log  = (cbYabVdp2Log->Checked ? 1 : 0);
    set.alldisp  = (cbYabAllDisp->Checked ? 1 : 0);
    set.diffdisp = (cbYabDiffDisp->Checked ? 1 : 0);
    set.saveref  = (cbYabSaveRef->Checked ? 1 : 0);
    set.dump     = (cbYabDump->Checked ? 1 : 0);
    /* VDP1 */
    set.vdp1log       = (cbYabVdp1Log->Checked ? 1 : 0);
    set.vdp1_reglog   = (cbYabVdp1Reg->Checked ? 1 : 0);
    set.vdp1_cmdlog   = (cbYabVdp1Cmd->Checked ? 1 : 0);
    set.vdp1_regsdump = (cbYabVdp1Dmp->Checked ? 1 : 0);

    /* Link emulator. */
    set.ylink_emulate     = (cbYabLinkEmu->Checked ? 1 : 0);
    set.log_ylink_emulate = (cbYabLinkEmuLog->Checked ? 1 : 0);

    memset(set.logpath, 0, VPAR_STRLEN);
    strncpy(set.logpath, edtYabLogPath->Text.c_str(), VPAR_STRLEN-1);

    set.crappy_dbg = (cbCrappyDbg->Checked ? 1 : 0);

    set.vdp2_poll_interval = strtoul(edtYabPollInterval->Text.c_str(), NULL, 0);
    if(set.vdp2_poll_interval < 5) set.vdp2_poll_interval = 5;

    set.monitor_interval = strtoul(edtYabMoniInterval->Text.c_str(), NULL, 0);

    /** If needed, update settings. **/
    if((iVparFirstSet) || (memcmp((void*)&(vpar_sm.satlink_set), (void*)&set, sizeof(vpar_satlink_set_t)) != 0))
    {
        memcpy((void*)&(vpar_sm.satlink_set), (void*)&set, sizeof(vpar_satlink_set_t));
        vpar_sm.satlink_set.update_counter++;
        _vpar.SetSatLinkParameters(&(vpar_sm.satlink_set));

        iVparFirstSet = 0;
    }
}
//---------------------------------------------------------------------------


void __fastcall TForm1::edtMemViewAddressKeyPress(TObject *Sender,
      char &Key)
{
    if((Key == '\r') || (Key == '\n'))
    {
        btnClick((TObject *)btnMemView);
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::edtMemFindValKeyPress(TObject *Sender, char &Key)
{
    if((Key == '\r') || (Key == '\n'))
    {
        btnClick((TObject *)btnMemFind);
    }
}
//---------------------------------------------------------------------------


int _iMemView_X = 0;
int _iMemView_Y = 0;
AnsiString _iMemView_Str = "";

void __fastcall TForm1::sgMemConvertSetEditText(TObject *Sender, int ACol,
      int ARow, const AnsiString Value)
{
    _iMemView_X = ACol;
    _iMemView_Y = ARow;
    _iMemView_Str = Value;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::sgMemConvertKeyPress(TObject *Sender, char &Key)
{
    /* Prevent from entering value when auto-read memory. */
    if(cbMemViewAuto->Checked) return;

    if((Key == '\r') || (Key == '\n'))
    {
        char buff[128];
        int index;
        memset(buff, 0, sizeof(buff)); snprintf(buff, sizeof(buff)-1, "%s", _iMemView_Str.c_str());

        unsigned long data = 0;
        int datasize = 0;
        int dataoffset = 0;
        index = cbMemoryConvert->ItemIndex;
        switch(index)
        {
        default:
        case(0): /* Char */
            data = buff[0];
            break;

        case(1): /* Hex */
            data = strtoul(buff, NULL, 16);
            break;

        case(2): /* Dec */
            data = strtoul(buff, NULL, 10);
            break;
        }

        index = cbMemSize->ItemIndex;
        switch(index)
        {
        default:
        case(0): /* 1 byte */
            datasize = 1;
            dataoffset = _iMemView_Y*16 + _iMemView_X*datasize;
            udGUI.mv_data[dataoffset] = data;
            break;

        case(3): /* RGB555 -> 2 bytes */
        case(1): /* 2 bytes */
            datasize = 2;
            dataoffset = _iMemView_Y*16 + _iMemView_X*datasize;
            udGUI.mv_data[dataoffset + 0] = (data>> 8) & 0x000000FF;
            udGUI.mv_data[dataoffset + 1] = (data>> 0) & 0x000000FF;
            break;

        case(2): /* 4 bytes */
            datasize = 4;
            dataoffset = _iMemView_Y*16 + _iMemView_X*datasize;
            udGUI.mv_data[dataoffset + 0] = (data>>24) & 0x000000FF;
            udGUI.mv_data[dataoffset + 1] = (data>>16) & 0x000000FF;
            udGUI.mv_data[dataoffset + 2] = (data>> 8) & 0x000000FF;
            udGUI.mv_data[dataoffset + 3] = (data>> 0) & 0x000000FF;
            break;
        }
        /* Send a write request. */
        udGUI.mv_woff = dataoffset;
        udGUI.mv_wlen = datasize;
        udGUI.btn[BTN_MVWRITE] = 1;

    }
}
//---------------------------------------------------------------------------







/* Inline assembler. */
#include "sh2/iasm.h"
void __fastcall TForm1::btnIasmExecClick(TObject *Sender)
{
    AnsiString str;
    unsigned short op = (unsigned short)iasm(edtIasmText->Text.c_str());
    str.printf("0x%04X (%d)", op, op);
    edtIasmOpCode->Text = str;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::edtIasmTextKeyPress(TObject *Sender, char &Key)
{
    if((Key == '\r') || (Key == '\n'))
    {
        btnIasmExecClick(Sender);
    }
}
//---------------------------------------------------------------------------

/* Disassembler. */
#include "sh2/sh2d.h"
void __fastcall TForm1::btnAsmExecClick(TObject *Sender)
{
    char tmp[256];
    unsigned short op = strtoul(edtIasmOpCode->Text.c_str(), NULL, 0);
    unsigned short addr = strtoul(edtIasmOpCode->Text.c_str(), NULL, 0);

    SH2Disasm(0, 0, 0, addr, op, 0/*mode:sh2*/, tmp);
    edtIasmText->Text = tmp;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::edtIasmOpCodeKeyPress(TObject *Sender, char &Key)
{
    if((Key == '\r') || (Key == '\n'))
    {
        btnAsmExecClick(Sender);
    }
}
//---------------------------------------------------------------------------


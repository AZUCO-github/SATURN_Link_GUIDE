Sega Saturn USB Dev cart driver - readme
http://ppcenter.free.fr/satcart/
Last updated : 2012/07/23


Description :
This driver will allow you to communicate with your Saturn via USB dev cart interface.


How to install :
 1. Turn your Saturn OFF.
 2. Connect your USB dev cart to your PC via USB.
 3. Plug your USB dev cart to your Saturn memory cartridge port.
 4. Turn your Saturn ON.
     -> A blue/green blinking screen appears on Saturn.
     -> If connected for the first time, your PC begs for drivers.
 5. According to your PC configuration, please select
    between x86, ia64 or amd64 folders from driver installation dialog window.
 6. When required, click OK on installation confirmation dialog window(s).


Note :
This driver has been tested and works under Windows XP 32 bits.
If this driver doesn't works under your operating system, please refer
to FTDI (USB chip used by USB dev cart) homepage :
http://www.ftdichip.com/Drivers/D2XX.htm



#include <SGL.H>
#include <sega_bup.h>
#include "RockinVR.h"
#include "common.h"


/****************************************************************************************************/
/* common functions *********************************************************************************/
/****************************************************************************************************/

//void clearScreen()
//{
//    int i;
//    for(i = 0; i < (240 / 8); i++)
//        slPrint("                                            ", slLocate(0, i));
//}

// check if pad is connected
// and return first pad with input
// multi tap compatible, up to 12 pads
//
// return: 	-1 		- no pad connected
//			-2 		- no input
//			else	- pad index
Sint8 getFirstPadIndex()
{
    Sint8 index;

    // is there even a pad connected?
    // check number of attached peripherals
    if((Per_Connect1 + Per_Connect2) == 0)
        return -1;
        
        // check up to 6 pads on left connector
    for(index = 0; index < Per_Connect1; index++) 
        if((Smpc_Peripheral[index].data != 0xFFFF) || (Smpc_Peripheral[index].pull != 0xFFFF))
            return index;

        // check up to 6 pads on right connector
    for(index = 0; index < Per_Connect2; index++) 
        if((Smpc_Peripheral[15+index].data != 0xFFFF) || (Smpc_Peripheral[15+index].pull != 0xFFFF))
            return 15+index;
            
        // no inputs found!
        // that is no error
    return -2;
}

void checkExitHere(Uint16 data)
{
    // check exit
    if(((data & PER_DGT_ST) == 0) && ((data & PER_DGT_TA) == 0) && ((data & PER_DGT_TB) == 0) && ((data & PER_DGT_TC) == 0)) {
        // return to demo demo loader
        // or activate multiplayer
        SYS_Exit(0);
    }
}

// return index and write button data
Sint8 getfirstPadInput(Uint16 *data, Uint16 *push, Uint16 *pull)
{
    Sint8 index = getFirstPadIndex();
    // pad found?    
    if(index == -1) {
        // no pad connected
        clearScreen();
        slPrint("!!! NO CONTROLLER CONNECTED !!!", slLocate(6, 14));
        // wait for a pad being connected
        do {
            index = getFirstPadIndex();
            slSynch();
        } while(index == -1);
    }
    if(index >= 0) {
        checkExitHere(Smpc_Peripheral[index].data);
        if(data != NULL)
            *data = Smpc_Peripheral[index].data;
        if(push != NULL)
            *push = Smpc_Peripheral[index].push;
        if(pull != NULL)
            *pull = Smpc_Peripheral[index].pull;
    } else {
        if(data != NULL)
            *data = 0xFFFF;
        if(push != NULL)
            *push = 0xFFFF;
        if(pull != NULL)
            *pull = 0xFFFF;
    }
    
    return index;
}


//void waitRelease(Uint16 buttons)
//{
//    Uint16 data, pull;
//    // wait release
//    do {
//        slSynch();
//        getfirstPadInput(&data, NULL, &pull);
//    } while( ((data & buttons) != buttons) && ((pull & buttons) != buttons));
////    } while(((data & PER_DGT_ST) == 0) || ((data & PER_DGT_TA) == 0) || ((data & PER_DGT_TB) == 0) || ((data & PER_DGT_TC) == 0));
//}


void waitKey(Uint16 buttons)
{
    Uint16 data;
    // wait release
    do {
        slSynch();
        getfirstPadInput(&data, NULL, NULL);
    } while(data != buttons);
}

void waitRelease()
{
     // wait for key release
     Uint16 data;
     while(getfirstPadInput(&data, NULL, NULL) >= 0)
//     while(data != PRESSED_PAD_NOTHING) 
     {
//          data = Smpc_Peripheral[0].data;
          slSynch();
     }
     slSynch();

     return;
}

//void waitKey(Uint16 key)
//{
//     // wait for pressing START
//     Uint16 data = Smpc_Peripheral[0].data;
//     while(data != key) 
//     {
//          data = Smpc_Peripheral[0].data;
//          slSynch();
//     }
//     slSynch();
//     
//     return;
//}


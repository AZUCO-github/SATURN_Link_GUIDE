

// taken from fb.h from Rockin'-VR:

/* pressed keys */
#define        PRESSED_PAD_UP                0xEFFF
#define        PRESSED_PAD_DOWN              0xDFFF
#define        PRESSED_PAD_LEFT              0xBFFF
#define        PRESSED_PAD_RIGHT             0x7FFF
#define        PRESSED_PAD_A                 0xFBFF
#define        PRESSED_PAD_B                 0xFEFF
#define        PRESSED_PAD_C                 0xFDFF
#define        PRESSED_PAD_X                 0xFFBF
#define        PRESSED_PAD_Z                 0xFFEF
#define        PRESSED_PAD_L                 0xFFF7
#define        PRESSED_PAD_R                 0xFF7F
#define        PRESSED_PAD_START             0xF7FF
#define        PRESSED_PAD_NOTHING           0xFFFF

/* operation modes */
#define        LOAD_KNOWN                    0
#define        SAVE_KNOWN                    1
#define        LOAD_UNKNOWN                  2
#define        SAVE_UNKNOWN                  3
#define        COPY_DELETE_RENAME_UNKNOWN    4


// taken from fb_util.c from Rockin'-VR:
void get_name(Uint8 *instructions, Uint8 length, Uint8 *target, Uint8 player);
void get_name_print_all(Uint8 dim_x, Uint8 dim_y, Sint8 chartbl[8][8], Uint8 item_x, Uint8 item_y, Uint8 charsleft, Uint8 *target, Uint8 *instructions);
//void get_name_print_all(Uint8 dim_x, Uint8 dim_y, Sint8 **chartbl, Uint8 item_x, Uint8 item_y, Uint8 charsleft, Uint8 *target, Uint8 *instructions);
void get_name_print_cursor(Uint8 dim_x, Uint8 dim_y, Uint8 item_x, Uint8 item_y);
void clearScreen();

// taken from fb.c from Rockin'-VR(now debugged, modified and enhanced):
Sint8 dialog(Uint8 posX, Uint8 posY, Uint8 strings, Sint8 selected, Uint8 items,...);

Sint8 get_dir_MEM(Uint8 mode, Uint32 device, Uint8 length, Uint8 *target);
void get_dir_print_all_MEM(Uint8 mode, BupDir dirs[], BupStat sttb, Uint8 files, Sint8 item, Uint32 device);
void get_dir_print_files_MEM(Uint8 mode, BupDir dirs[], Uint8 files, Sint8 item);



#include <SGL.H>

/* for replay debuging */
//#define        DEBUG_REPLAY
/* define here if to use PCM(for CD release) or not(PAR uploading) */
#define        USE_PCM
/* number of silent frames between "Player ?" and "you win" or "you loose" */
#define        PCM_PAUSE                     6

/* Error codes */
#define        ERROR_OK                      0
#define        ERROR_OUT_OF_MEMORY           -1
#define        ERROR_NO_CONTROLLER           -2
#define        ERROR_BACKUP_MEMORY           -3
#define        ERROR_ABORTED                 -4

/* for stop watch timer */
#define        FPS_DIV        2
#define        FPS            (60 / FPS_DIV)

/* for demo play */
#define        NREPLAYS            14
#define        SECONDS2DEMO        5

Sint8 getfirstPadInput(Uint16 *data, Uint16 *push, Uint16 *pull);
void checkExitHere(Uint16 data);
void waitRelease();
void waitKey(Uint16 key);


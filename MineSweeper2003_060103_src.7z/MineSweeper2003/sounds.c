#include "common.h"


#if defined(USE_PCM)

/* speech */
/* Note: unused speech causes black screen when used.
 * Maybe the binary is too big. */
#include "media/PCM/voice/champion.c"
#include "media/PCM/voice/draw.c"
#include "media/PCM/voice/goodwork.c"
//#include "media/PCM/voice/guessing.c"
#include "media/PCM/voice/loose.c"
//#include "media/PCM/voice/morebomb.c"
#include "media/PCM/voice/notbad.c"
#include "media/PCM/voice/player1.c"
#include "media/PCM/voice/player2.c"
#include "media/PCM/voice/toobad.c"
#include "media/PCM/voice/verygood.c"
#include "media/PCM/voice/welcome.c"
#include "media/PCM/voice/win.c"

/* applause */
#include "media/PCM/applause/applaus1.c"
#include "media/PCM/applause/applaus2.c"
#include "media/PCM/applause/applaus3.c"
#include "media/PCM/applause/applaus4.c"

/* SFX */
/* Note: the unused SFX were not to hear on Saturn,
 * reason unknown */
#include "media/PCM/SFX/bomb.c"
//#include "media/PCM/SFX/cursor.c"
#include "media/PCM/SFX/confirm.c"
//#include "media/PCM/SFX/choose.c"
//#include "media/PCM/SFX/leave.c"
#include "media/PCM/SFX/finished.c"
#include "media/PCM/SFX/nobomb.c"

#endif

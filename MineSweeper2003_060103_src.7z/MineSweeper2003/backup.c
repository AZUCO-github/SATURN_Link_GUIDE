#include <SGL.H>
#include "common.h"
#include <sega_bup.h>
#include "board.h"
#include "replay.h"
#include "hscfdata.h"
#include "RockinVR.h"
#include "backup.h"


/* This is to init backup library
 * Note that SGL demo got a terrible error 
 * that can cause to damage controller access during gameplay:
 * Always keep these two array as global variables. */
Uint32	BackUpRamWork[2048];
Uint8     BackUpLibSpace[16384];


Sint32 initBackupData()
{
     BupConfig cntb[3];
     BupStat stat;
     BupDir dir;
     Sint32 ret;
     Uint32 length;
     Uint8 *ptr;

     // First prepare the backup library for usage
     BackUpInit(cntb);

     // check if the System Memory is initialized
     while(BUP_Stat(SYSTEM_MEMORY, 0, &stat) != 0)
     {
          // ask to format
          if(dialog(12, 15, 6, 0, 2, "Rockin'-B's MineSweeper", 8, 2, "for SEGA Saturn", 12, 3, "A, START - select", 10, 5, "The System Memory is not ready for use.", 1, 7, "Do you want to clear all files in", 3, 8, "System Memory? Are you sure?", 6, 9, "Yes", "No") != 0)
               return ERROR_BACKUP_MEMORY;

          // format
          ret = BackUpFormat(SYSTEM_MEMORY);
          
          clearScreen();
          
          switch(ret)
          {
               case(0):
                    slPrint("Cleared all files in System Memory.", slLocate(2,15));
                    break;
               case(BUP_WRITE_PROTECT):
                    slPrint("The System Memory is write protected.", slLocate(1,15));
                    break;
               default:
                    slPrint("Failed to clear all files in", slLocate(6,15));
                    slPrint("System Memory.", slLocate(13,16));
                    break;
          }
          slPrint("Press Start Button", slLocate(11,18));
          waitKey(PRESSED_PAD_START);

          if(ret != 0)
               return ERROR_BACKUP_MEMORY;
     }

     clearScreen();
     
     // check if data exists in backup memory
     if(BUP_Dir(SYSTEM_MEMORY, MINESWEEPER_HSCF_FILENAME, 1, &dir) == 1)
     {
          // load that file
          ptr = BackupData;
          slResetDisable();
          ret = BUP_Read(SYSTEM_MEMORY, MINESWEEPER_HSCF_FILENAME, ptr);
          slResetEnable();

          /* verify data only on read success */
          if(ret == 0)
               ret = BUP_Verify(SYSTEM_MEMORY, MINESWEEPER_HSCF_FILENAME, ptr);          

          if(ret != 0)
          {
               switch(ret)
               {
                    case(BUP_BROKEN):
                         slPrint("The file could not be loaded!", slLocate(5,15));
                         break;
                    case(BUP_NO_MATCH):
                         slPrint("Failed loading file!", slLocate(5,15));
                         slPrint("Please restart the console.", slLocate(5,16));
                         break;
                    default:
                         slPrint("Error loading file.", slLocate(10,15));
                         break;
               }
               slPrint("Press Start Button", slLocate(11,18));
               waitKey(PRESSED_PAD_START);
               return ERROR_BACKUP_MEMORY;
          }
     }
     else
     {
          /* The backup file is not in System Memory,
           * save the default file.
           */
          ret = ((CF_DATA_LENGTH + HS_ENTRIES*HS_ENTRY_LENGTH) + 32) / 64;
          
          if(stat.freeblock >= ret)
               saveBackupData();
          else
          {
               slPrint("An additional ", slLocate(12,15));
               slPrintHex((ret - stat.freeblock), slLocate(26,15));               
               slPrint("blocks of free memory is required", slLocate(3,16));               
               slPrint("to save the game.", slLocate(11,17));               
               slPrint("Press Start Button", slLocate(11,18));
               waitKey(PRESSED_PAD_START);
               
               return ERROR_BACKUP_MEMORY;
          }     
     }

     return ERROR_OK;     
}



Sint32 saveBackupData()
{
     BupDir dir;
     Sint32 ret;
     Uint8 filename[12] = MINESWEEPER_HSCF_FILENAME;
     Uint8 comment[11] = MINESWEEPER_HSCF_COMMENT;

     // save the default file
               // file control data
     for(ret = 0; ret < 12; ret++)
     {
          dir.filename[ret] = filename[ret];
     }     
     for(ret = 0; ret < 11; ret++)
     {
               dir.comment[ret] = comment[ret];
     }     
     dir.language = BackupData[CF_LANGUAGE];
     dir.datasize = CF_DATA_LENGTH + HS_ENTRIES*HS_ENTRY_LENGTH;
               
     ret = BackUpWrite(SYSTEM_MEMORY, &dir, BackupData, OFF);

     /* verify data only on write success */
     if(ret == 0)
          ret = BUP_Verify(SYSTEM_MEMORY, MINESWEEPER_HSCF_FILENAME, BackupData);          

     if(ret != 0)
          return ERROR_BACKUP_MEMORY;
     else return ERROR_OK;     
}


void saveReplay(ReplayData *replay, Uint32 device, Uint8 player)
{
     BupDir dir[DIR_SIZE], tdir;
     BupStat stat;
     Sint32 ret, i;
     Uint8 *tfilename;     
     Bool found = FALSE;
     Uint8 nhigh = '0', nlow = '0';
     Uint8 filename[] = MINESWEEPER_REPLAY_FILENAME;
     Uint8 comment[] = MINESWEEPER_REPLAY_COMMENT;

     // check if enough memory is available
     if(BUP_Stat(device, (replay->length), &stat) != 0)
     {
          clearScreen();
          ret = (((replay->length) + 32) / 64);
          slPrint("An additional ", slLocate(12,15));
          slPrintHex((ret - stat.freeblock), slLocate(26,15));               
          slPrint("blocks of free memory is required", slLocate(3,16));               
          slPrint("to save the game.", slLocate(11,17));               
          slPrint("Press Start Button", slLocate(11,18));
          waitKey(PRESSED_PAD_START);
          return;
     }

     // handle 1 and 2 player replays
     ret = BUP_Dir(device, (Uint8 *)"", DIR_SIZE, dir);
     
     // search the existing filenames to determine new filename
     while(found == FALSE)
     {
          // select another filename
          if(nlow == '9')
          {
               nlow = '0';
               nhigh++;
          }
          else nlow++;
          // claim it's free
          found = TRUE;
               
          // check if this filename already exists
          for(i = 0; i < ret; i++)
          {
               // only look at filenames of MineSweeper replays
               tfilename = (Uint8 *)strtok(dir[i].filename, "_");
               if(strcmp(tfilename, MINESWEEPER_REPLAY_FILENAME) == 0) 
               {
                    // is this filename already used?
                    if((dir[i].filename[9] == nhigh) && (dir[i].filename[10] == nlow))
                         found = FALSE;
               }
          }
          
          /* if all filenames are used,
           * use the first
           */
          if((nhigh == '9') && (nlow == '9') && (found == FALSE))
          {
               nhigh = '0';
               nlow = '1';
               found = TRUE;
          }
     }
     
     // insert the default comment
     for(ret = 0; ret < 10; ret++)
     {
          tdir.comment[ret] = comment[ret];
     }
     tdir.comment[10] = '\0';
     // ask for comment
     get_name("Add your comment to the replay:", 10, tdir.comment, player);

     // insert the filename
     for(ret = 0; ret < 8; ret++)
     {
          tdir.filename[ret] = filename[ret];
     }
     tdir.filename[8] = '_';     
     tdir.filename[9] = nhigh;
     tdir.filename[10] = nlow;
     tdir.filename[11] = '\0';
     
     tdir.language = BackupData[CF_LANGUAGE];
     tdir.datasize = replay->length;
               
     ret = BackUpWrite(device, &tdir, replay->start, ON);

     /* verify data only on write success */
     if(ret == 0)
          ret = BUP_Verify(device, tdir.filename, replay->start);          
          
     clearScreen();
     if(ret != 0)
     {
          slPrint("Error saving file.", slLocate(11,15));
          slPrint(tdir.filename, slLocate(11,16));
     }
     else slPrint("Saving complete.", slLocate(12,15));         

     slPrint("Press Start Button", slLocate(11,18));
     waitKey(PRESSED_PAD_START);

     return;
}



Sint32 loadReplay(ReplayData *replay)
{
     Sint8 item, selected;
     char filename[11];
     Uint8 *data;
     Uint32 length;
     Sint32 ret;
     
     selected = 0;
     while(1)
     {
          item = dialog(10, 15, 3, selected, 4, "Rockin'-B's MineSweeper", 8, 2, "for SEGA Saturn", 12, 3, "A, START - select", 11, 5, "System Memory", "Cartridge Memory", "External Device", "Exit");
          switch(item)
          {
               // System Memory
               case(0):
               // Cartridge Memory
               case(1):
               // External Device
               case(2):
               selected = item;
                    // first select filename
                    if(get_dir_MEM(LOAD_UNKNOWN, item, 11, filename) == ERROR_OK)
                    {
                         // check prefix
                         if(strncmp(filename, MINESWEEPER_REPLAY_FILENAME, 8) == 0)
                         {
                              // load that file
                              ret = BackUpRead(item, filename, &data, &length);
                              /* verify data only on read success */
                              if(ret == 0)
                                   ret = BUP_Verify(item, filename, data);
                                             
                              if(ret != 0)
                              {
                                   clearScreen();
                                   switch(ret)
                                   {
                                        case(BUP_BROKEN):
                                             slPrint("The file could not be loaded.", slLocate(5,15));
                                             break;
                                        default:
                                             slPrint("Error loading file.", slLocate(10,15));
                                             slPrint(filename, slLocate(10,16));
                                             break;
                                   }
                                   slPrint("Press Start Button", slLocate(11,18));
                                   waitKey(PRESSED_PAD_START);
                                   return ret;
                              }
                              else
                              {
                                   // set up replay data
                                   replay->scale = *(data + REPLAY_SCALE);
                                   replay->length = length;
                                   replay->maxframe = replay->scale * 31;
                                   replay->start = data;
                                   replay->current = replay->start + REPLAY_DATA_START((*replay));
                                   // rest is done by reInitReplay()
                                   return ERROR_OK;
                              }
                         }
                         else
                         {
                              clearScreen();
                              slPrint("Rockin'-B's MineSweeper", slLocate(8, 2));
                              slPrint("for SEGA Saturn", slLocate(12, 3));
                              slPrint("This file is not a replay:", slLocate(7,15));
                              slPrint(filename, slLocate(7,16));
                              waitRelease();
                              slPrint("Press Start Button", slLocate(11,18));
                              waitKey(PRESSED_PAD_START);
                         }
                    }
                    selected = 2;
                    break;
               case(3):
                    return ERROR_ABORTED;     
               default:
                    break;     
           }     
     }
}                                   



Sint32 BackUpRead(Uint32 device, Uint8 *filename, Uint8 **data, Uint32 *length)
{
     BupDir dir;
     Sint32 ret;

     /* first get file size */
     /* file not found */
     if((ret = BUP_Dir(device, filename, 1, &dir)) == 0) { return ret; }

     /* allocate memory buffer */
     /* not enough memory */
     if((*(data) = (Uint8 *)malloc((dir.datasize + 1) * sizeof(Uint8))) == NULL) { return NO_MEMORY; }

	slResetDisable();
	ret = BUP_Read(device, filename, *(data));
	slResetEnable();
 
     /* give back filesize */
     *(length) = dir.datasize;

	return(ret);
}



/* taken from sgl sample 13-1 */

void	BackUpInit(BupConfig cntb[3] )
{
	slResetDisable();
	BUP_Init((Uint32 *)BackUpLibSpace,BackUpRamWork,cntb);
	slResetEnable();
}



Sint32	BackUpWrite(Uint32 device, BupDir *dir, Uint8 *data, Uint8 sw)
{
	Sint32		ret;
	SmpcDateTime	*time;
	BupDate		date;
	
	if(!dir->date){
		time = &(Smpc_Status->rtc);
		date.year  = (Uint8 )( slDec2Hex((Uint32)time->year)-1980 ); /* Modify K.T */
		date.month = (Uint8 )( time->month & 0x0f);
		date.week  = (Uint8 )( time->month >> 4  );
		date.day   = (Uint8 )( slDec2Hex((Uint32)time->date));   /* Modify K.T */
		date.time  = (Uint8 )( slDec2Hex((Uint32)time->hour));   /* Modify K.T */
		date.min   = (Uint8 )( slDec2Hex((Uint32)time->minute)); /* Modify K.T */
		dir->date = BUP_SetDate(&date);
	}
	slResetDisable();
	ret = BUP_Write(device,dir,data,sw);
	slResetEnable();

	return(ret);
}



Sint32	BackUpDelete(Uint32 device,Uint8 *filename)
{
	Sint32	ret;

	slResetDisable();
	ret = BUP_Delete(device,filename);
	slResetEnable();

	return(ret);
}



Sint32	BackUpFormat(Uint32 device)
{
	Sint32	ret;

	slResetDisable();
	ret = BUP_Format(device);
	slResetEnable();

	return(ret);
}


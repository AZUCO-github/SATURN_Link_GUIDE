/* multi language system
 * idea discarded.... */
#define        DEUTSCH                       0
#define        FRANCAIS                      1
#define        ENGLISH                       2



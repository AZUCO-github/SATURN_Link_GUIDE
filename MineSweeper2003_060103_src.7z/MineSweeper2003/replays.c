#include <sgl.h>

Uint8 replay01[] = {
#include "media/replays/MSR01.h"
};
Uint8 replay02[] = {
#include "media/replays/MSR02.h"
};
Uint8 replay03[] = {
#include "media/replays/MSR03.h"
};
Uint8 replay04[] = {
#include "media/replays/MSR04.h"
};
Uint8 replay05[] = {
#include "media/replays/MSR05.h"
};
Uint8 replay06[] = {
#include "media/replays/MSR06.h"
};
Uint8 replay07[] = {
#include "media/replays/MSR07.h"
};
Uint8 replay08[] = {
#include "media/replays/MSR08.h"
};
Uint8 replay09[] = {
#include "media/replays/MSR09.h"
};
Uint8 replay10[] = {
#include "media/replays/MSR10.h"
};
Uint8 replay11[] = {
#include "media/replays/MSR11.h"
};
Uint8 replay12[] = {
#include "media/replays/MSR12.h"
};
Uint8 replay13[] = {
#include "media/replays/MSR13.h"
};
Uint8 replay14[] = {
#include "media/replays/MSR14.h"
};

Uint8 *replays[] = {
     replay01,
     replay02,
     replay03,
     replay04,
     replay05,
     replay06,
     replay07,
     replay08,
     replay09,
     replay10,
     replay11,
     replay12,
     replay13,
     replay14
};



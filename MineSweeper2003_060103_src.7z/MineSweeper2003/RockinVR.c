/* contains little modified things from Rockin'-VR's file browser */

#include <SGL.H>
#include <STDARG.H>
#include <sega_bup.h>
#include "RockinVR.h"
#include "replay.h"
#include "backup.h"
#include "common.h"


#if defined(USE_PCM)

/* SFX */
extern Uint8 confirm[];
extern Uint32 confirm_size;
extern PCM confirm_dat ;

#endif



/* this prototype allows a dialog to the user 
 * parameter format:
 * <number of strings + x_pos + y_pos>, <number of items>, <string for display> <x-position> <y-position>, ....., <item0>, .... */
Sint8 dialog(Uint8 posX, Uint8 posY, Uint8 strings, Sint8 selected, Uint8 items,...)
{
     Uint16 push;
     va_list args;
     Sint8 *string, *item_name;
     Uint8 x_pos, y_pos;
     Uint8 i;
     Uint8 item;

     // look if a value is pre-selected
     if(selected == -1)
          item = 0;
     else item = selected;     
     
     clearScreen();

     va_start(args, items);

     /* draw gui */
     /* background strings */
     for(i = 0; i < strings; i++)
     {
          /* get it out of the variable argument list */
          string = va_arg(args, Sint8 *);
//          x_pos = va_arg(args, Uint8);
//          y_pos = va_arg(args, Uint8);
          x_pos = va_arg(args, int);
          y_pos = va_arg(args, int);
          /* display it */
          slPrint(string, slLocate(x_pos, y_pos)); 
     }
     /* menu items */
     for(i = 0; i < items; i++)
     {
          /* get it out of the variable argument list */
          item_name = va_arg(args, Sint8 *);
          /* display it */
          slPrint(item_name, slLocate(posX + 3, posY + i)); 
     }
     /* cursor */
     slPrint("->", slLocate(posX, posY + item));     
     
     va_end(args);
     
     /* get the controller data */
//     if(!Per_Connect1)
//     {
//          slPrint("No Controler!", slLocate(10, 30));
//          return ERROR_NO_CONTROLLER;
//     }
     
     /* loop controller inputs */
     waitRelease();
     while(1)
     {
          getfirstPadInput(NULL, &push, NULL);
//          push = Smpc_Peripheral[0].push;

          /* examine the pressed keys */
          if(push != PRESSED_PAD_NOTHING)
          {
               switch(push)
               {
                    case(PRESSED_PAD_UP):
                         /* item up */
                         slPrint("  ", slLocate(posX, posY + item));
                         if(item == 0) item = (items - 1);
                         else item--; 
                         slPrint("->", slLocate(posX, posY + item));
                         break;     
                    case(PRESSED_PAD_DOWN):
                         /* item down */
                         slPrint("  ", slLocate(posX, posY + item));
                         if(item == (items - 1)) item = 0; 
                         else item++; 
                         slPrint("->", slLocate(posX, posY + item));
                         break;     
                    case(PRESSED_PAD_B):
                         /* leave */
                         return selected;
                    case(PRESSED_PAD_A):
                         /* select item */
                    case(PRESSED_PAD_C):
                         /* select item */
                    case(PRESSED_PAD_START):     
#if defined(USE_PCM)
                         /* play confirm sound */
                         slPCMOn(&confirm_dat , confirm , confirm_size);
#endif          
                         return item;
               }
          }
          slSynch();
     }
}


void get_name(Uint8 *instructions, Uint8 length, Uint8 *target, Uint8 player) 
{
     Uint16 push;
//     Uint8 name[length + 1];
     Uint8 name_length = length;
     Uint8 item_x = 0, item_y = 0;
     
     Sint8 chartbl[8][8] =    {{'A','B','C','D','E','F','G','H'},
                              {'I','J','K','L','M','N','O','P'},
                              {'Q','R','S','T','U','V','W','X'},
                              {'Y','Z','a','b','c','d','e','f'},
                              {'g','h','i','j','k','l','m','n'},
                              {'o','p','q','r','s','t','u','v'},
                              {'w','x','y','z','0','1','2','3'},
                              {'4','5','6','7','8','9','_','.'},};

     /* reserve required space */
//     if(!(name = (Sint8 *)malloc((length + 1) * sizeof(Sint8))))
//          return (Sint8 *)NULL;
//     *(name + length + 1) = '\0';

     *(target + length) = '\0';
     
     /* search cursor position:
      * place it behind the existing name */
      while(((name_length - 1) >= 0) && (*(target + name_length - 1) == ' '))
      {
          name_length--;
      }
     
//     name[length] = '\0';
     clearScreen();
     
     /* draw gui */
     get_name_print_all(8, 8, chartbl, item_x, item_y, length - name_length, target, instructions);

     /* loop controller inputs */
     waitRelease();
     while(1)
     {
          // manage the user inputs
//          if(player == PLAYER_1)
//          {
////               if(!Per_Connect1)
////                    return ERROR_NO_CONTROLLER;
//               push = Smpc_Peripheral[0].push;
//          }
//          else if(player == PLAYER_2)
//          {
////               if(!Per_Connect2)
////                    return ERROR_NO_CONTROLLER;
//               push = Smpc_Peripheral[15].push;
//          }
          getfirstPadInput(NULL, &push, NULL);
          
          /* examine the pressed keys */
          if(push != PRESSED_PAD_NOTHING)
          {
               switch(push)
               {
                    case(PRESSED_PAD_UP):
                         /* item up */
                         if(item_y == 0) item_y = 7;
                         else item_y--;
                         get_name_print_cursor(8, 8, item_x, item_y);
                         break;
                    case(PRESSED_PAD_DOWN):
                         /* item down */
                         if(item_y == 7) item_y = 0;
                         else item_y++;
                         get_name_print_cursor(8, 8, item_x, item_y);
                         break;
                    case(PRESSED_PAD_LEFT):
                         /* item left */
                         if(item_x == 0) item_x = 7;
                         else item_x--;
                         get_name_print_cursor(8, 8, item_x, item_y);
                         break;
                    case(PRESSED_PAD_RIGHT):
                         /* item right */
                         if(item_x == 7) item_x = 0;
                         else item_x++;
                         get_name_print_cursor(8, 8, item_x, item_y);
                         break;
                    case(PRESSED_PAD_B):
                         /* delete one character */
                         if(name_length > 0)
                         {
                              //name[--name_length] = ' ';
                              *(target + --name_length) = ' ';
                              slPrint(target, slLocate(14, 7));
                              slPrintFX(toFIXED(length - name_length), slLocate(22, 9));
                         }     
                         break;
                    case(PRESSED_PAD_A):
                         /* select item */
                    case(PRESSED_PAD_C):
                         /* select item */
                         if(name_length < length)
                         {
                              //name[name_length++] = chartbl[item_y][item_x];
                              *(target + name_length++) = chartbl[item_y][item_x];
                              slPrint(target, slLocate(14, 7));
                              slPrintFX(toFIXED(length - name_length), slLocate(22, 9));
                         }
                         break;
                    case(PRESSED_PAD_START):
#if defined(USE_PCM)
                         /* play confirm sound */
                         slPCMOn(&confirm_dat , confirm , confirm_size);
#endif          
                         /* wait for release */
                         waitRelease();
                         return;
               }
          }
          slSynch();
     }
}


// error whith -O2
//void get_name_print_all(Uint8 dim_x, Uint8 dim_y, Sint8 chartbl[dim_y][dim_x], Uint8 item_x, Uint8 item_y, Uint8 charsleft, Uint8 *target, Uint8 *instructions)
void get_name_print_all(Uint8 dim_x, Uint8 dim_y, Sint8 chartbl[8][8], Uint8 item_x, Uint8 item_y, Uint8 charsleft, Uint8 *target, Uint8 *instructions)
{
//void get_name_print_all(Uint8 dim_x, Uint8 dim_y, Sint8 **chartbl, Uint8 item_x, Uint8 item_y, Uint8 charsleft, Uint8 *target, Uint8 *instructions)
//{
     Uint8 i, j;
     Sint8 sign[2] = {' ', '\0'};

     clearScreen();

     slPrint("Rockin'-B's MineSweeper", slLocate(8,2));

     slPrint(instructions, slLocate(5,5));
     slPrint(target, slLocate(14, 7));
     /* print menu */
     for(i = 0; i < dim_y; i++)
     {
          for(j = 0; j < dim_x; j++)
          {
               sign[0] = chartbl[i][j];
               slPrint(sign, slLocate(16 + j,13 + i));
          }
     }
     get_name_print_cursor(dim_x, dim_y, item_x, item_y);
     
     slPrint("characters left:", slLocate(5, 9));
     slPrintFX(toFIXED(charsleft), slLocate(22, 9));

     slPrint("Select character with D-Pad.", slLocate(5,25));
     slPrint("Press A,C to add one character", slLocate(5,26));
     slPrint("and B to remove the last.", slLocate(5,27));
     slPrint("Finish filename with START.", slLocate(5,28));

     return;
}



void get_name_print_cursor(Uint8 dim_x, Uint8 dim_y, Uint8 item_x, Uint8 item_y)
{
     Uint8 i,j;

     /* first delete the old cursor */
     for(i = 0; i < dim_y; i++)
     {
          slPrint(" ", slLocate(14, 13 + i)); 
     }
     for(j = 0; j < dim_x; j++)
     {
          slPrint(" ", slLocate(16 + j, 11)); 
     }

     /* then draw new one */
     slPrint("+", slLocate(14, 13 + item_y)); 
     slPrint("+", slLocate(16 + item_x, 11)); 
     
     return;
}



/* lets the user select a path and file from a given device and returns that */
Sint8 get_dir_MEM(Uint8 mode, Uint32 device, Uint8 length, Uint8 *target)
{
     /* the pad data */
     Uint16 data;
//     BupConfig conf[3];
     BupStat sttb;
     BupDir dirs[DIR_SIZE];
     Sint8 i, item;
     Uint8 files;
     
//     BackUpInit(conf);
     *(target + length) = '\0';
     
     /* look if unformated */
     if(BUP_Stat(device, 10, &sttb) == BUP_UNFORMAT)
     {
          /* ask to format */
          if(dialog(13, 15, 7, 1, 2, "Rockin'-B filebrowser",10,0,((device == SYSTEM_MEMORY)? "The Internal Memory": "The Backup Memory Cartridge"),5,2,"is unformated! To access the device,",5,3,"you have to format it first!",5,4,"Press UP/DOWN for option selection,",5,25,"confirm with A, C or START.",5,26,"Cancel with B.",5,27,"Yes", "No") == 0)
          {
               BackUpFormat(device);
               BUP_Stat(device, 10, &sttb);
          }
          else return ERROR_BACKUP_MEMORY;
     }
     files = BUP_Dir(device, (Uint8 *)"", DIR_SIZE, dirs);

     if(mode == LOAD_UNKNOWN)
          item = 0;
     else if(mode == SAVE_UNKNOWN)
               item = -1;
                    
     /* draw gui */     
     get_dir_print_all_MEM(mode, dirs, sttb, files, item, device);
    
     /* loop controller inputs */
     waitRelease();     
     while(1)
     {
          /* get the controller data */
          getfirstPadInput(&data, NULL, NULL);
//          data = Smpc_Peripheral[0].data;

          /* examine the pressed keys */
          if(data != PRESSED_PAD_NOTHING)
          {
               switch(data)
               {
                    case(PRESSED_PAD_UP):
                         /* item up */
                         if(item == 0 && mode == LOAD_UNKNOWN)
                              item = MIN(files - 1, DIR_SIZE - 1);
                         else if(item == -1 && mode == SAVE_UNKNOWN)
                                   item = MIN(files - 1, DIR_SIZE - 1);
                              else item--;
                         get_dir_print_files_MEM(mode, dirs, files, item);
                         break;
                    case(PRESSED_PAD_DOWN):
                         /* item down */
                         if(item == MIN(files - 1, DIR_SIZE - 1))
                         {
                              if(mode == LOAD_UNKNOWN) 
                                   item = 0;
                              else if(mode == SAVE_UNKNOWN)
                                        item = -1;
                         }
                         else item++;
                         get_dir_print_files_MEM(mode, dirs, files, item);
                         break;
                    case(PRESSED_PAD_A):
                         /* select item */
                    case(PRESSED_PAD_C):
                         /* select item */
                    case(PRESSED_PAD_START):     
#if defined(USE_PCM)
                         /* play confirm sound */
                         slPCMOn(&confirm_dat , confirm , confirm_size);
#endif          
                         if(item == -1)
                         {
                              /* enter new name */ 
                              get_name((Uint8 *)"Enter a filname!", length, target, PLAYER_1);
                              return ERROR_OK;
                         }
                         else
                         {
                              /* use name of existing file */
                              if(mode == SAVE_UNKNOWN)
                              {
                                   /* ask whether to overwrite existing file, use same name or to select another name */
                                   switch(dialog(13, 15, 7, 2, 3, "Rockin'-B filebrowser",10,0,"The selected filename already exists!",2,2,"On Saturn it's possible to have",2,3,"multiple files of the same name.",2,4,"Press UP/DOWN for option selection,",5,25,"confirm with A, C or START.",5,26,"Cancel with B.",5,27,"Overwrite", "Use same name", "Cancel"))
                                   {
                                        /* switch selected item */
                                        case(0):
                                             /* Overwrite */
                                             /* delete first */
                                             (void)BackUpDelete(device,dirs[item].filename);
                                             /* then return name */
                                        case(1):
                                             /* Use same name */
                                             (void)strcpy(target, dirs[item].filename);
                                             return ERROR_OK;
                                        case(2):
                                             /* Cancel */
                                             /* redraw gui */     
                                             get_dir_print_all_MEM(mode, dirs, sttb, files, item, device);
                                             break;
                                   }
                              }
                              else 
                              {
                                   (void)strcpy(target, dirs[item].filename);
                                   return ERROR_OK;
                              }     
                         }
                    case(PRESSED_PAD_B):
                         /* leave */
                         return ERROR_ABORTED;
               }
          }
          slSynch();
     }
}



void get_dir_print_all_MEM(Uint8 mode, BupDir dirs[], BupStat sttb, Uint8 files, Sint8 item, Uint32 device)
{
     clearScreen();

     slPrint("Rockin'-B filebrowser", slLocate(10, 0));

     slPrint("Select a file to ", slLocate(5, 2));
     if(mode == LOAD_UNKNOWN)
          slPrint("load from:", slLocate(22, 2));
     else slPrint("save to:", slLocate(22, 2));     
     if(device == SYSTEM_MEMORY)
          slPrint("Internal Memory", slLocate(5,3));
     else slPrint("Backup Memory Cartridge", slLocate(5,3));

     slPrint("filename:", slLocate(5,5));
     slPrint("description:", slLocate(17,5));
     slPrint("size:", slLocate(29,5));

     get_dir_print_files_MEM(mode, dirs, files, item);
     
     slPrint("Used blocks:", slLocate(5, 22));
     slPrintFX(toFIXED(sttb.totalblock - sttb.freeblock), slLocate(17, 22));
     slPrint("Free blocks:", slLocate(5, 23));
     slPrintFX(toFIXED(sttb.freeblock), slLocate(17, 23));

     slPrint("Press UP/DOWN for file selection,", slLocate(5,25));
     slPrint("confirm with A, C or START.", slLocate(5,26));
     slPrint("Cancel with B.", slLocate(5,27));

     return;
}



void get_dir_print_files_MEM(Uint8 mode, BupDir dirs[], Uint8 files, Sint8 item)
{
     Sint8 i;
     
     /* print cursor */
     slPrint("->", slLocate(2, 12));
     /* print 11 filenames */
     for(i = -5; i < 6; i++)
     {
          slPrint("           ", slLocate(5, 12 + i));
          slPrint("          ", slLocate(17, 12 + i));
          slPrint("        ", slLocate(29, 12 + i));
          /* print spaces for out of bounds filenames */
          if(((i + item) >= 0) && ((i + item) < DIR_SIZE) && ((i + item) < files))
          {
               slPrint(dirs[i + item].filename, slLocate(5, 12 + i));
               slPrint(dirs[i + item].comment, slLocate(17, 12 + i));
               slPrintFX(toFIXED(dirs[i + item].blocksize), slLocate(29, 12 + i));
          }
          else if((mode == SAVE_UNKNOWN) && ((i + item) == -1)) slPrint("New File", slLocate(5, 12 + i));
     }

     return;
}




/* fills the screen with spaces */
void clearScreen()
{
     int i, j;

     for(i = 0; i < 30; i++)
     {
          for(j = 0; j < 40; j++)
          {
               slPrint(" ", slLocate(j, i));
          }
     }
}


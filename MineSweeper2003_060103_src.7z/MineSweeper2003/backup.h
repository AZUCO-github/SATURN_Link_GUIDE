#ifndef USE_BACKUP
#define USE_BACKUP


/* devices */
/* Saturn */
#define        SYSTEM_MEMORY                 (Uint32)0
#define        CARTRIDGE_MEMORY              (Uint32)1
#define        EXTERNAL_DEVICE               (Uint32)2

/* error codes */
#define        UNFORMATED                    0
#define        FORMATED                      1
#define        WRONG_MODE                    0
#define        UNSUPPORTED_DEVICE            -1
#define        NO_FILENAME                   -2
#define        NO_PATH                       -3
#define        NO_DATA                       -4
#define        NO_MEMORY                     -5


/* we have only 99 replays, but there can be a lot of other files in memory,
 * especially using a cartridge */     
#define        DIR_SIZE            200


Sint32 initBackupData();
Sint32 saveBackupData();
void saveReplay(ReplayData *replay, Uint32 device, Uint8 player);
Sint32 loadReplay(ReplayData *replay);

Sint32 BackUpRead(Uint32 device, Uint8 *filename, Uint8 **data, Uint32 *length);

void	BackUpInit(BupConfig cntb[3]);
Sint32 BackUpWrite(Uint32 device, BupDir *dir, Uint8 *data, Uint8 sw);
Sint32 BackUpDelete(Uint32 device,Uint8 *filename);
Sint32 BackUpFormat(Uint32 device);

#endif

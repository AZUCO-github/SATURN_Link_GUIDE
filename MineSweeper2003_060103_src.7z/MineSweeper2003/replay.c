#include <SGL.H>
#include "common.h"
#include "replay.h"
#include "board.h"
#include "hscfdata.h"



int initReplay(ReplayData *replay, PlayingField *board, Uint8 name)
{
     Uint8 posX, posY;
     Uint16 bomb = 0;
     
     // first fill replay's variables
     replay->length = REPLAY_MINLENGTH(BackupData[CF_BOMBS]);
     replay->scale = BackupData[CF_REPLAY];
     replay->maxframe = replay->scale * 31;
     replay->curframe = 0;

     // then get memory for the backup array
     if((replay->start = (Uint8 *)malloc(REPLAY_MINLENGTH(BackupData[CF_BOMBS]) * sizeof(Uint8))) == NULL)
          return ERROR_OUT_OF_MEMORY;
          
     // and fill the start information of the backup array     
     *(replay->start + REPLAY_WIDTH) = BackupData[CF_WIDTH]; 
     *(replay->start + REPLAY_HEIGHT) = BackupData[CF_HEIGHT]; 
     *(replay->start + REPLAY_SCALE) = BackupData[CF_REPLAY]; 
     // insert player name
     for(posX = 0; posX <= CF_NAME_LENGTH; posX++)
     {
          *(replay->start + REPLAY_NAME + posX) = BackupData[name + posX];
     }
     // terminate player name string
     *(replay->start + REPLAY_NAME + CF_NAME_LENGTH) = '\0';
     
     *(replay->start + REPLAY_BOMBS) = BackupData[CF_BOMBS];
     // search and insert bombs position
     for(posY = 0; posY < board->height; posY++)
     {
          for(posX = 0; posX < board->width; posX++)
          {
               // check if we found a bomb here
               if((board->elements + ((int)posY*((int)(board->width))) + (int)posX)->isBomb == TRUE)
               {
                    *(replay->start + REPLAY_BOMBS + ++bomb) = posX;
                    *(replay->start + REPLAY_BOMBS + ++bomb) = posY;
               }
          }     
     }
      
     replay->current = replay->start + REPLAY_DATA_START((*replay));
     
     return ERROR_OK;
}



/* used when playing replays */
void reInitReplay(ReplayData *replay)
{
     replay->current = replay->start + REPLAY_DATA_START((*replay));
     replay->curframe = (*(replay->current) & 0x1F) * replay->scale;
}



int deleteReplay(ReplayData *replay)
{
     replay->maxframe = 0;
     replay->curframe = 0;
     replay->scale = 0;
     replay->length = 0;
     free(replay->start);

     return ERROR_OK;
}



int handleReplay(ReplayData *replayP1, ReplayData *replayP2, Uint8 selected)
{
     Uint32 ret;
     Sint8 device;
     Bool shown = FALSE, saved = FALSE;
     
     waitRelease();
     
     while(1)
     {
          // what to select first?
          ret = dialog(12, 15, 3, selected, 3, "Rockin'-B's MineSweeper", 8, 2, "for SEGA Saturn", 12, 3, "A - select, B - exit", 10, 5, "Show Replay", "Save Replay", "Exit");
     
          switch(ret)
          {
               // show replay
               case(0):
                    if(replayP2 == (ReplayData *)NULL)
                         ret = playReplay1P(replayP1, FALSE);
                    else ret = playReplay2P(replayP1, replayP2, FALSE);     
                    if(ret != ERROR_OK)
                         return ret;
                    shown = TRUE;     
                    if(saved == FALSE)
                         selected = 1;
                    else selected = 2;     
                    break;
               // save replay
               case(1):
                    // ask where to save it
                    device = dialog(10, 15, 3, 0, 4, "Rockin'-B's MineSweeper", 8, 2, "for SEGA Saturn", 12, 3, "A, START - select, B - exit", 6, 5, "System Memory", "Cartridge Memory", "External Device", "Exit");
                    switch(device)
                    {
                         // System Memory
                         case(0):
                         // Cartridge Memory
                         case(1):
                         // External Device
                         case(2):
                              saveReplay(replayP1, device, PLAYER_1);
                              if(replayP2 != (ReplayData *)NULL)
                                   saveReplay(replayP2, device, PLAYER_2);
                              break;
                                   
                         default:
                              break;     
                    }     
                    saved = TRUE;
                    if(shown == FALSE)
                         selected = 0;
                    else selected = 2;     
                    break;
               // exit replay
               case(2):
                    if(replayP2 != (ReplayData *)NULL)
                    {
                         ret = deleteReplay(replayP2);
                         if(ret != ERROR_OK)
                              return ret;
                    }
                    return deleteReplay(replayP1);
          }
     }
}

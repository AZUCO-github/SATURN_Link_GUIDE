#include <SGL.H>
#include "common.h"
#include "board.h"
#include "hscfdata.h"
#include <sega_bup.h>
#include "RockinVR.h"
#include "play.h"

// !!!!!!! -Os required to work, otherwise SGL vars will be overwritten


#if defined(USE_PCM)

#include    "sddrvs.dat"
/* The game start voice included in sounds.c */
extern Uint8 welcome[];
extern Uint32 welcome_size;
extern PCM welcome_dat ;

#endif


/* The board sprites included in sprites.c */
extern TEXTURE tex_spr[];
extern PICTURE pic_spr[];
extern SPR_ATTR attr[];

/* The demo replays included in replays.c */
extern Uint8 *replays[];



/* taken from a SGL demo */
static void set_sprite(PICTURE *pcptr , Uint32 NbPicture)
{
	TEXTURE *txptr;
 
	for(; NbPicture-- > 0; pcptr++){
		txptr = tex_spr + pcptr->texno;
		slDMACopy((void *)pcptr->pcsrc,
			(void *)(SpriteVRAM + ((txptr->CGadr) << 3)),
			(Uint32)((txptr->Hsize * txptr->Vsize * 4) >> (pcptr->cmode)));
	}
}



/* taken from a SGL demo */
#if defined(USE_PCM)
void init_sound(){
    char sound_map[] = {0xff , 0xff} ;
    slInitSound(sddrvstsk , sizeof(sddrvstsk) , (Uint8 *)sound_map , sizeof(sound_map)) ;
}
#endif



void checkError(int code)
{
     // check for errors while playing
     switch(code)
     {
          case(ERROR_OK):
               break;
          case(ERROR_NO_CONTROLLER):
               slPrint("The controller is not plugged", slLocate(3, 25));
               slPrint("or has been removed!", slLocate(3, 26));
               break;
          case(ERROR_OUT_OF_MEMORY):
               slPrint("No memory available!", slLocate(10, 25));
               break;
          case(ERROR_BACKUP_MEMORY):
               slPrint("Backup memory error!", slLocate(10, 25));
               break;
          default:     
               slPrint("Unknown error occured!", slLocate(9, 25));
               break;
     }
}



/* selects the demos to play */
void selectReplay(ReplayData *replayP1, ReplayData *replayP2)
{
     int n;
     
     /* select a replay */
     n = slRandom();
     n = (int)(slMulFX(n, toFIXED(NREPLAYS-1)) / 65536.0);
     /* set up replay data */
     replayP1->scale = *(replays[n] + REPLAY_SCALE);
     replayP1->length = sizeof(replays[n]);
     replayP1->maxframe = replayP1->scale * 31;
     replayP1->start = replays[n];
     replayP1->current = replayP1->start + REPLAY_DATA_START((*replayP1));

     if(replayP2 != NULL)
     {
          /* don't need to call slRandom() twice,
           * this function has bad properties,
           * so avoid selecting the same replays this way. */
          n = NREPLAYS - 1 - n;
          /* set up replay data */
          replayP2->scale = *(replays[n] + REPLAY_SCALE);
          replayP2->length = sizeof(replays[n]);
          replayP2->maxframe = replayP2->scale * 31;
          replayP2->start = replays[n];
          replayP2->current = replayP2->start + REPLAY_DATA_START((*replayP2));
     }
     
     return;
}




/*   The Menu structure:
 *   start
 *        1 Player
 *        2 Player
 *        Replay
 *             system memory
 *             cartridge memory
 *             external device
 *             Exit
 *        Hiscores
 *        Manual
 *             How to play
 *             Highscores
 *             Replays #1
 *             Replays #2
 *             segaXtreme
 *             The Rockin'-B
 *             Exit
 *        Options
 *             width
 *             height
 *             bombs
 *             replay
 *             P1 name
 *             P2 name
 *             Exit
 *        Exit
 */


int chooseOptions()
{
     ReplayData replayP1, replayP2;
     
     int ret;
     Sint8 item = 0, selected = 0;

     while(1)
     {
          /* Top level: select if to play, set width, height or bombs or to exit */
          item = dialog(13, 15, 3, selected, 7, "Rockin'-B's MineSweeper", 8, 2, "for SEGA Saturn", 12, 3, "A, START - select", 11, 5, "1 Player", "2 Player", "Replay", "Highscores", "Manual", "Options", "Exit");
          if(item == 6)
               break;                    
          switch(item)
          {
               // 1 Player
               case(0):
                    ret = play1P(BackupData[CF_WIDTH], BackupData[CF_HEIGHT], BackupData[CF_BOMBS]);
                    // check for errors that occured while playing     
                    if(ret != ERROR_OK)
                         return ret;
                    selected = 0;     
                    break;

               // 2 Player
               case(1):
                    if(BackupData[CF_WIDTH] <= 9)
                    {
                         ret = playMatch(BackupData[CF_WIDTH], BackupData[CF_HEIGHT], BackupData[CF_BOMBS], BackupData[CF_MATCHES]);
                         // check for errors that occured while playing     
                         if(ret != ERROR_OK)
                              return ret;
                    }
                    else
                    {
                         clearScreen();
                         slPrint("Rockin'-B's MineSweeper", slLocate(8, 2));
                         slPrint("for SEGA Saturn", slLocate(12, 3));
                         slPrint("2 player game maximum", slLocate(13,14));
                         slPrint("playingfield width is 9!", slLocate(6,15));
                         slPrint("Press Start Button", slLocate(11,18));
                         waitKey(PRESSED_PAD_START);
                    }          
                    selected = 1;     
                    break;

               // Replay
               case(2):
                    selected = 0;
                    while(1)
                    {
                         item = dialog(11, 15, 3, selected, 3, "Rockin'-B's MineSweeper", 8, 2, "for SEGA Saturn", 12, 3, "A, START - select", 11, 5, "1P Replay", "2P Replay", "Exit");
                         if(item == 2)
                              break;
                         switch(item)
                         {
                              // 1P Replay
                              case(0):
                                   // play the replay
                                   if(loadReplay(&replayP1) == ERROR_OK)
                                   {
                                        playReplay1P(&replayP1, FALSE);
                                        deleteReplay(&replayP1);
                                        selected = 0;
                                   }
                                   else
                                   {
                                        selected = 2;
                                   }
                                   break;
                                   
                              // 2P Replay
                              case(1):
                                   // play the replays
                                   if(loadReplay(&replayP1) == ERROR_OK)
                                   {
                                        if(loadReplay(&replayP2) == ERROR_OK)
                                        {
                                             playReplay2P(&replayP1, &replayP2, FALSE);
                                             deleteReplay(&replayP2);
                                        }
                                        deleteReplay(&replayP1);
                                        selected = 1;
                                   }
                                   else
                                   {
                                        selected = 2;
                                   }
                                   break;
                                   
                              default:
                                   break;     
                         }     
                    }
                    selected = 2;     
                    break;
               // hiscores
               case(3):
                    displayHighscores(0, FALSE);
                    selected = 3;     
                    break;
               // Manual
               case(4):
                    selected = 0;
                    while(1)
                    {
                         item = dialog(11, 15, 3, selected, 8, "Rockin'-B's MineSweeper", 8, 2, "for SEGA Saturn", 12, 3, "A, START - select", 11, 5, "How to play", "2P Matches", "Highscores", "Replays #1", "Replays #2", "segaXtreme", "The Rockin'-B", "Exit");
                         if(item == 7)
                              break;
                         switch(item)
                         {
                              // How to play
                              case(0):
                                   clearScreen();
                                   slPrint("Rockin'-B's MineSweeper", slLocate(8, 2));
                                   slPrint("for SEGA Saturn", slLocate(12, 3));
                                   slPrint("You start with a covered playing", slLocate(4,5));
                                   slPrint("field. There is a certain number", slLocate(4,6));
                                   slPrint("of bombs/mines hidden in the field.", slLocate(4,7));
                                   slPrint("The goal is to uncover all regions", slLocate(4,8));
                                   slPrint("where no bombs are covered as fast", slLocate(4,9));
                                   slPrint("as possible. Select the region to", slLocate(4,10));
                                   slPrint("uncover by either guessing or", slLocate(4,11));
                                   slPrint("thinking. Use the number of", slLocate(4,12));
                                   slPrint("uncovered regions as a hint for", slLocate(4,13));
                                   slPrint("the number of bombs surrounding", slLocate(4,14));
                                   slPrint("that region.", slLocate(4,15));

                                   slPrint("Adjust the playing field width,", slLocate(4,17));
                                   slPrint("height and number of hidden bombs", slLocate(4,18));
                                   slPrint("in the Options menu.", slLocate(4,19));

                                   slPrint("The keys:", slLocate(4,21));
                                   slPrint("D-pad      - cursor movement", slLocate(4,22));
                                   slPrint("A/C-button - uncover", slLocate(4,23));
                                   slPrint("B-button   - mark", slLocate(4,24));
                                   
                                   waitRelease();
                                   slPrint("Press Start Button", slLocate(11,29));
                                   waitKey(PRESSED_PAD_START);
                                   selected = 1;
                                   break;

                              // 2P matches
                              case(1):
                                   clearScreen();
                                   slPrint("Rockin'-B's MineSweeper", slLocate(8, 2));
                                   slPrint("for SEGA Saturn", slLocate(12, 3));
                                   slPrint("In a 2 player match, you and", slLocate(4,5));
                                   slPrint("your opponent play a number of", slLocate(4,6));
                                   slPrint("rounds against each other in real", slLocate(4,7));
                                   slPrint("time. Both have to try to uncover", slLocate(4,8));
                                   slPrint("all of the board but the bombs as", slLocate(4,9));
                                   slPrint("fast as possible and of course", slLocate(4,10));
                                   slPrint("faster than the opponent. But", slLocate(4,11));
                                   slPrint("don't risc too much because when", slLocate(4,12));
                                   slPrint("you explode, you will be punished", slLocate(4,13));
                                   slPrint("and your opponent benefits from", slLocate(4,14));
                                   slPrint("that.", slLocate(4,15));

                                   slPrint("The player who wins a round gets", slLocate(4,17));
                                   slPrint("1 point added. And if a player", slLocate(4,18));
                                   slPrint("explodes, he gets 2 points subtracted", slLocate(4,19));
                                   
                                   slPrint("After all rounds have been played,", slLocate(4,21));
                                   slPrint("the player with the highest points", slLocate(4,22));
                                   slPrint("wins the match.", slLocate(4,23));

                                   slPrint("Fair play guaranteed!", slLocate(4,25));
                                   
                                   waitRelease();
                                   slPrint("Press Start Button", slLocate(11,29));
                                   waitKey(PRESSED_PAD_START);
                                   selected = 2;
                                   break;
                                   
                              // Highscores
                              case(2):
                                   clearScreen();
                                   slPrint("Rockin'-B's MineSweeper", slLocate(8, 2));
                                   slPrint("for SEGA Saturn", slLocate(12, 3));
                                   slPrint("The highscore table is very large,", slLocate(4,5));
                                   slPrint("so even after hours of playing,", slLocate(4,6));
                                   slPrint("you will still be able to get into", slLocate(4,7));
                                   slPrint("the highscores. All games with all", slLocate(4,8));
                                   slPrint("possible width, height and bombs", slLocate(4,9));
                                   slPrint("settings are placed there. The", slLocate(4,10));
                                   slPrint("rank is computed via an appropriate", slLocate(4,11));
                                   slPrint("formula of width, height, bombs and", slLocate(4,12));
                                   slPrint("time.", slLocate(4,13));
                                   
                                   slPrint("If you won a game, your game is", slLocate(4,15));
                                   slPrint("checked if it's a new highscore", slLocate(4,16));
                                   slPrint("entry. And if that's the case, you", slLocate(4,17));
                                   slPrint("can change/enter your name and see", slLocate(4,18));
                                   slPrint("your rank.", slLocate(4,19));
                                   
                                   slPrint("Have a look at the highscore table", slLocate(4,21));
                                   slPrint("whenever you want by selecting", slLocate(4,22));
                                   slPrint("Highscores in the main menu.", slLocate(4,23));

                                   slPrint("The better one wins!", slLocate(4,25));
                                   
                                   waitRelease();
                                   slPrint("Press Start Button", slLocate(11,29));
                                   waitKey(PRESSED_PAD_START);
                                   selected = 3;
                                   break;

                              // Replays #1
                              case(3):
                                   clearScreen();
                                   slPrint("Rockin'-B's MineSweeper", slLocate(8, 2));
                                   slPrint("for SEGA Saturn", slLocate(12, 3));
                                   slPrint("Every game you play is recorded as", slLocate(4,5));
                                   slPrint("a replay. After the game, you can", slLocate(4,6));
                                   slPrint("watch your play again and even", slLocate(4,7));
                                   slPrint("save it to System Memory or to", slLocate(4,8));
                                   slPrint("Cartridge Memory. Up to 99 replays", slLocate(4,9));
                                   slPrint("can be saved. Share your highscore", slLocate(4,10));
                                   slPrint("replays with friends via netlink", slLocate(4,11));
                                   slPrint("email, AR 4M Plus and a PC or", slLocate(4,12));
                                   slPrint("memory carts. Even 2 player replays", slLocate(4,13));
                                   slPrint("can be saved as two 1 player replays.", slLocate(4,14));
                                   slPrint("All saved replays can be watched as", slLocate(4,15));
                                   slPrint("1 player replay or 2 player replay,", slLocate(4,16));
                                   slPrint("if you combine two of them.", slLocate(4,17));
                                   
                                   slPrint("Replays don't take up much memory,", slLocate(4,19));
                                   slPrint("even if the game lasts minutes.", slLocate(4,20));
                                   slPrint("You can control memory consumption", slLocate(4,21));
                                   slPrint("by setting the replay variable", slLocate(4,22));
                                   slPrint("in the Options menu.", slLocate(4,23));
                                   slPrint("It's a trade-off between accuracy", slLocate(4,24));
                                   slPrint("and memory space. Select high", slLocate(4,25));
                                   slPrint("accuracy for fast players and low", slLocate(4,26));
                                   slPrint("for long games.", slLocate(4,27));
                                   
                                   waitRelease();
                                   slPrint("Press Start Button", slLocate(11,29));
                                   waitKey(PRESSED_PAD_START);
                                   selected = 4;
                                   break;

                              // Replays #2
                              case(4):
                                   clearScreen();
                                   slPrint("Rockin'-B's MineSweeper", slLocate(8, 2));
                                   slPrint("for SEGA Saturn", slLocate(12, 3));
                                   slPrint("The replays are encoded such that", slLocate(4,5));
                                   slPrint("even zip compression wouldn't", slLocate(4,6));
                                   slPrint("make them smaller in file size.", slLocate(4,7));
                                   slPrint("But the encoding is lossy, as", slLocate(4,8));
                                   slPrint("told before about accuracy.", slLocate(4,9));
                                   slPrint("This means: replay timing will", slLocate(4,10));
                                   slPrint("not match the original game", slLocate(4,11));
                                   slPrint("exactly.", slLocate(4,12));

                                   slPrint("Okay, they could match exactly,", slLocate(4,14));
                                   slPrint("but you can not adjust the proper", slLocate(4,15));
                                   slPrint("replay scale value for this.", slLocate(4,16));
                                   slPrint("It wouldn't be worth it to waste", slLocate(4,17));
                                   slPrint("so much space.", slLocate(4,18));
                                   
                                   slPrint("So keep this in mind when you", slLocate(4,20));
                                   slPrint("combine 2 winning replays that", slLocate(4,21));
                                   slPrint("should result in a draw game,", slLocate(4,22));
                                   slPrint("but they don't because one", slLocate(4,23));
                                   slPrint("replay wins first over the", slLocate(4,24));
                                   slPrint("other.", slLocate(4,25));
                                   
                                   waitRelease();
                                   slPrint("Press Start Button", slLocate(11,29));
                                   waitKey(PRESSED_PAD_START);
                                   selected = 5;
                                   break;

                              // segaXtreme
                              case(5):
                                   clearScreen();
                                   slPrint("Rockin'-B's MineSweeper", slLocate(8, 2));
                                   slPrint("for SEGA Saturn", slLocate(12, 3));
                                   slPrint("This game is a contribution to the", slLocate(4,5));
                                   slPrint("segaXtreme coding contest 2003:", slLocate(4,6));
                                   slPrint("http://www.litespeedcomputers.com/sx/", slLocate(4,7));

                                   slPrint("I want to thank all people there", slLocate(4,9));
                                   slPrint("asking interesting questions and", slLocate(4,10));
                                   slPrint("giving very helpful answers.", slLocate(4,11));
                                   slPrint("This contest really is the first", slLocate(4,12));
                                   slPrint("of it's kind for the SEGA Saturn,", slLocate(4,13));
                                   slPrint("a milestone in Saturn homebrew", slLocate(4,14));
                                   slPrint("development. I really look forward", slLocate(4,15));
                                   slPrint("to the other contributions,", slLocate(4,16));
                                   slPrint("we will give kind of a rebirth", slLocate(4,17));
                                   slPrint("to the SEGA Saturn system.", slLocate(4,18));

                                   slPrint("And most promising for the future:", slLocate(4,20));
                                   slPrint("I bet everyone of us got secret", slLocate(4,21));
                                   slPrint("projects that nobody knows of.", slLocate(4,22));
                                   slPrint("So be aware...", slLocate(4,23));
                                   
                                   waitRelease();
                                   slPrint("Press Start Button", slLocate(11,29));
                                   waitKey(PRESSED_PAD_START);
                                   selected = 6;
                                   break;

                              // The Rockin'-B
                              case(6):
                                   clearScreen();
                                   slPrint("Rockin'-B's MineSweeper", slLocate(8, 2));
                                   slPrint("for SEGA Saturn", slLocate(12, 3));
                                   slPrint("My homepage dedicated to SEGA", slLocate(4,5));
                                   slPrint("console development:", slLocate(4,6));
                                   slPrint("http://www.Rockin-B.de", slLocate(4,7));

                                   slPrint("As for SEGA Saturn, I worked over", slLocate(4,9));
                                   slPrint("6 month on Rockin'-VR, a VRML", slLocate(4,10));
                                   slPrint("viewer that allows interactive", slLocate(4,11));
                                   slPrint("3D worlds and games to be explored", slLocate(4,12));
                                   slPrint("and developed on SEGA Saturn.", slLocate(4,13));
                                   slPrint("Although the project is paused,", slLocate(4,14));
                                   slPrint("I can say:", slLocate(4,15));
                                   slPrint("I never loose my sources ;-).", slLocate(4,16));
                                   
                                   slPrint("And there is the Visual Memory,", slLocate(4,18));
                                   slPrint("handheld videogame and memory", slLocate(4,19));
                                   slPrint("cartridge of the Dreamcast.", slLocate(4,20));
                                   slPrint("I did a lot of hard in-depth", slLocate(4,21));
                                   slPrint("assembler libraries and demos:", slLocate(4,22));
                                   slPrint("B-movie;) - compressed animation", slLocate(4,23));
                                   slPrint("player/encoder", slLocate(4,24));
                                   slPrint("greyscale - more realistic images,", slLocate(4,25));
                                   slPrint("viewer and conversion", slLocate(4,26));
                                   slPrint("Tiny 3D engine - unbelievable, eh?", slLocate(4,27));
                                   
                                   waitRelease();
                                   slPrint("Press Start Button", slLocate(11,29));
                                   waitKey(PRESSED_PAD_START);
                                   selected = 7;
                                   break;

                              default:
                                   break;     
                         }     
                    }
                    selected = 4;     
                    break;
               // Options
               case(5):
                    selected = 0;
                    while(1)
                    {
                         item = dialog(14, 15, 3, selected, 8, "Rockin'-B's MineSweeper", 8, 2, "for SEGA Saturn", 12, 3, "A, START - select", 11, 5, "Width", "Height", "Bombs", "Replay", "Matches", "P1 Name", "P2 Name", "Exit");
                         if(item == 7)
                              break;
                         switch(item)
                         {
                              // width
                              case(0):
                                   BackupData[CF_WIDTH] = 5 + (Uint8)dialog(16, 10, 4, (BackupData[CF_WIDTH]-5), 15, "Rockin'-B's MineSweeper", 8, 2, "for SEGA Saturn", 12, 3, "Choose the playing field width:", 4, 5, "A, START - select, B - no change", 4, 7, "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19");
                                   selected = 0;
                                   break;

                              // height
                              case(1):
                                   BackupData[CF_HEIGHT] = 5 + (Uint8)dialog(16, 12, 4, (BackupData[CF_HEIGHT]-5), 11, "Rockin'-B's MineSweeper", 8, 2, "for SEGA Saturn", 12, 3, "Choose the playing field height:", 4, 5, "A, START - select, B - no change", 4, 7, "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15");
                                   selected = 1;
                                   break;
                                   
                              // bombs
                              case(2):
                                   /* no linear bomb selection
                                    * place cursor on correct position */
                                   selected = BackupData[CF_BOMBS];
                                   if(selected <= 10)
                                        selected = BackupData[CF_BOMBS] - 5;
                                   else if(selected <= 20)
                                             selected = BackupData[CF_BOMBS] / 2;
                                        else selected = (10 + BackupData[CF_BOMBS]) / 3;              
                                   selected =  (Uint8)dialog(16, 10, 4, selected, 16, "Rockin'-B's MineSweeper", 8, 2, "for SEGA Saturn", 12, 3, "Choose the playing field bombs:", 4, 5, "A, START - select, B - no change", 4, 7, "5", "6", "7", "8", "9", "10", "12", "14", "16", "18", "20", "23", "26", "29", "32", "35");
                                   if(selected <= 5)
                                        BackupData[CF_BOMBS] = selected + 5;
                                   else if(selected <= 10)
                                             BackupData[CF_BOMBS] = selected * 2;
                                        else BackupData[CF_BOMBS] = selected * 2 + (selected-10);              
                                   selected = 2;
                                   /* don't select more bombs than the playingfield got 
                                    * instead select playable bomb amount */
                                   if(BackupData[CF_BOMBS] > BackupData[CF_WIDTH] * BackupData[CF_HEIGHT])
                                        BackupData[CF_BOMBS] = (BackupData[CF_WIDTH] * BackupData[CF_HEIGHT]) / 4;     
                                   break;
                              // replay
                              case(3):
                                   BackupData[CF_REPLAY] = (2 * (1 + (Uint8)dialog(13, 15, 5, ((BackupData[CF_REPLAY] / 2) - 1), 8, "Rockin'-B's MineSweeper", 8, 2, "for SEGA Saturn", 12, 3, "Choose the replay accuracy:", 4, 5, "actions per second | seconds per byte", 2, 6, "A, START - select, B - no change", 4, 8, "15.0 |  2.1", " 7.5 |  4.3", " 5.0 |  6.4", " 3.8 |  8.5", " 3.0 | 10.6", " 2.5 | 12.8", " 2.1 | 14.9", " 1.9 | 17.1")));
                                   selected = 3;
                                   break;
                              // matches
                              case(4):
                                   BackupData[CF_MATCHES] = (1 + (2 * (Uint8)dialog(13, 15, 5, ((BackupData[CF_MATCHES] - 1) / 2), 10, "Rockin'-B's MineSweeper", 8, 2, "for SEGA Saturn", 12, 3, "Choose the number of", 10, 5, "2 player matches:", 12, 6, "A, START - select, B - no change", 4, 8, " 1", " 3", " 5", " 7", " 9", "11", "13", "15", "17", "19")));
                                   selected = 4;
                                   break;
                              // player 1 name
                              case(5):
                                   get_name("Player 1 name:", CF_NAME_LENGTH, &BackupData[CF_P1_NAME], PLAYER_1);
                                   selected = 5;
                                   break;
                              // player 2 name
                              case(6):
                                   get_name("Player 2 name:", CF_NAME_LENGTH, &BackupData[CF_P2_NAME], PLAYER_2);
                                   selected = 6;
                                   break;
                              default:
                                   break;     
                         }
                    }
                    saveBackupData();     
                    selected = 5;     
                    break;
               default:
                    break;                              
          }     
     }
     return ERROR_OK;
}



void ss_main(void)
{
     Uint16 push;
     int ret;
     ReplayData replayP1, replayP2;
     Uint8 n[3];
     Uint32 frame = 0;
     
     slInitSystem(TV_320x240, tex_spr, FPS_DIV);

#if defined(USE_PCM)
     init_sound();
#endif

     set_sprite(pic_spr, 12);
     
     initBackupData();     
                    
     /* check if controller plugged */ 
     if(Per_Connect1)
     {
#if defined(USE_PCM)
          /* say hello! */
          slPCMOn(&welcome_dat , welcome , welcome_size);
#endif          
          waitRelease();

          /* game can start */
          while(1)
          {
               /* check if to play a demo */
               if((frame / FPS) == SECONDS2DEMO)
               {
                    /* decide randomly whether to show single or two player demo */
                    ret = slRandom();
                    ret = (int)(ret & 0x8000);
#if defined(USE_PCM)
                    /* wait untill sound ends */
                    while(slPCMStat(&welcome_dat)) { slSynch(); }
#endif          
                    if(ret == 0)
                    {
                         /* 1 player demo */
                         selectReplay(&replayP1, NULL);
                         ret = playReplay1P(&replayP1, TRUE);
                    }
                    else
                    {
                         /* 2 player demo */
                         selectReplay(&replayP1, &replayP2);
                         ret = playReplay2P(&replayP1, &replayP2, TRUE);
                    }
                    clearScreen();
                    checkError(ret);
                    frame = 0;
#if defined(USE_PCM)
                    /* say hello!, again */
                    slPCMOn(&welcome_dat , welcome , welcome_size);
#endif          
               }
               else
               {
                    /* check for user input, count till demo */
                    frame++;
               
                    /* get the controller data */
//                    push = Smpc_Peripheral[0].push;
                    getfirstPadInput(NULL, &push, NULL);
                    if(push == PRESSED_PAD_START)
                    {
#if defined(USE_PCM)
                         /* wait untill sound ends */
                         while(slPCMStat(&welcome_dat)) { slSynch(); }
#endif          
                         ret = chooseOptions();
                         clearScreen();
                         checkError(ret);
                         frame = 0;
#if defined(USE_PCM)
                         /* say hello!, again */
                         slPCMOn(&welcome_dat , welcome , welcome_size);
#endif          
                    }
               }                      
               // reprint screen
               slPrint("Rockin'-B's MineSweeper", slLocate(8, 2));
               slPrint("for SEGA Saturn", slLocate(12, 3));
               slPrint("Demo in", slLocate(10, 15));
               print2Digits(SECONDS2DEMO - (frame / FPS), n);
               slPrint(n, slLocate(18, 15));
               slPrint("seconds!", slLocate(21, 15));
               slPrint("Press Start Button", slLocate(10, 20));
               
               slSynch();
          }
     }
     else
     {
          /* game start not possible */
          while(1)
          {
               slPrint("No controller plugged into port 1!", slLocate(3, 15));
               slPrint("The game will not start.", slLocate(3, 16));
               slSynch();
          }
     }
     /* to prevent emulators from executing after main finished */
     while(1)
     {
           slPrint("The game is finished.", slLocate(3, 14));
           slSynch();
     }
}


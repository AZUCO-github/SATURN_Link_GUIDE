#ifndef USE_BOARD
#define USE_BOARD

/* board position macros */
#define   BOARDP1_POSX_1P(w)         (320/2 - (16*w/2))
#define   BOARDP1_POSY_1P(h)         (((240 - (16*h)) / 4) * 3)

#define   BOARDP1_POSX_2P(w)         ((320 - (16*w*2)) / 3)
#define   BOARDP1_POSY_2P(h)         BOARDP1_POSY_1P(h)
#define   BOARDP2_POSX_2P(w)         (2 * BOARDP1_POSX_2P(w) + 16*w)
#define   BOARDP2_POSY_2P(h)         BOARDP1_POSY_1P(h)


/* That's the data type for one element of the playing field */
typedef struct ELEMENT {
     Bool isCovered;
     Bool isBomb;
     Bool isMarked;
     Uint8 nBombsAround;
} Element;

/* That's the playing field data structure */
typedef struct PLAYINGFIELD {
     Uint8 width;
     Uint8 height;
     Uint8 bombs;
     Uint8 cursorX;
     Uint8 cursorY;
     Uint8 posX;
     Uint8 posY;
     Uint16 coveredElements;
     Bool exploded;
     Element *elements;
} PlayingField;

int createBoard(PlayingField *board, Uint8 width, Uint8 height, Uint8 bombs, Uint8 posX, Uint8 posY);
int deleteBoard(PlayingField *board);
int displayBoard(PlayingField *board, Bool cursor, Bool cheat);
int displayBoardSprite(PlayingField *board, Bool cursor, Bool cheat);
void computeNumbers(PlayingField *board);

#include "replay.h"

int reCreateBoard(PlayingField *board, ReplayData *replay, Uint8 posX, Uint8 posY);

#endif

void displayTime(Uint32 seconds, Uint8 posX, Uint8 posY);

int playP1(Uint8 width, Uint8 height, Uint8 bombs);
int playMatch(Uint8 width, Uint8 height, Uint8 bombs, Uint8 matches);
int playP2(Uint8 width, Uint8 height, Uint8 bombs, Uint8 round, Sint8 *pointsP1, Sint8 *pointsP2);
int checkInputs(PlayingField *board, ReplayData *replay, Uint8 player, Uint8 *blink, Bool *HUD);


int playReplay1P(ReplayData *replayP1, Bool autoExit);
int playReplay2P(ReplayData *replayP1, ReplayData *replayP2, Bool autoExit);
Uint8 checkCommand(PlayingField *board, ReplayData *replay, Uint8 *blink);


#include <SGL.H>
#include "common.h"
#include <sega_bup.h>
#include "RockinVR.h"
#include "board.h"
#include "replay.h"
#include "hscfdata.h"
#include "play.h"



#define        WIN       0
#define        LOOSE     1
#define        DRAW      2


#if defined(USE_PCM)

/* speech */
extern Uint8 player1[];
extern Uint32 player1_size;
extern PCM player1_dat ;

extern Uint8 player2[];
extern Uint32 player2_size;
extern PCM player2_dat ;

extern Uint8 win[];
extern Uint32 win_size;
extern PCM win_dat ;

extern Uint8 loose[];
extern Uint32 loose_size;
extern PCM loose_dat ;

extern Uint8 draw[];
extern Uint32 draw_size;
extern PCM draw_dat ;

/* SFX */
extern Uint8 bomb[];
extern Uint32 bomb_size;
extern PCM bomb_dat ;

extern Uint8 finished[];
extern Uint32 finished_size;
extern PCM finished_dat ;

extern Uint8 nobomb[];
extern Uint32 nobomb_size;
extern PCM nobomb_dat ;

/* makes voice sentences like
 * "Draw game!"
 * "Player 1, you win"
 * "Player 2, you loose"
 * and vice versa
 */
void shoutResult(PlayingField *boardP1, PlayingField *boardP2, Uint8 player, Uint8 result)
{
     Uint16 frame;

     /* wait untill previous sound ends */
     while(slPCMStat(&bomb_dat) || slPCMStat(&nobomb_dat)) 
     { 
          if(boardP1 != NULL)
               displayBoardSprite(boardP1, FALSE, TRUE);
          if(boardP2 != NULL)
               displayBoardSprite(boardP2, FALSE, TRUE);
          slSynch(); 
     }
     if(result != DRAW)
     {
          /* say Player ? */
          if(player == PLAYER_1)
               slPCMOn(&player1_dat , player1 , player1_size);
          else slPCMOn(&player2_dat , player2 , player2_size);     
          /* wait untill sound ends */
          while(slPCMStat(&player1_dat) || slPCMStat(&player2_dat)) 
          { 
               if(boardP1 != NULL)
                    displayBoardSprite(boardP1, FALSE, TRUE);
               if(boardP2 != NULL)
                    displayBoardSprite(boardP2, FALSE, TRUE);
               slSynch(); 
          }
          /* wait some time silent */
          for(frame = 0; frame < PCM_PAUSE; frame++) 
          { 
               if(boardP1 != NULL)
                    displayBoardSprite(boardP1, FALSE, TRUE);
               if(boardP2 != NULL)
                    displayBoardSprite(boardP2, FALSE, TRUE);
               slSynch(); 
          }
          /* say result */
          if(result == WIN)
               slPCMOn(&win_dat , win , win_size);
          else     
               slPCMOn(&loose_dat , loose , loose_size);
          /* wait untill sound ends */
          while(slPCMStat(&win_dat) || slPCMStat(&loose_dat)) 
          { 
               if(boardP1 != NULL)
                    displayBoardSprite(boardP1, FALSE, TRUE);
               if(boardP2 != NULL)
                    displayBoardSprite(boardP2, FALSE, TRUE);
               slSynch(); 
          }
     }          
     else
     {
          /* say draw */
          slPCMOn(&draw_dat , draw , draw_size);
          /* wait untill sound ends */
          while(slPCMStat(&draw_dat)) 
          { 
               if(boardP1 != NULL)
                    displayBoardSprite(boardP1, FALSE, TRUE);
               if(boardP2 != NULL)
                    displayBoardSprite(boardP2, FALSE, TRUE);
               slSynch(); 
          }
     }
     
     return;
}

#endif

void displayTime(Uint32 seconds, Uint8 posX, Uint8 posY)
{
     char string[6];
     Uint32 minutes = 0;

     if(seconds != 0)
     {
          minutes = seconds / 60;
          seconds = seconds - (minutes * 60);
     }     
     // first assemble the string to display
     // data is in BCD format
     // convert to ASCII chars
     
     // minutes
     string[0] = (char)((minutes / 10) + 48);
     string[1] = (char)(minutes - (10 * (Uint32)(string[0] - 48)) + 48);
     string[2] = ':';
     // seconds
     string[3] = (char)((seconds / 10) + 48);
     string[4] = (char)(seconds - (10 * (Uint32)(string[3] - 48)) + 48);
     // terminate string
     string[5] = '\0';
     
     // then display the string
     slPrint(string, slLocate(posX, posY));

     return;     
}

void displayHUD(Uint8 players, Uint8 bombsP1, Uint8 *nameP1, Uint8 bombsP2, Uint8 *nameP2, Uint8 round)
{
     Uint8 n[3];     

     clearScreen();
     slPrint("Rockin'-B's MineSweeper", slLocate(8, 2));
     slPrint("for SEGA Saturn", slLocate(12, 3));
     slPrint("A - uncover, B - mark", slLocate(9, 5));
     slPrint("START - toggle text", slLocate(10, 6));
     slPrint("Time:", slLocate(13, 11));

     // player 1 specific
     slPrint("Player 1:", slLocate(1, 8));
     slPrint(nameP1, slLocate(11, 8));
     print2Digits(bombsP1, n);
     slPrint("Bombs:", slLocate(1, 9));
     slPrint(n, slLocate(10, 9));
     
     if(players == 2)
     {
          // player 2 specific
          slPrint("Player 2:", slLocate(21, 8));
          slPrint(nameP2, slLocate(31, 8));
          print2Digits(bombsP2, n);
          slPrint("Bombs:", slLocate(21, 9));
          slPrint(n, slLocate(30, 9));
          // round
          print2Digits(round, n);
          slPrint("Round:", slLocate(13, 13));
          slPrint(n, slLocate(20, 13));
     }

     return;
}


#if defined(DEBUG_REPLAY)
/* displays the last 10 bytes of replay data */
void displayReplay(ReplayData *replay, Uint8 posX)
{
     int i;

     slPrint("Replay", slLocate(posX+2, 12));     
     slPrint("Data", slLocate(posX+4, 13));     
     for(i = 0; i < 10; i++)
     {
          if(replay->current - i > replay->start + *(replay->start + REPLAY_BOMBS) * 2 + REPLAY_BOMBS + 1)
               slPrintHex(*(replay->current - i), slLocate(posX, 25 - i));
     }

     return;
}

#endif



int play1P(Uint8 width, Uint8 height, Uint8 bombs)
{
     PlayingField boardP1;
     ReplayData replayP1;
     int ret;
     Bool HUD = TRUE;
     Uint8 result;
     Uint32 frame = 0;
     Uint8 blink = 0;
     
     
     // first create the playing field
     ret = createBoard(&boardP1, width, height, bombs, BOARDP1_POSX_1P(width), BOARDP1_POSY_1P(height));
     // check for errors
     if(ret != ERROR_OK)
          return ret;
     
     // then init replay
     ret = initReplay(&replayP1, &boardP1, CF_P1_NAME);
     // check for errors
     if(ret != ERROR_OK)
          return ret;

     displayHUD(1, bombs, &BackupData[CF_P1_NAME], 0, NULL, 1);
               
     // then start the playing loop
     waitRelease();
     while((boardP1.exploded == FALSE) && (boardP1.coveredElements != 0))
     {
          // next frame of player input?
          ret = checkInputs(&boardP1, &replayP1, PLAYER_1, &blink, &HUD);
          // check for errors
          if(ret != ERROR_OK)
               return ret;

          // update display
          if(++blink <= (FPS / 2))
               displayBoardSprite(&boardP1, TRUE, FALSE);
          else
          {
               displayBoardSprite(&boardP1, FALSE, FALSE);
               if(blink == FPS)
                    blink = 0;
          }
          if(HUD == TRUE)
          {
               displayHUD(1, bombs, &BackupData[CF_P1_NAME], 0, NULL, 1);
               displayTime(frame / FPS, 19, 11);
#if defined(DEBUG_REPLAY)
               displayReplay(&replayP1, 30);
#endif
          }
          else clearScreen();

          frame++;
          slSynch();
     }
     
     // stop replay recording
     REPLAY_END((&replayP1));
     
     // and wait to exit
     waitRelease();
     
     // examine the reason why the game ended
     if(boardP1.exploded == TRUE)
     {
          // You loose!
          slPrint(&BackupData[CF_P1_NAME], slLocate(11, 27));
          slPrint("exploded!", slLocate(11 + CF_NAME_LENGTH + 1, 27));
          result = LOOSE;
     }
     else if(boardP1.coveredElements == 0)
          {
              // You win!
               slPrint(&BackupData[CF_P1_NAME], slLocate(13, 27));
               slPrint("wins!", slLocate(13 + CF_NAME_LENGTH + 1, 27));
               result = WIN;
          }
          else
               // Some error?
               slPrint("Unexpected exit!", slLocate(12, 27));

#if defined(USE_PCM)
     shoutResult(&boardP1, NULL, PLAYER_1, result);
#endif          

     slPrint("Press Start Button", slLocate(11, 29));

     // display the playing field uncovered and without marks
     while(1) {
          Uint16 data;
          getfirstPadInput(&data, NULL, NULL);
          if(data == PRESSED_PAD_START)
              break;
          displayBoardSprite(&boardP1, FALSE, TRUE);
          slSynch();
     }
     // update highscores
     if((boardP1.exploded == FALSE) && (boardP1.coveredElements == 0))
          updateHighscores(&boardP1, frame / FPS, CF_P1_NAME, PLAYER_1);
     
     // now ask what to do with the replay
     // You win: cursor is on show, 
     // You Loose: cursor is on exit
     handleReplay(&replayP1, (ReplayData *)NULL, (boardP1.exploded == TRUE? 2: 0));

     deleteBoard(&boardP1);

     return ERROR_OK;
}



int play2P(Uint8 width, Uint8 height, Uint8 bombs, Uint8 round, Sint8 *pointsP1, Sint8 *pointsP2)
{
     PlayingField boardP1, boardP2;
     ReplayData replayP1, replayP2;
     int ret;
     Bool HUD = TRUE;
     Uint8 result, player;
     Uint32 frame = 0;
     Uint8 blinkP1 = 0, blinkP2 = 0;

     // first create the playing fields
     ret = createBoard(&boardP1, width, height, bombs, BOARDP1_POSX_2P(width), BOARDP1_POSY_2P(height));
     // check for errors
     if(ret != ERROR_OK)
          return ret;
     ret = createBoard(&boardP2, width, height, bombs,  BOARDP2_POSX_2P(width), BOARDP2_POSY_2P(height));
     // check for errors
     if(ret != ERROR_OK)
          return ret;
     

     // init replay
     ret = initReplay(&replayP1, &boardP1, CF_P1_NAME);
     // check for errors
     if(ret != ERROR_OK)
          return ret;
     ret = initReplay(&replayP2, &boardP2, CF_P2_NAME);
     // check for errors
     if(ret != ERROR_OK)
          return ret;

     displayHUD(2, bombs, &BackupData[CF_P1_NAME], bombs, &BackupData[CF_P2_NAME], round);
     
     // then start the playing loop
     waitRelease();
     while((boardP1.exploded == FALSE) && (boardP1.coveredElements != 0) && (boardP2.exploded == FALSE) && (boardP2.coveredElements != 0))
     {
          // next frame of player input?
          ret = checkInputs(&boardP1, &replayP1, PLAYER_1, &blinkP1, &HUD);
          // check for errors
          if(ret != ERROR_OK)
               return ret;
          ret = checkInputs(&boardP2, &replayP2, PLAYER_2, &blinkP2, &HUD);
          // check for errors
          if(ret != ERROR_OK)
               return ret;

          // update display
               // player 1
          if(++blinkP1 <= (FPS / 2))
               displayBoardSprite(&boardP1, TRUE, FALSE);
          else
          {
               displayBoardSprite(&boardP1, FALSE, FALSE);
               if(blinkP1 == FPS)
                    blinkP1 = 0;
          }
               // player 2
          if(++blinkP2 <= (FPS / 2))
               displayBoardSprite(&boardP2, TRUE, FALSE);
          else
          {
               displayBoardSprite(&boardP2, FALSE, FALSE);
               if(blinkP2 == FPS)
                    blinkP2 = 0;
          }
          if(HUD == TRUE)
          {
               displayHUD(2, bombs, &BackupData[CF_P1_NAME], bombs, &BackupData[CF_P2_NAME], round);
               displayTime(frame / FPS, 19, 11);
#if defined(DEBUG_REPLAY)          
               displayReplay(&replayP1, 10);
               displayReplay(&replayP2, 30);
#endif
          }
          else clearScreen();
          
          frame++;
          slSynch();
     }
     
     // stop replay recording
     REPLAY_END((&replayP1));
     REPLAY_END((&replayP2));
     
     waitRelease();
     
     // examine the reason why the game ended
     if((boardP1.coveredElements == 0) && (boardP1.exploded == FALSE) && (boardP2.coveredElements == 0) && (boardP2.exploded == FALSE))
     {
          // Both win!
          slPrint("Draw!", slLocate(17, 27));
          *pointsP1 += 1;
          *pointsP2 += 1;
          result = DRAW;
     }
     else if((boardP1.coveredElements == 0) && (boardP1.exploded == FALSE))
          {
               // Player 1 wins!
               slPrint(&BackupData[CF_P1_NAME], slLocate(13, 27));
               slPrint("wins!", slLocate(13 + CF_NAME_LENGTH + 1, 27));
               *pointsP1 += 1;
               result = WIN;
               player = PLAYER_1;
          }
          else if((boardP2.coveredElements == 0) && (boardP2.exploded == FALSE))
               {
                    // Player 2 wins!
                    slPrint(&BackupData[CF_P2_NAME], slLocate(13, 27));
                    slPrint("wins!", slLocate(13 + CF_NAME_LENGTH + 1, 27));
                    *pointsP2 += 1;
                    result = WIN;
                    player = PLAYER_2;
               }
               else if(boardP1.exploded == TRUE)
                    {
                         // Player 1 exploded!
                         slPrint(&BackupData[CF_P1_NAME], slLocate(11, 27));
                         slPrint("exploded!", slLocate(11 + CF_NAME_LENGTH + 1, 27));
                         *pointsP1 -= 2;
                         result = LOOSE;
                         player = PLAYER_1;
                    }
                    else
                    {
                         // Player 2 exploded!
                         slPrint(&BackupData[CF_P2_NAME], slLocate(11, 27));
                         slPrint("exploded!", slLocate(11 + CF_NAME_LENGTH + 1, 27));
                         *pointsP2 -= 2;
                         result = LOOSE;
                         player = PLAYER_2;
                    }

#if defined(USE_PCM)
     shoutResult(&boardP1, &boardP2, player, result);
#endif          

     slPrint("Press Start Button", slLocate(11, 29));

     // display the playing field uncovered and without marks
     while(1) {
          Uint16 data;
          getfirstPadInput(&data, NULL, NULL);
          if(data == PRESSED_PAD_START)
              break;
          displayBoardSprite(&boardP1, FALSE, TRUE);
          displayBoardSprite(&boardP2, FALSE, TRUE);
          slSynch();
     }
     // update highscores
     if(result == DRAW)
     {
          // Both win!
          updateHighscores(&boardP1, frame / FPS, CF_P1_NAME, PLAYER_1);
          updateHighscores(&boardP2, frame / FPS, CF_P2_NAME, PLAYER_2);
     }
     else if((player == PLAYER_1) && (result == WIN))
               // Player 1 wins!
               updateHighscores(&boardP1, frame / FPS, CF_P1_NAME, PLAYER_1);
          else if((player == PLAYER_2) && (result == WIN))
                    updateHighscores(&boardP2, frame / FPS, CF_P2_NAME, PLAYER_2);

     // now ask what to do with the replay
     // One player wins: cursor is on show, 
     // One player explodes: cursor is on exit
     handleReplay(&replayP1, &replayP2, (((boardP1.coveredElements == 0) && (boardP1.exploded == FALSE) || (boardP2.coveredElements == 0) && (boardP2.exploded == FALSE)) ? 0: 2));

     ret = deleteBoard(&boardP1);
     if(ret != ERROR_OK)
          return ret;
     ret = deleteBoard(&boardP2);
     if(ret != ERROR_OK)
          return ret;
     
     return ERROR_OK;
}




int playMatch(Uint8 width, Uint8 height, Uint8 bombs, Uint8 matches)
{
     int ret;
     Uint8 result, player;
     Uint8 n[3], i;
     Sint8 pointsP1 = 0, pointsP2 = 0;
     
     for(i = 1; i <= matches; i++)
     {
          ret = play2P(width, height, bombs, i, &pointsP1, &pointsP2);
          if(ret != ERROR_OK)
               return ret;
     }

     clearScreen();
     slPrint("Rockin'-B's MineSweeper", slLocate(8, 2));
     slPrint("for SEGA Saturn", slLocate(12, 3));

     slPrint("Points after", slLocate(8, 10));
     print2Digits(matches, n);
     slPrint(n, slLocate(21, 10));
     slPrint("rounds:", slLocate(24, 10));
     // player 1 points
     slPrint(&BackupData[CF_P1_NAME], slLocate(12, 12));
     if(pointsP1 < 0)
     {
          slPrint("-", slLocate(12 + CF_NAME_LENGTH + 4, 12));
          print2Digits((0 - pointsP1), n);
     }
     else print2Digits(pointsP1, n);
     
     slPrint(n, slLocate(12 + CF_NAME_LENGTH + 5, 12));
     // player 2 points
     slPrint(&BackupData[CF_P2_NAME], slLocate(12, 13));
     if(pointsP2 < 0)
     {
          slPrint("-", slLocate(12 + CF_NAME_LENGTH + 4, 13));
          print2Digits((0 - pointsP2), n);
     }
     else print2Digits(pointsP2, n);
     slPrint(n, slLocate(12 + CF_NAME_LENGTH + 5, 13));


     // who wins the match?
     if(pointsP1 == pointsP2)
     {
          // draw game
          slPrint("Draw!", slLocate(17, 27));
          player = PLAYER_1;
          result = DRAW;
     }
     else if(pointsP1 > pointsP2)
          {
               // player 1 wins
               slPrint(&BackupData[CF_P1_NAME], slLocate(13, 27));
               slPrint("wins!", slLocate(13 + CF_NAME_LENGTH + 1, 27));
               player = PLAYER_1;
               result = WIN;
          }
          else
          {
               // player 2 wins
               slPrint(&BackupData[CF_P2_NAME], slLocate(13, 27));
               slPrint("wins!", slLocate(13 + CF_NAME_LENGTH + 1, 27));
               player = PLAYER_2;
               result = WIN;
          }

#if defined(USE_PCM)
     shoutResult(NULL, NULL, player, result);
#endif          

     waitRelease();
     slPrint("Press Start Button", slLocate(11, 29));
     waitKey(PRESSED_PAD_START);

     return ERROR_OK;
}



int checkInputs(PlayingField *board, ReplayData *replay, Uint8 player, Uint8 *blink, Bool *HUD)
{
     Uint16 push;
     Bool newCommand = FALSE;

     int cursorX = (int)(board->cursorX);
     int cursorY = (int)(board->cursorY);
     int width = (int)(board->width);
     int height = (int)(board->height);


     // manage the user inputs
     if(player == PLAYER_1)
     {
          if(!Per_Connect1)
               return ERROR_NO_CONTROLLER;
          push = Smpc_Peripheral[0].push;
          checkExitHere(Smpc_Peripheral[0].data);
     }
     else if(player == PLAYER_2)
     {
          if(!Per_Connect2)
               return ERROR_NO_CONTROLLER;
          push = Smpc_Peripheral[15].push;
          checkExitHere(Smpc_Peripheral[15].data);
     }
          
     switch(push)
     {
          case(PRESSED_PAD_LEFT):
               if(board->cursorX > 0)
               {
                    board->cursorX--;
                    REPLAY_LEFT(replay);
                    newCommand = TRUE;
               }
               // display cursor to see where it is
               *blink = 0;     
               break;
          case(PRESSED_PAD_RIGHT):
               if(board->cursorX < board->width-1)
               {
                    board->cursorX++;
                    REPLAY_RIGHT(replay);
                    newCommand = TRUE;
               }
               // display cursor to see where it is
               *blink = 0;     
               break;
          case(PRESSED_PAD_UP):
               if(board->cursorY > 0)
               {
                    board->cursorY--;
                    REPLAY_UP(replay);
                    newCommand = TRUE;
               }
               // display cursor to see where it is
               *blink = 0;     
               break;
          case(PRESSED_PAD_DOWN):
               if(board->cursorY < board->height-1)
               {
                    board->cursorY++;
                    REPLAY_DOWN(replay);
                    newCommand = TRUE;
               }
               // display cursor to see where it is
               *blink = 0;     
               break;
          // uncover
          case(PRESSED_PAD_C):
          case(PRESSED_PAD_A):
               if((board->elements + cursorY*width + cursorX)->isCovered == TRUE)
               {
                    if((board->elements + cursorY*width + cursorX)->isBomb == TRUE)
                    {
                         board->exploded = TRUE;
#if defined(USE_PCM)
                         /* play bomb sound */
                         slPCMOn(&bomb_dat , bomb, bomb_size);
#endif          
                    }
#if defined(USE_PCM)
                    else
                         /* play nobomb sound */
                         slPCMOn(&nobomb_dat , nobomb, nobomb_size);
#endif          
                    (board->elements + cursorY*width + cursorX)->isCovered = FALSE;
                    board->coveredElements--;
                    REPLAY_A(replay);
                    newCommand = TRUE;
                    // hide cursor to see the uncovered element
                    *blink = FPS / 2;     
               }
               break;     
          // set/remove mark
          case(PRESSED_PAD_B):
               /* only covered field can be marked */
               if((board->elements + (int)(board->cursorY)*(int)(board->width) + (int)(board->cursorX))->isCovered == TRUE)
               {
                    if((board->elements + cursorY*width + cursorX)->isMarked == FALSE)
                         (board->elements + cursorY*width + cursorX)->isMarked = TRUE;
                    else
                         (board->elements + cursorY*width + cursorX)->isMarked = FALSE;
                    REPLAY_B(replay);
                    newCommand = TRUE;
                    // hide cursor to see the marked element
                    *blink = FPS / 2;     
               }     
               break;     
          case(PRESSED_PAD_START):
               // toggle HUD display
               if(*HUD == TRUE)
                    *HUD = FALSE;
               else *HUD = TRUE;          
               break;
          default:
               break;
     }
     // manage replay byte overflow
     if((newCommand == FALSE) && (replay->curframe == replay->maxframe))
     {
          /* we have to reached the maximum time this byte can encode
           * and still no command has come 
           * so we have to insert the command "REPLAY_NONE"
           */
          REPLAY_NONE(replay);
          newCommand = TRUE;
     }
     /* look if we have to append space to the replay 
      * for the next player input
      */
     if(newCommand == TRUE)
     {
          if((replay->start = (Uint8 *)realloc((void *)replay->start, ++(replay->length) * sizeof(Uint8))) == NULL)
               return ERROR_OUT_OF_MEMORY;
          replay->current = replay->start + replay->length - 1;
          replay->curframe = 0;
          /* default entry, although unnecessary,
           * this might help fix the replay abort issue
           */
          REPLAY_NONE(replay);
     }
     else
          replay->curframe++;
          
     return ERROR_OK;
}



int playReplay1P(ReplayData *replayP1, Bool autoExit)
{
     PlayingField boardP1;
     int ret, i;
     Uint32 frame = 0;
     Uint8 blink = 0;
     

     // init replay
     reInitReplay(replayP1);
     
     ret = reCreateBoard(&boardP1, replayP1, BOARDP1_POSX_1P(*(replayP1->start + REPLAY_WIDTH)), BOARDP1_POSY_1P(*(replayP1->start + REPLAY_HEIGHT)));
     // check for errors
     if(ret != ERROR_OK)
          return ret;

     displayHUD(1, boardP1.bombs, (replayP1->start + REPLAY_NAME), 0, NULL, 1);

     // then start the playing loop
     waitRelease();
     slPrint("Press any button!", slLocate(11, 29));
     while((boardP1.exploded == FALSE) &&  (boardP1.coveredElements != 0))
     {
          // check to exit
          Uint16 data;
          getfirstPadInput(&data, NULL, NULL);
          if(data != PRESSED_PAD_NOTHING)
               break;
//          if(!Per_Connect1)
//               return ERROR_NO_CONTROLLER;
//          if(Smpc_Peripheral[0].data != PRESSED_PAD_NOTHING)
//               break;
               
          /* check if the replay's next command can be processed
           * and abort if replay ends 
           */
          if(checkCommand(&boardP1, replayP1, &blink))
               break;
          
          // update display
          if(++blink <= (FPS / 2))
               displayBoardSprite(&boardP1, TRUE, FALSE);
          else
          {
               displayBoardSprite(&boardP1, FALSE, FALSE);
               if(blink == FPS)
                    blink = 0;
          }
          displayTime(frame++ / FPS, 19, 11);
#if defined(DEBUG_REPLAY)          
          displayReplay(replayP1, 30);
#endif
          slSynch();
     }
     
     // and wait to exit
     waitRelease();
     
     // examine the reason why the game ended
     if(boardP1.exploded == TRUE)
     {
          // You loose!
          slPrint((replayP1->start + REPLAY_NAME), slLocate(11, 27));
          slPrint("exploded!", slLocate(11 + CF_NAME_LENGTH + 1, 27));
     }
     else if(boardP1.coveredElements == 0) 
          {
              // You win!
               slPrint((replayP1->start + REPLAY_NAME), slLocate(13, 27));
               slPrint("wins!", slLocate(13 + CF_NAME_LENGTH + 1, 27));
          }
          else
               slPrint("Replay aborted!", slLocate(12, 27));

#if defined(USE_PCM)
     /* wait untill sound ends */
     while(slPCMStat(&bomb_dat) || slPCMStat(&nobomb_dat)) 
     { 
          displayBoardSprite(&boardP1, FALSE, TRUE);
          slSynch(); 
     }
     /* play finished */
     slPCMOn(&finished_dat , finished , finished_size);
     /* wait untill sound ends */
     while(slPCMStat(&finished_dat)) 
     { 
          displayBoardSprite(&boardP1, FALSE, TRUE);
          slSynch(); 
     }
#endif          

     slPrint("Press Start Button", slLocate(11, 29));

     // display the playing field uncovered and without marks
     frame = 0;
     while(1)
     {
          Uint16 data;
          displayBoardSprite(&boardP1, FALSE, TRUE);
          slSynch();
          frame++;
          getfirstPadInput(&data, NULL, NULL);
          
          /* exit event according to autoExit */  
          if((autoExit == FALSE) && (data == PRESSED_PAD_START))
               break;
          else if((autoExit == TRUE) && (((frame / FPS) == SECONDS2DEMO) || (data == PRESSED_PAD_START)))
                    break;
     }
     
     waitRelease();

     ret = deleteBoard(&boardP1);
     // check for errors
     if(ret != ERROR_OK)
          return ret;

     return ERROR_OK;     
}



int playReplay2P(ReplayData *replayP1, ReplayData *replayP2, Bool autoExit)
{
     PlayingField boardP1, boardP2;
     int ret, i;
     Uint32 frame = 0;
     Uint8 blinkP1 = 0, blinkP2 = 0, finishedP1 = 0, finishedP2 = 0;
     

     // init replay
     reInitReplay(replayP1);
     reInitReplay(replayP2);
     
     ret = reCreateBoard(&boardP1, replayP1, BOARDP1_POSX_2P(*(replayP1->start + REPLAY_WIDTH)), BOARDP1_POSY_2P(*(replayP1->start + REPLAY_HEIGHT)));
     // check for errors
     if(ret != ERROR_OK)
          return ret;
     ret = reCreateBoard(&boardP2, replayP2, BOARDP2_POSX_2P(*(replayP2->start + REPLAY_WIDTH)), BOARDP2_POSY_2P(*(replayP2->start + REPLAY_HEIGHT)));
     // check for errors
     if(ret != ERROR_OK)
          return ret;
     
     displayHUD(2, boardP1.bombs, (replayP1->start + REPLAY_NAME), boardP2.bombs, (replayP2->start + REPLAY_NAME), 1);

     // then start the playing loop
     waitRelease();
     slPrint("Press any button!", slLocate(11, 29));
     while((boardP1.exploded == FALSE)  && (boardP1.coveredElements != 0) && (boardP2.exploded == FALSE)  && (boardP2.coveredElements != 0))
     {
          // check only for Input on 1st controller
          Uint16 data;
          getfirstPadInput(&data, NULL, NULL);
          if(data != PRESSED_PAD_NOTHING)
                break;
//          if(Per_Connect1)
//          {
//               if(Smpc_Peripheral[PLAYER_1].data != PRESSED_PAD_NOTHING)
//                    break;
//          }
//          else return ERROR_NO_CONTROLLER;

          // check if the replay's next command can be processed
          /* only play replays that are not finished */
          if(!finishedP1)
               finishedP1 = checkCommand(&boardP1, replayP1, &blinkP1);
          if(!finishedP2)
               finishedP2 = checkCommand(&boardP2, replayP2, &blinkP2);
          /* and abort if both replays are finished */
          if(finishedP1 && finishedP2)
               break;
          
          // update display
               // player 1
          if(++blinkP1 <= (FPS / 2))
               displayBoardSprite(&boardP1, TRUE, FALSE);
          else
          {
               displayBoardSprite(&boardP1, FALSE, FALSE);
               if(blinkP1 == FPS)
                    blinkP1 = 0;
          }
               // player 2
          if(++blinkP2 <= (FPS / 2))
               displayBoardSprite(&boardP2, TRUE, FALSE);
          else
          {
               displayBoardSprite(&boardP2, FALSE, FALSE);
               if(blinkP2 == FPS)
                    blinkP2 = 0;
          }
          displayTime(frame++ / FPS, 19, 11);
#if defined(DEBUG_REPLAY)          
          displayReplay(replayP1, 10);
          displayReplay(replayP2, 30);
#endif
          slSynch();
     }
     
     // and wait to exit
     waitRelease();
     
     // examine the reason why the game ended
     if((boardP1.exploded == FALSE) && (boardP1.coveredElements == 0) && (boardP2.exploded == FALSE) && (boardP2.coveredElements == 0))
          // Both win!
          slPrint("Draw!", slLocate(17, 27));
     else if((boardP1.exploded == FALSE) && (boardP1.coveredElements == 0))
          {
               // Player 1 wins!
               slPrint((replayP1->start + REPLAY_NAME), slLocate(13, 27));
               slPrint("wins!", slLocate(13 + CF_NAME_LENGTH + 1, 27));
          }
          else if((boardP2.exploded == FALSE) && (boardP2.coveredElements == 0))
               {
                    // Player 2 wins!
                    slPrint((replayP2->start + REPLAY_NAME), slLocate(13, 27));
                    slPrint("wins!", slLocate(13 + CF_NAME_LENGTH + 1, 27));
               }
               else if(boardP1.exploded == TRUE)
                    {
                         // Player 1 exploded!
                         slPrint((replayP1->start + REPLAY_NAME), slLocate(11, 27));
                         slPrint("exploded!", slLocate(11 + CF_NAME_LENGTH + 1, 27));
                    }
                    else if(boardP2.exploded == TRUE)
                         {
                              // Player 2 exploded!
                              slPrint((replayP2->start + REPLAY_NAME), slLocate(11, 27));
                              slPrint("exploded!", slLocate(11 + CF_NAME_LENGTH + 1, 27));
                         }
                         else
                              slPrint("Replay aborted!", slLocate(12, 27));

#if defined(USE_PCM)
     /* wait untill sound ends */
     while(slPCMStat(&bomb_dat) || slPCMStat(&nobomb_dat)) 
     { 
          displayBoardSprite(&boardP1, FALSE, TRUE);
          displayBoardSprite(&boardP2, FALSE, TRUE);
          slSynch(); 
     }
     /* play finished */
     slPCMOn(&finished_dat , finished , finished_size);
     /* wait untill sound ends */
     while(slPCMStat(&finished_dat)) 
     { 
          displayBoardSprite(&boardP1, FALSE, TRUE);
          displayBoardSprite(&boardP2, FALSE, TRUE);
          slSynch(); 
     }
#endif          

     slPrint("Press Start Button", slLocate(11, 29));

     // display the playing field uncovered and without marks
     frame = 0;
     while(1)
     {
          Uint16 data;
          displayBoardSprite(&boardP1, FALSE, TRUE);
          displayBoardSprite(&boardP2, FALSE, TRUE);
          slSynch();
          frame++;
          getfirstPadInput(&data, NULL, NULL);
          
          /* exit event according to autoExit */  
          if((autoExit == FALSE) && (data == PRESSED_PAD_START))
               break;
          else if((autoExit == TRUE) && (((frame / FPS) == SECONDS2DEMO) || (data == PRESSED_PAD_START)))
                    break;
     }
     
     waitRelease();

     ret = deleteBoard(&boardP1);
     // check for errors
     if(ret != ERROR_OK)
          return ret;

     ret = deleteBoard(&boardP2);
     // check for errors
     if(ret != ERROR_OK)
          return ret;

     return ERROR_OK;     
}


/* return 0 if everything is OK,
 * return 1 if replay ends */
Uint8 checkCommand(PlayingField *board, ReplayData *replay, Uint8 *blink)
{
     int cursorX = (int)(board->cursorX);
     int cursorY = (int)(board->cursorY);
     int width = (int)(board->width);
     int height = (int)(board->height);

     // is it time to execute the fetched command? 
     if(replay->curframe == 0)
     {
          switch(*(replay->current) >> 5)
          {
               case(ENCODED_LEFT):
                         board->cursorX--;
                         // show cursor
                         *blink = 0;
                    break;
               case(ENCODED_RIGHT):
                         board->cursorX++;
                         // show cursor
                         *blink = 0;
                    break;
               case(ENCODED_UP):
                         board->cursorY--;
                         // show cursor
                         *blink = 0;
                    break;
               case(ENCODED_DOWN):
                         board->cursorY++;
                         // show cursor
                         *blink = 0;
                    break;
               // uncover
               case(ENCODED_A):
                    if((board->elements + cursorY*width + cursorX)->isBomb == TRUE)
                    {
                         board->exploded = TRUE;
#if defined(USE_PCM)
                         /* play bomb sound */
                         slPCMOn(&bomb_dat , bomb, bomb_size);
#endif          
                    }
#if defined(USE_PCM)
                    else
                         /* play nobomb sound */
                         slPCMOn(&nobomb_dat , nobomb, nobomb_size);
#endif          
                    (board->elements + cursorY*width + cursorX)->isCovered = FALSE;
                    board->coveredElements--;
                    // hide cursor
                    *blink = FPS / 2;
                    break;     
               // set/remove mark
               case(ENCODED_B):
                    if((board->elements + cursorY*width + cursorX)->isMarked == FALSE)
                         (board->elements + cursorY*width + cursorX)->isMarked = TRUE;
                    else
                         (board->elements + cursorY*width + cursorX)->isMarked = FALSE;
                    // hide cursor
                    *blink = FPS / 2;
                    break;
               case(ENCODED_NONE):
                    break;          
               case(ENCODED_END):
                    // don't point to next command, this is the last one
                    return 1;
               default:
                    break;
          }
          /* point to next command */
          replay->current++;
          /* compute number of frames untill the next command is processed */
          replay->curframe = (*(replay->current) & 0x1F) * replay->scale;
     }
     else replay->curframe--;
     
     return 0;
}


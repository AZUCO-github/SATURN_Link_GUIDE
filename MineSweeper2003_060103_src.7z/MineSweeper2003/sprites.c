#include	"sgl.h"

#include "media/sprites/board.c"

// this note is old,
// I found a little error in my sprite display...

/* Here an example how bad the old compiler is. 
 * The comments and workarounds are not neccessary with the new gnush. */


/* for some reason the last 13th element should not be removed, 
 * although we have only 12 sprites
 */	
SPR_ATTR attr[] = {
	SPR_ATTRIBUTE(0,No_Palet,No_Gouraud,CL32KRGB|ECdis,sprNoflip),	
	SPR_ATTRIBUTE(1,No_Palet,No_Gouraud,CL32KRGB|ECdis,sprNoflip),	
	SPR_ATTRIBUTE(2,No_Palet,No_Gouraud,CL32KRGB|ECdis,sprNoflip),	
	SPR_ATTRIBUTE(3,No_Palet,No_Gouraud,CL32KRGB|ECdis,sprNoflip),	
	SPR_ATTRIBUTE(4,No_Palet,No_Gouraud,CL32KRGB|ECdis,sprNoflip),	
	SPR_ATTRIBUTE(5,No_Palet,No_Gouraud,CL32KRGB|ECdis,sprNoflip),
	SPR_ATTRIBUTE(6,No_Palet,No_Gouraud,CL32KRGB|ECdis,sprNoflip),	
	SPR_ATTRIBUTE(7,No_Palet,No_Gouraud,CL32KRGB|ECdis,sprNoflip),	
	SPR_ATTRIBUTE(8,No_Palet,No_Gouraud,CL32KRGB|ECdis,sprNoflip),	
	SPR_ATTRIBUTE(9,No_Palet,No_Gouraud,CL32KRGB|ECdis,sprNoflip),	
	SPR_ATTRIBUTE(10,No_Palet,No_Gouraud,CL32KRGB|ECdis,sprNoflip),	
	SPR_ATTRIBUTE(11,No_Palet,No_Gouraud,CL32KRGB|ECdis,sprNoflip)
//	SPR_ATTRIBUTE(12,No_Palet,No_Gouraud,CL32KRGB|ECdis,sprNoflip)	
};

/* although unused, removing of this array causes sprites to not display
 * note that as in the SPR_ATTRIBUTE array, here is also a 13th element,
 * one more than sprites used
 */
/*
ANGLE angz[] = {
	DEGtoANG(  0),
	DEGtoANG(  0),
	DEGtoANG(  0),
	DEGtoANG(  0),
	DEGtoANG(  0),
	DEGtoANG(  0),
	DEGtoANG(  0),
	DEGtoANG(  0),
	DEGtoANG(  0),
	DEGtoANG(  0),
	DEGtoANG(  0),
	DEGtoANG(  0),
	DEGtoANG(  0)
};
*/

TEXTURE tex_spr[] = {
	TEXDEF(16,16,0),
	TEXDEF(16,16,256),
	TEXDEF(16,16,512),
	TEXDEF(16,16,768),
	TEXDEF(16,16,1024),
	TEXDEF(16,16,1280),
	TEXDEF(16,16,1536),
	TEXDEF(16,16,1792),
	TEXDEF(16,16,2048),
	TEXDEF(16,16,2304),
	TEXDEF(16,16,2560),
	TEXDEF(16,16,2816)
};

PICTURE pic_spr[] = {
	PICDEF(0,COL_32K,board),
	PICDEF(1,COL_32K,board + (1 * 256)),
	PICDEF(2,COL_32K,board + (2 * 256)),
	PICDEF(3,COL_32K,board + (3 * 256)),
	PICDEF(4,COL_32K,board + (4 * 256)),
	PICDEF(5,COL_32K,board + (5 * 256)),
	PICDEF(6,COL_32K,board + (6 * 256)),
     PICDEF(7,COL_32K,board + (7 * 256)),
	PICDEF(8,COL_32K,board + (8 * 256)),
	PICDEF(9,COL_32K,board + (9 * 256)),
	PICDEF(10,COL_32K,board + (10 * 256)),
	PICDEF(11,COL_32K,board + (11 * 256))
};


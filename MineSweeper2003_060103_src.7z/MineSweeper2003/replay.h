#ifndef USE_REPLAY
#define USE_REPLAY

#define        MINESWEEPER_REPLAY_FILENAME   "MSReplay"
#define        MINESWEEPER_REPLAY_COMMENT    "No Comment"

/* 1P replay data format(bytes):
 *
 * width
 * height
 * bombs
 *
 * bomb_x
 * bomb_y
 *
 * name (8 characters) 
 * 3 bits                     5 bits
 * [Player input or end TAG][number of frames till next input]
 *            .....
 *  
 */
 
// to address the player specific controll data
#define        PLAYER_1                      0      
#define        PLAYER_2                      1

#define        REPLAY_NAME_LENGTH             HS_NAME_LENGTH     // plus '\0'

#define        REPLAY_WIDTH                   0
#define        REPLAY_HEIGHT                  1
#define        REPLAY_SCALE                   2
#define        REPLAY_NAME                    3
#define        REPLAY_BOMBS                   (REPLAY_NAME + REPLAY_NAME_LENGTH + 1)

#define        REPLAY_DATA_START(rp)          (*(rp.start + REPLAY_BOMBS) * 2 + REPLAY_BOMBS + 1)
#define        REPLAY_MINLENGTH(b)            (b * 2 + REPLAY_BOMBS + 2)
                                             
#define        ENCODED_END                        0
#define        ENCODED_UP                         1
#define        ENCODED_DOWN                       2
#define        ENCODED_LEFT                       3
#define        ENCODED_RIGHT                      4
#define        ENCODED_A                          5
#define        ENCODED_B                          6
#define        ENCODED_NONE                       7

/* 2P replay data format(bytes):
 * concatenation of 2 1 player replay data
 */
// to encode player inputs for replay
#define        NORM_CURFRAME(rp)             ((rp->curframe + (rp->scale / 2)) / rp->scale)

#define        REPLAY_END(rp)                *(rp->current) = ((ENCODED_END << 5) | NORM_CURFRAME(rp))
#define        REPLAY_UP(rp)                 *(rp->current) = ((ENCODED_UP << 5) | NORM_CURFRAME(rp))
#define        REPLAY_DOWN(rp)               *(rp->current) = ((ENCODED_DOWN << 5) | NORM_CURFRAME(rp))
#define        REPLAY_LEFT(rp)               *(rp->current) = ((ENCODED_LEFT << 5) | NORM_CURFRAME(rp))
#define        REPLAY_RIGHT(rp)              *(rp->current) = ((ENCODED_RIGHT << 5) | NORM_CURFRAME(rp))
#define        REPLAY_A(rp)                  *(rp->current) = ((ENCODED_A << 5) | NORM_CURFRAME(rp))
#define        REPLAY_B(rp)                  *(rp->current) = ((ENCODED_B << 5) | NORM_CURFRAME(rp))
#define        REPLAY_NONE(rp)               *(rp->current) = ((ENCODED_NONE << 5) | NORM_CURFRAME(rp))


typedef struct REPLAYDATA {
                              // control information                                          
     Uint8 scale;                  // scales maxframe = scale * 32
     Uint16 maxframe;              // maximum number of frames untill the next command has to follow
     Uint16 curframe;              // number of frames with no player input
     Uint16 length;                // number of instructions + overhead(RP_1P_MINLENGTH-1)
     Uint8 *start;            // the replay data that is saved to backup RAM
     Uint8 *current;          // the current command
} ReplayData;

int deleteReplay(ReplayData *replay);


#include "board.h"

int handleReplay(ReplayData *replayP1, ReplayData *replayP2, Uint8 selected);
int initReplay(ReplayData *replay, PlayingField *board, Uint8 name);
void reInitReplay(ReplayData *replay);

#endif

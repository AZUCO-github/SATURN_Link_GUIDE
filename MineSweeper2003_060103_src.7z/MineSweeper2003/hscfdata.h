#ifndef USE_HSCFDATA
#define USE_HSCFDATA

#define        MINESWEEPER_HSCF_FILENAME     "MineSweeper"
#define        MINESWEEPER_HSCF_COMMENT      "Highscores"

// all names are followed by the termination character '\0'
// -> writing and printing is possible without copying

// Backup data: holds serialised 8bit data(config and highscore)
/* Configuration data format:
 *   width
 *   heigth
 *   bombs
 *   name 1
 *    ...
 *   name 2
 *    ...
 */
#define        CF_NAME_LENGTH                8    // plus '\0'
/* offsets in Backup data */
#define        CF_WIDTH                      0
#define        CF_HEIGHT                     1
#define        CF_BOMBS                      2
#define        CF_REPLAY                     3
#define        CF_MATCHES                    4
#define        CF_LANGUAGE                   5
#define        CF_P1_NAME                    6
#define        CF_P2_NAME                    (CF_P1_NAME + CF_NAME_LENGTH + 1)

#define        CF_DATA_LENGTH                (CF_P2_NAME + CF_NAME_LENGTH + 1)

/* Highscore data format:
 *   rank
 *   name (8 characters, no termination!)
 *   width
 *   heigth
 *   bombs
 *   minutes
 *   seconds
 * NOTE: all date entries are not in SGL Hex format, year is the years since 1980
 */
 
#define        HS_NAME_LENGTH                CF_NAME_LENGTH // plus '\0' 
 
#define        HS_RANK                       0
#define        HS_NAME                       1
#define        HS_WIDTH                      (HS_NAME + HS_NAME_LENGTH + 1)
#define        HS_HEIGHT                     (HS_NAME + HS_NAME_LENGTH + 2)
#define        HS_BOMBS                      (HS_NAME + HS_NAME_LENGTH + 3)
#define        HS_MINUTES                    (HS_NAME + HS_NAME_LENGTH + 4)
#define        HS_SECONDS                    (HS_NAME + HS_NAME_LENGTH + 5)
#define        HS_YEAR                       (HS_NAME + HS_NAME_LENGTH + 6)
#define        HS_MONTH                      (HS_NAME + HS_NAME_LENGTH + 7)
#define        HS_DAY                        (HS_NAME + HS_NAME_LENGTH + 8)

#define        HS_START                      CF_DATA_LENGTH
#define        HS_ENTRY_LENGTH               (HS_DAY + 1)
#define        HS_ENTRIES                    60
#define        HS_ENTRIES_PER_PAGE           20

extern Uint8 BackupData[CF_DATA_LENGTH + HS_ENTRIES*HS_ENTRY_LENGTH];   

int updateHighscores(PlayingField *board, Uint32 seconds, Uint8 name, Uint8 player);
int displayHighscores(Uint8 newEntry, Bool tooEasy);
void print2Digits(Uint8 value, char string[3]);

#endif

#include <SGL.H>
#include "common.h"
#include <sega_bup.h>
#include "RockinVR.h"
#include "board.h"
#include "hscfdata.h"


#if defined(USE_PCM)

/* speech */
extern Uint8 champion[];
extern Uint32 champion_size;
extern PCM champion_dat ;

extern Uint8 verygood[];
extern Uint32 verygood_size;
extern PCM verygood_dat ;

extern Uint8 goodwork[];
extern Uint32 goodwork_size;
extern PCM goodwork_dat ;
/* Cannot be used, otherwise the screen keeps black
 * for some reason. Maybe the binary wwould be too big
extern Uint8 morebomb[];
extern Uint32 morebomb_size;
extern PCM morebomb_dat ;
*/
extern Uint8 notbad[];
extern Uint32 notbad_size;
extern PCM notbad_dat ;

extern Uint8 toobad[];
extern Uint32 toobad_size;
extern PCM toobad_dat ;

/* applause */
extern Uint8 applaus1[];
extern Uint32 applaus1_size;
extern PCM applaus1_dat ;

extern Uint8 applaus2[];
extern Uint32 applaus2_size;
extern PCM applaus2_dat ;

extern Uint8 applaus3[];
extern Uint32 applaus3_size;
extern PCM applaus3_dat ;

extern Uint8 applaus4[];
extern Uint32 applaus4_size;
extern PCM applaus4_dat ;

/* SFX */
extern Uint8 confirm[];
extern Uint32 confirm_size;
extern PCM confirm_dat ;
#endif


/* The default highscore table */
Uint8 BackupData[CF_DATA_LENGTH + HS_ENTRIES*HS_ENTRY_LENGTH] = 
{
#include "media/hstable/hstable.h"
};


//void displayDate(Uint8 year, Uint8 month, Uint8 day, Uint8 posX, Uint8 posY);

/* How the Highscore is ordered:
 * Goal: lower time -> higher rank, bigger playing field -> higher rank, more bombs -> higher rank
 *   ! bombs have higher priority than just increasing the playing field
 * -> The higher this number: (width*height*bombs*bombs) / seconds
 *    the higher the rank
 * ! new formula: (  (b*b) / (w*h*t)  )
 *
 */
int updateHighscores(PlayingField *board, Uint32 seconds, Uint8 name, Uint8 player)
{
     Uint8 i, rank, orank = HS_ENTRIES + 1, wrank = 0;
     Uint8 replace = 0;
     Uint32 twidth, theight, tbombs, tseconds, ret;
     SmpcDateTime today;
     float opoints, tpoints;
     opoints = ((float)(board->bombs) * (float)(board->bombs)) / ((float)(board->width) * (float)(board->height) * (float)seconds);

     slGetStatus();
     today = Smpc_Status->rtc;
     
     // check if the player made an entry, otherwise do nothing
          // we search: the last entry(lowest computed number) for replacement
          // and the highest rank which entry is below this one for rank determination
          
          // prinziple:  search all highscore entries
          //             if we found an entry whoose computed number is below ours, we increase his rank(worse)
          //                  if this entry has the lowest rank we found so far, remember that position
     for(i = 0; i < HS_ENTRIES; i++)
     {
          // compute the points
          twidth = (Uint32)BackupData[HS_START + (HS_ENTRY_LENGTH * i) + HS_WIDTH]; 
          theight = (Uint32)BackupData[HS_START + (HS_ENTRY_LENGTH * i) + HS_HEIGHT]; 
          tbombs = (Uint32)BackupData[HS_START + (HS_ENTRY_LENGTH * i) + HS_BOMBS]; 
          tseconds = 60 * (Uint32)BackupData[HS_START + (HS_ENTRY_LENGTH * i) + HS_MINUTES]; 
          tseconds += (Uint32)BackupData[HS_START + (HS_ENTRY_LENGTH * i) + HS_SECONDS]; 
          tpoints = ((float)tbombs * (float)tbombs) / ((float)twidth * (float)theight * (float)tseconds);
          
          // are we better than this entry?
          if(tpoints < opoints)
          {
               rank = BackupData[HS_START + (HS_ENTRY_LENGTH * i) + HS_RANK];          

               // is it a candidate to replace in memory?
               if(wrank <= rank)
               {
                    wrank = rank;
                    replace = i;
               }
               
               // is it the entry whoose rank we replace?
               if(orank >= rank)
                    orank = rank;
               
               // the entry shifts one position down
               BackupData[HS_START + (HS_ENTRY_LENGTH * i) + HS_RANK]++;     
          }
     }
     

     // do we have an entry?
     if(orank < HS_ENTRIES + 1)
     {
          // insert all data
          // handling of date is similar to backup library
          // but playing time is not
          BackupData[HS_START + (HS_ENTRY_LENGTH * replace) + HS_RANK] = orank;          
          BackupData[HS_START + (HS_ENTRY_LENGTH * replace) + HS_WIDTH] = board->width;          
          BackupData[HS_START + (HS_ENTRY_LENGTH * replace) + HS_HEIGHT] = board->height;          
          BackupData[HS_START + (HS_ENTRY_LENGTH * replace) + HS_BOMBS] = board->bombs;          
          BackupData[HS_START + (HS_ENTRY_LENGTH * replace) + HS_MINUTES] = (Uint8)(seconds / 60);          
          BackupData[HS_START + (HS_ENTRY_LENGTH * replace) + HS_SECONDS] = (Uint8)(seconds - (60 * BackupData[HS_START + (HS_ENTRY_LENGTH * replace) + HS_MINUTES]));          
          BackupData[HS_START + (HS_ENTRY_LENGTH * replace) + HS_YEAR] = (Uint8)(slDec2Hex((Uint32)today.year) - 1980);          
          BackupData[HS_START + (HS_ENTRY_LENGTH * replace) + HS_MONTH] = (Uint8)(today.month & 0x0f);
          BackupData[HS_START + (HS_ENTRY_LENGTH * replace) + HS_DAY] = (Uint8)slDec2Hex((Uint32)today.date);          
          
          // copy over the selected player name saved in game configuration
          for(i = 0; i < HS_NAME_LENGTH; i++)
          {
               BackupData[HS_START + (HS_ENTRY_LENGTH * replace) + HS_NAME + i] = BackupData[name + i];
          }
          // terminate string
          BackupData[HS_START + (HS_ENTRY_LENGTH * replace) + HS_NAME + HS_NAME_LENGTH] = '\0';
          // ask if that name is ok
          get_name("Your highscore name:", HS_NAME_LENGTH, &BackupData[HS_START + (HS_ENTRY_LENGTH * replace) + HS_NAME], player);
          
          // save the new highscores
          ret = saveBackupData();
          if(ret != ERROR_OK)
               return ret;
          
          // show highscores
          ret = displayHighscores(orank, (((int)board->width * (int)board->height) / (int)board->bombs < 9 ? FALSE : TRUE));     
          if(ret != ERROR_OK)
               return ret;
     }
#if defined(USE_PCM)
     else
     {
          /* say too bad */
          slPCMOn(&toobad_dat , toobad , toobad_size);
     }     
#endif
          
     return ERROR_OK;     
}



/* Should look like this:
 *
 *  R      Name  W  H  B  Time       Date
 *  1  Player__  5  5  5 00:32 2000/05/07
 */
void print2Digits(Uint8 value, char string[3])
{
     string[0] = (value / 10) + 48;
     string[1] = value - (10*(string[0] - 48)) + 48;
     string[2] = '\0';
     if(string[0] == '0')
          string[0] = ' ';
     
     return;
}

void displayDate(Uint8 year, Uint8 month, Uint8 day, Uint8 posX, Uint8 posY)
{
     char string[11];
     Uint16 years = (Uint16)year + 1980;
     
     // fill the string
     string[0] = (char)((years / 1000) + 48);
     string[1] = (char)((years - ((string[0] - 48) * 1000)) / 100 + 48);
     string[2] = (char)((years - ((string[0] - 48) * 1000) - ((string[1] - 48) * 100)) / 10 + 48);
     string[3] = (char)((years - ((string[0] - 48) * 1000) - ((string[1] - 48) * 100) - ((string[2] - 48) * 10)) + 48);
     string[4] = '/';
     string[5] = (char)((month / 10) + 48);
     string[6] = (char)(month - ((string[5] - 48) * 10) + 48);
     string[7] = '/';
     string[8] = (char)((day / 10) + 48);
     string[9] = (char)(day - ((string[8] - 48) * 10) + 48);
     string[10] = '\0';
               
     // then display the string
     slPrint(string, slLocate(posX, posY));

     return;
}

void printHighscores(Uint8 startRank, Uint8 newEntry)
{
     int i;
     Uint8 rank;
     char n[3];

     // print entries sorted
     // search all entries and only print the right ones
     for(i = 0; i < HS_ENTRIES; i++)
     {
          rank = BackupData[HS_START + HS_ENTRY_LENGTH*i + HS_RANK];
          if((startRank <= rank) && (rank < startRank + HS_ENTRIES_PER_PAGE))
          {
               print2Digits(rank, n);
               slPrint(n, slLocate(2, 7 + rank - startRank));
               
               // look if to mark as new entry
               if(rank == newEntry)
                    slPrint("*", slLocate(4, 7 + rank - startRank)); 

               BackupData[HS_START + (HS_ENTRY_LENGTH*i) + HS_NAME + HS_NAME_LENGTH] = '\0';
               slPrint(&BackupData[HS_START + (HS_ENTRY_LENGTH*i) + HS_NAME], slLocate(5, 7 + rank - startRank));

               print2Digits(BackupData[HS_START + (HS_ENTRY_LENGTH*i) + HS_WIDTH], n);
               slPrint(n, slLocate(14, 7 + rank - startRank));

               print2Digits(BackupData[HS_START + (HS_ENTRY_LENGTH*i) + HS_HEIGHT], n);
               slPrint(n, slLocate(17, 7 + rank - startRank));

               print2Digits(BackupData[HS_START + (HS_ENTRY_LENGTH*i) + HS_BOMBS], n);
               slPrint(n, slLocate(20, 7 + rank - startRank));

               displayTime(60 * BackupData[HS_START + (HS_ENTRY_LENGTH*i) + HS_MINUTES] + BackupData[HS_START + (HS_ENTRY_LENGTH*i) + HS_SECONDS], 23, 7 + rank - startRank);
               displayDate(BackupData[HS_START + (HS_ENTRY_LENGTH*i) + HS_YEAR], BackupData[HS_START + (HS_ENTRY_LENGTH*i) + HS_MONTH], BackupData[HS_START + (HS_ENTRY_LENGTH*i) + HS_DAY], 29, 7 + rank - startRank);
          }
     }
     
     return;                    
}

void updateScreen(Uint8 startRank, Uint8 newEntry)
{
     clearScreen();
     slPrint("Rockin'-B's MineSweeper", slLocate(8, 2));
     slPrint("for SEGA Saturn", slLocate(12, 3));

     // print headline
     slPrint("R", slLocate(3, 5));
     slPrint("Name", slLocate(5, 5));
     slPrint("W", slLocate(15, 5));
     slPrint("H", slLocate(18, 5));
     slPrint("B", slLocate(21, 5));
     slPrint("Time", slLocate(23, 5));
     slPrint("Date", slLocate(29, 5));
     
     printHighscores(startRank, newEntry);
          
     slPrint("<- L     Press Start Button     R ->", slLocate(2, 28));

     return;
}

int displayHighscores(Uint8 newEntry, Bool tooEasy)
{
     int i,j;
     Uint16 push;
     Uint8 rank, startRank;

     // to point to selected speech and applause sequence
     Uint8 *speech, *applause;
     Uint32 speech_size, applause_size;
     PCM *speech_dat, *applause_dat ;


     /* display the correct page of the new entry */
     if((0 < newEntry) && (newEntry <= HS_ENTRIES))
     {
          /* search all pages */
          for(startRank = 1; startRank <= HS_ENTRIES; startRank += HS_ENTRIES_PER_PAGE)
          {
               /* if the new entry is on this page, leave */
               if((startRank <= newEntry) && (newEntry < startRank + HS_ENTRIES_PER_PAGE))
                    break;
          }
     }
     else
          startRank = 1;

     updateScreen(startRank, newEntry);
     slSynch();
     
#if defined(USE_PCM)
     /* select & play speech only if a new entry happend */
     if(newEntry != 0)
     {
          /* wait untill previous sound ends */
          while(slPCMStat(&confirm_dat)) { slSynch(); }

//          if(tooEasy == TRUE)
//          {
//              /* give advice */               
//              slPCMOn(&morebomb_dat , morebomb , morebomb_size);
//          }
//          else
          {
               if(newEntry == 1)
               {
                    speech = champion;
                    speech_size = champion_size;
                    speech_dat = &champion_dat;

                    applause = applaus1;
                    applause_size = applaus1_size;
                    applause_dat = &applaus1_dat;
               }
               else if(newEntry <= HS_ENTRIES_PER_PAGE)
                    {
                         speech = verygood;
                         speech_size = verygood_size;
                         speech_dat = &verygood_dat;

                         applause = applaus2;
                         applause_size = applaus2_size;
                         applause_dat = &applaus2_dat;
                    }
                    else if(newEntry <= 2*HS_ENTRIES_PER_PAGE)
                         {
                              speech = goodwork;
                              speech_size = goodwork_size;
                              speech_dat = &goodwork_dat;

                              applause = applaus3;
                              applause_size = applaus3_size;
                              applause_dat = &applaus3_dat;
                         }
                         else
                         {
                              speech = notbad;
                              speech_size = notbad_size;
                              speech_dat = &notbad_dat;

                              applause = applaus4;
                              applause_size = applaus4_size;
                              applause_dat = &applaus4_dat;
                         }
               /* and start playing the sequence */               
               slPCMOn(speech_dat , speech , speech_size);
               /* wait untill speech ends */
               while(slPCMStat(speech_dat)) { slSynch(); }
               /* wait some time silent */
               for(i = 0; i < PCM_PAUSE; i++) { slSynch(); }
               /* and start playing the applause */               
               slPCMOn(applause_dat , applause , applause_size);
          }
     }
                         
#endif     
     
     waitRelease();
     while(1)
     {
          // check for input
//          if(!Per_Connect1)
//               return ERROR_NO_CONTROLLER;
//          push = Smpc_Peripheral[0].push;
          getfirstPadInput(NULL, &push, NULL);
               
          switch(push)
          {
               // check if to show higher ranks
               case(PRESSED_PAD_L):
               case(PRESSED_PAD_LEFT):
               case(PRESSED_PAD_UP):
                    if(startRank > 1)
                         startRank -= HS_ENTRIES_PER_PAGE;
                    break;
          
               // check if to show lower ranks
               case(PRESSED_PAD_R):
               case(PRESSED_PAD_RIGHT):
               case(PRESSED_PAD_DOWN):
                    if(startRank < HS_ENTRIES - HS_ENTRIES_PER_PAGE)
                         startRank += HS_ENTRIES_PER_PAGE;
                    break;
               
               // check if to return
               case(PRESSED_PAD_START):
               case(PRESSED_PAD_B):
#if defined(USE_PCM)
                    /* wait untill applause ends */
                    if(newEntry != 0)
                         while(slPCMStat(applause_dat)) { slSynch(); }
#endif          
                    return;
          }     
          
          if(push != PRESSED_PAD_NOTHING)
               updateScreen(startRank, newEntry);
               
          slSynch();
     }
}


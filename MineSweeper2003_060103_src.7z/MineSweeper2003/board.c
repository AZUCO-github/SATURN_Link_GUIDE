#include <SGL.H>
#include "common.h"
#include "replay.h"
#include "hscfdata.h"
#include "board.h"


extern SPR_ATTR attr[];



int createBoard(PlayingField *board, Uint8 width, Uint8 height, Uint8 bombs, Uint8 posX, Uint8 posY)
{
     FIXED random;
     int i, j;
     Uint16 nElements = (Uint16)width*(Uint16)height;
     
     // first allocate the board
     if((board->elements = (Element *)malloc((int)width * (int)height * sizeof(Element))) == NULL)
          return ERROR_OUT_OF_MEMORY;

     // set attributes
     board->width = width;
     board->height = height;
     board->bombs = bombs;
     board->coveredElements = (height * width) - bombs;
     board->cursorX = 0;
     board->cursorY = 0;
     board->posX = posX;
     board->posY = posY;
     board->exploded = FALSE;
     
     // initialize playing field data
     for(i = 0; i < nElements; i++)
     {
          (board->elements + i)->isCovered = TRUE;     
          (board->elements + i)->isBomb = FALSE;     
          (board->elements + i)->isMarked = FALSE;     
          (board->elements + i)->nBombsAround = 0;     
     }

     // then insert the bombs
     while(bombs > 0)
     {
          // get bombs position in playing field
          random = slRandom();
          i = (int)(slMulFX(random, toFIXED(nElements - 1)) / 65536.0);
          
          // insert only one bomb per element 
          if((board->elements + i)->isBomb == FALSE)
          {
               (board->elements + i)->isBomb = TRUE;
               bombs--;
          }     
     }

     // and compute the numbers
     computeNumbers(board);

     return ERROR_OK;
}



int reCreateBoard(PlayingField *board, ReplayData *replay, Uint8 posX, Uint8 posY)
{
     int i;
     
     Uint16 nElements;
     
     // reconstruct the playing field from the replay data
          // set size
     board->width = *(replay->start + REPLAY_WIDTH);
     board->height = *(replay->start + REPLAY_HEIGHT);
     board->bombs = *(replay->start + REPLAY_BOMBS);
     board->coveredElements = ((Uint16)board->height * (Uint16)board->width) - (Uint16)board->bombs;
     board->cursorX = 0;
     board->cursorY = 0;
     board->posX = posX;
     board->posY = posY;
     board->exploded = FALSE;


     nElements = (Uint16)board->width * (Uint16)board->height;
     
     // first allocate the board
     if((board->elements = (Element *)malloc(nElements * sizeof(Element))) == NULL)
          return ERROR_OUT_OF_MEMORY;

     // initialize playing field data
     for(i = 0; i < nElements; i++)
     {
          (board->elements + i)->isCovered = TRUE;     
          (board->elements + i)->isBomb = FALSE;     
          (board->elements + i)->isMarked = FALSE;     
          (board->elements + i)->nBombsAround = 0;     
     }

     // then insert the bombs
     for(i = 0; i < board->bombs; i++)
     {
          posX = *(replay->start + REPLAY_BOMBS + 2*i + 1);
          posY = *(replay->start + REPLAY_BOMBS + 2*i + 2);
          (board->elements + (int)posX + (int)posY*((int)(board->width)))->isBomb = TRUE;
     }

     // and compute the numbers
     computeNumbers(board);
     
     return ERROR_OK;
}



void computeNumbers(PlayingField *board)
{
     int i, j;
     int width = (int)(board->width);

     for(i = 0; i < board->height; i++)
     {
          for(j = 0; j < board->width; j++)
          {
               // element itself
               if((board->elements + i*width + j)->isBomb == TRUE)
                    (board->elements + i*width + j)->nBombsAround++;           
               // top 3 elements
               if(i > 0)
               {
                    // top
                    if((board->elements + (i-1)*width + j)->isBomb == TRUE)
                         (board->elements + i*width + j)->nBombsAround++;           
                    // topleft
                    if((j > 0) && ((board->elements + (i-1)*width + j-1)->isBomb == TRUE))
                         (board->elements + i*width + j)->nBombsAround++;           
                    // topright
                    if((j < board->width-1) && ((board->elements + (i-1)*width + j+1)->isBomb == TRUE))
                         (board->elements + i*width + j)->nBombsAround++;           
               }
               // bottom 3 elements
               if(i < board->height-1)
               {
                    // bottom
                    if((board->elements + (i+1)*width + j)->isBomb == TRUE)
                         (board->elements + i*width + j)->nBombsAround++;           
                    // bottomleft
                    if((j > 0) && ((board->elements + (i+1)*width + j-1)->isBomb == TRUE))
                         (board->elements + i*width + j)->nBombsAround++;           
                    // bottomright
                    if((j < board->width-1) && ((board->elements + (i+1)*(int)board->width + j+1)->isBomb == TRUE))
                         (board->elements + i*width + j)->nBombsAround++;           
               }
               // left
               if((j > 0) && ((board->elements + i*width + j-1)->isBomb == TRUE))
                    (board->elements + i*width + j)->nBombsAround++;           
               //  right
               if((j < board->width-1) && ((board->elements + i*width + j+1)->isBomb == TRUE))
                    (board->elements + i*width + j)->nBombsAround++;           
          }
     }
     return;
}



int deleteBoard(PlayingField *board)
{
     free(board->elements);
     board->width = 0;
     board->height = 0;
     board->bombs = 0;
     board->cursorX = 0;
     board->cursorY = 0;
     board->posX = 0;
     board->posY = 0;
     board->coveredElements = 0;
     board->exploded = FALSE;

     return ERROR_OK;
}




int displayBoardSprite(PlayingField *board, Bool cursor, Bool cheat)
{
     int i, j;
     char n[1];

     FIXED pos[XYZS] = {toFIXED(0),toFIXED(0),toFIXED(169),toFIXED(1.0)};
     ANGLE ang = DEGtoANG(0);
     
     int width = (int)(board->width);
     int height = (int)(board->height);

     
     n[1] = '\0';

     for(i = 0; i < height; i++)
     {
          for(j = 0; j < width; j++)
          {
               /* manage cursor blinking */
               /* display all non cursor position and the cursor position only, if cursor != TRUE and cheat != TUE */
               if(((board->posX + board->cursorX == board->posX + j) && (board->posX + board->cursorX == board->posX + j) && ((cheat == TRUE) || (cursor == FALSE))) || ((board->posX + board->cursorX != board->posX + j) || (board->posY + board->cursorY != board->posY + i)))
               {
                    pos[X] = toFIXED(board->posX + j * 16 - 152);
                    pos[Y] = toFIXED(board->posY + i * 16 - 112);

                    // check if element is covered or not
                    if(((board->elements + i*width + j)->isCovered) == TRUE && (cheat == FALSE))
                    {
                         // covered
                         // check if element is marked or not
                         if((board->elements + i*width + j)->isMarked == TRUE && (cheat == FALSE))
                              slDispSprite((FIXED *)pos, attr + 10, ang);             
                         else
                              slDispSprite((FIXED *)pos, attr + 9, ang);             
                    }    
                    else
                    {
                         // uncovered
                         // check if a bomb has been uncovered
                         if((board->elements + i*width + j)->isBomb == TRUE)
                              slDispSprite((FIXED *)pos, attr + 11, ang);             
                         else
                         // else display the number of surrounding bombs
                         // convert Uint8 to ASCII
                              slDispSprite((FIXED *)pos, attr + (board->elements + i*width + j)->nBombsAround, ang);             
                    }
               }
          }
     }
     return ERROR_OK;
}

